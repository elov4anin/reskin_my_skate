(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\serg\WebstormProjects\reskin_my_skate\src\main.ts */"zUnb");


/***/ }),

/***/ "03gG":
/*!**********************************************!*\
  !*** ./src/app/shared/enums/Storage.enum.ts ***!
  \**********************************************/
/*! exports provided: StorageEnum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageEnum", function() { return StorageEnum; });
var StorageEnum;
(function (StorageEnum) {
    StorageEnum["PROFILE"] = "profile";
    StorageEnum["GAME"] = "game";
    StorageEnum["LOGGEDIN"] = "loggedIn";
    StorageEnum["SELECTED_SKATEPARK"] = "selectedSkatepark";
    StorageEnum["SKATEPARK_FEATURES"] = "skateparkFeatures";
    StorageEnum["SELECTED_NEWS"] = "selectedNews";
    StorageEnum["SELECTED_EVENT"] = "selectedEvent";
    StorageEnum["SELECTED_STORE"] = "selectedStore";
})(StorageEnum || (StorageEnum = {}));


/***/ }),

/***/ "162u":
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.enum.ts ***!
  \***********************************/
/*! exports provided: TabsEnum, tabsEnum2LabelMapping, tabsEnum2RouteMapping, tabsEnum2IconMapping, tabsEnum2IconActiveMapping, TABS_MAIN_ROUTE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsEnum", function() { return TabsEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabsEnum2LabelMapping", function() { return tabsEnum2LabelMapping; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabsEnum2RouteMapping", function() { return tabsEnum2RouteMapping; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabsEnum2IconMapping", function() { return tabsEnum2IconMapping; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabsEnum2IconActiveMapping", function() { return tabsEnum2IconActiveMapping; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TABS_MAIN_ROUTE", function() { return TABS_MAIN_ROUTE; });
var TabsEnum;
(function (TabsEnum) {
    TabsEnum["SKATEPARKS"] = "SKATEPARKS";
    TabsEnum["SPOTS"] = "SPOTS";
    TabsEnum["GAME"] = "GAME";
    TabsEnum["STORES"] = "STORES";
    TabsEnum["EVENTS"] = "EVENTS";
    // not show in tabs footer
    TabsEnum["TEAM"] = "TEAM";
    TabsEnum["NEWS"] = "NEWS";
    TabsEnum["PROFILE"] = "PROFILE";
})(TabsEnum || (TabsEnum = {}));
const tabsEnum2LabelMapping = {
    SKATEPARKS: '',
    SPOTS: '',
    GAME: '',
    STORES: '',
    EVENTS: '',
    TEAM: '',
    NEWS: '',
    PROFILE: '',
};
const tabsEnum2RouteMapping = {
    SKATEPARKS: 'skateparks',
    SPOTS: 'spots',
    GAME: 'game',
    STORES: 'stores',
    EVENTS: 'events',
    TEAM: 'team',
    NEWS: 'news',
    PROFILE: 'profile',
};
const tabsEnum2IconMapping = {
    SKATEPARKS: 'search.svg',
    SPOTS: 'spots.svg',
    GAME: 'game.svg',
    STORES: 'store.svg',
    EVENTS: 'events.svg',
    TEAM: '',
    NEWS: '',
    PROFILE: '',
};
const tabsEnum2IconActiveMapping = {
    SKATEPARKS: 'search-active.svg',
    SPOTS: 'spots-active.svg',
    GAME: 'game-active.svg',
    STORES: 'store-active.svg',
    EVENTS: 'events-active.svg',
    TEAM: '',
    NEWS: '',
    PROFILE: '',
};
const TABS_MAIN_ROUTE = 'tabs';


/***/ }),

/***/ "2DP2":
/*!*******************************************!*\
  !*** ./src/app/pages/game/game-routes.ts ***!
  \*******************************************/
/*! exports provided: GameRoutes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GameRoutes", function() { return GameRoutes; });
var GameRoutes;
(function (GameRoutes) {
    GameRoutes["ROOT"] = "game";
    GameRoutes["TRICK"] = "trick";
    GameRoutes["NAILED"] = "nailed";
    GameRoutes["FAILED"] = "failed";
    GameRoutes["CURRENT"] = "current-standings";
    GameRoutes["CONGRADULATIONS"] = "congradulations";
})(GameRoutes || (GameRoutes = {}));


/***/ }),

/***/ "8e7N":
/*!********************************************!*\
  !*** ./src/app/shared/store/core.store.ts ***!
  \********************************************/
/*! exports provided: CoreStore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreStore", function() { return CoreStore; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _abstract_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./abstract.store */ "zEat");
/* harmony import */ var _core_state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core.state */ "Fc0j");
/* harmony import */ var _enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../enums/Storage.enum */ "03gG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _helpers_ionic_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../helpers/ionic-storage.service */ "JUP5");






let CoreStore = class CoreStore extends _abstract_store__WEBPACK_IMPORTED_MODULE_1__["Store"] {
    constructor(_storage) {
        super(new _core_state__WEBPACK_IMPORTED_MODULE_2__["CoreState"]());
        this._storage = _storage;
        this._prefix = 'lk';
        // read initial values from storage
        this.ready$ = Promise.all([
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].LOGGEDIN),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].PROFILE),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].GAME),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SELECTED_SKATEPARK),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SKATEPARK_FEATURES),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SELECTED_NEWS),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SELECTED_EVENT),
            this.initValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SELECTED_EVENT),
        ]);
    }
    initValue(prop) {
        return this._storage.getItem(prop).then(value => {
            this.setStateValue(prop, value);
            return value;
        }).catch(_ => {
            this.setStateValue(prop, undefined);
            return undefined;
        });
    }
    initObsValue(prop) {
        return this._storage.getItem(prop).then(value => {
            this.setStateValue(prop, value);
            return value;
        }).catch(_ => {
            this.setStateValue(prop, undefined);
            return undefined;
        });
    }
    setStateValue(prop, value) {
        this.state = Object.assign(Object.assign({}, this.state), { [prop]: value });
    }
    setValue(prop, value) {
        this.setStateValue(prop, value);
        return this._storage.setItem(prop, value);
    }
    setCacheValue(prop, value) {
        value = JSON.stringify(value);
        this.setStateValue(prop, value);
        return this._storage.setItem(prop, value);
    }
    getValue(prop) {
        return this._storage.getItem(prop);
    }
    removeValue(prop) {
        this.setStateValue(prop, undefined);
        return this._storage.removeItem(prop);
    }
    clearLogout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.removeValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].LOGGEDIN);
            yield this.removeValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].GAME);
            yield this.removeValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].PROFILE);
            yield this.removeValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SELECTED_SKATEPARK);
            yield this.removeValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].SKATEPARK_FEATURES);
        });
    }
};
CoreStore.ctorParameters = () => [
    { type: _helpers_ionic_storage_service__WEBPACK_IMPORTED_MODULE_5__["IonicStorageService"] }
];
CoreStore = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"])({
        providedIn: 'root'
    })
], CoreStore);



/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "Fc0j":
/*!********************************************!*\
  !*** ./src/app/shared/store/core.state.ts ***!
  \********************************************/
/*! exports provided: CoreState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreState", function() { return CoreState; });
class CoreState {
    constructor() {
        // set initial state
        this.profile = undefined;
        this.game = undefined;
        this.loggedIn = undefined;
        this.selectedSkatepark = undefined;
        this.skateparkFeatures = undefined;
        this.selectedNews = undefined;
        this.selectedEvent = undefined;
        this.selectedStore = undefined;
    }
}


/***/ }),

/***/ "JUP5":
/*!*********************************************************!*\
  !*** ./src/app/shared/helpers/ionic-storage.service.ts ***!
  \*********************************************************/
/*! exports provided: IonicStorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IonicStorageService", function() { return IonicStorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "e8h1");
/* harmony import */ var _enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../enums/Storage.enum */ "03gG");




let IonicStorageService = class IonicStorageService {
    constructor(_storage) {
        this._storage = _storage;
    }
    setItem(key, value) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._storage.set(key, value);
        });
    }
    getItem(key) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this._storage.get(key);
        });
    }
    removeItem(key) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this._storage.remove(key);
        });
    }
    // async isAuthenticated(): Promise<boolean> {
    //     return !!await this.getToken;
    // }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._storage.remove(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].LOGGEDIN); //@todo
            yield this._storage.remove(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].PROFILE);
            yield this._storage.remove(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_3__["StorageEnum"].GAME);
        });
    }
};
IonicStorageService.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"] }
];
IonicStorageService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], IonicStorageService);



/***/ }),

/***/ "KwcL":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/pwa-elements/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pwa-action-sheet.entry.js": [
		"jDxf",
		43
	],
	"./pwa-camera-modal-instance.entry.js": [
		"37vE",
		44
	],
	"./pwa-camera-modal.entry.js": [
		"cJxf",
		45
	],
	"./pwa-camera.entry.js": [
		"eGHz",
		46
	],
	"./pwa-toast.entry.js": [
		"fHjd",
		47
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "KwcL";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "LjFu":
/*!*********************************************!*\
  !*** ./src/app/shared/guards/auth.guard.ts ***!
  \*********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _store_core_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../store/core.store */ "8e7N");
/* harmony import */ var _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../pages/auth/auth-routes.enum */ "mKaM");
/* harmony import */ var _helpers_ionic_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../helpers/ionic-storage.service */ "JUP5");
/* harmony import */ var _enums_Storage_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../enums/Storage.enum */ "03gG");







let AuthGuard = class AuthGuard {
    constructor(_coreStore, router, _storage) {
        this._coreStore = _coreStore;
        this.router = router;
        this._storage = _storage;
    }
    canActivate(route, state) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loggedIn = yield this._coreStore.getValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_6__["StorageEnum"].LOGGEDIN);
            if (loggedIn) {
                return true;
            }
            else {
                yield this.router.navigate(['/', _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_4__["AuthRoutesEnum"].ROOT], {
                    queryParams: {
                        accessDenied: true
                    }
                });
                return false;
            }
        });
    }
    canActivateChild(route, state) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.canActivate(route, state);
        });
    }
    canLoad(route) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loggedIn = yield this._coreStore.getValue(_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_6__["StorageEnum"].LOGGEDIN);
            if (loggedIn) {
                return true;
            }
            else {
                yield this.router.navigate(['/', _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_4__["AuthRoutesEnum"].ROOT], {
                    queryParams: {
                        accessDenied: true
                    }
                });
                return false;
            }
        });
    }
};
AuthGuard.ctorParameters = () => [
    { type: _store_core_store__WEBPACK_IMPORTED_MODULE_3__["CoreStore"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
    { type: _helpers_ionic_storage_service__WEBPACK_IMPORTED_MODULE_5__["IonicStorageService"] }
];
AuthGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ "MJS4":
/*!******************************************************************!*\
  !*** ./src/app/shared/layouts/mail-layout/main-layout.helper.ts ***!
  \******************************************************************/
/*! exports provided: MainLayoutHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainLayoutHelper", function() { return MainLayoutHelper; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



let MainLayoutHelper = class MainLayoutHelper {
    constructor() {
        this.menuToggleEmitter$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](true);
    }
};
MainLayoutHelper = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: "root"
    })
], MainLayoutHelper);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss */ "ynWL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "54vc");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "VYYF");
/* harmony import */ var _shared_layouts_mail_layout_main_layout_helper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./shared/layouts/mail-layout/main-layout.helper */ "MJS4");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./tabs/tabs.enum */ "162u");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./shared/store/core.store */ "8e7N");
/* harmony import */ var _pages_auth_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/auth/auth.service */ "zbnG");












let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, _mainLayoutHelper, _router, _coreStore, _authService) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this._mainLayoutHelper = _mainLayoutHelper;
        this._router = _router;
        this._coreStore = _coreStore;
        this._authService = _authService;
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
            yield this._coreStore.ready$;
        }));
    }
    showHeaderToggle() {
        this._mainLayoutHelper.menuToggleEmitter$.next(true);
    }
    openTeam() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["tabsEnum2RouteMapping"].TEAM]);
        });
    }
    openNews() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["tabsEnum2RouteMapping"].NEWS]);
        });
    }
    openProfile() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["tabsEnum2RouteMapping"].PROFILE]);
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"] },
    { type: _shared_layouts_mail_layout_main_layout_helper__WEBPACK_IMPORTED_MODULE_7__["MainLayoutHelper"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_10__["CoreStore"] },
    { type: _pages_auth_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n    <ion-split-pane contentId=\"main\">\n        <!--  the side menu  -->\n        <ion-menu contentId=\"main\" menuId=\"main-menu\" (ionDidClose)=\"showHeaderToggle()\">\n            <ion-header>\n                <ion-toolbar color=\"primary\" class=\"ion-padding-top\">\n                    <ion-menu-toggle auto-hide=\"false\" slot=\"end\" class=\"ion-margin-end\">\n                        <ion-icon name=\"menu-outline\" color=\"light\" size=\"large\"></ion-icon>\n                    </ion-menu-toggle>\n                </ion-toolbar>\n            </ion-header>\n            <ion-content color=\"primary\">\n                <ion-list lines=\"full\">\n                    <ion-menu-toggle auto-hide=\"false\">\n                        <ion-item color=\"primary\" class=\"person\" (click)=\"openProfile()\">\n                            <ion-thumbnail slot=\"start\">\n                                <img src=\"assets/images/no-avatar.png\">\n                            </ion-thumbnail>\n                            <ion-label>\n                                <h3 class=\"person__name\">Mike Johanssen</h3>\n                                <ion-text color=\"medium\" class=\"person__info\">Active since 2019</ion-text>\n                            </ion-label>\n                            <ion-icon color=\"medium\" slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\n                        </ion-item>\n                    </ion-menu-toggle>\n                    <ion-menu-toggle auto-hide=\"false\">\n                        <ion-item color=\"primary\" (click)=\"openTeam()\"\n                        >\n                            <ion-label>Roll with Team GB</ion-label>\n                            <ion-icon color=\"medium\" slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\n                        </ion-item>\n                    </ion-menu-toggle>\n                    <ion-menu-toggle auto-hide=\"false\">\n                        <ion-item color=\"primary\" (click)=\"openNews()\">\n                            <ion-label>News</ion-label>\n                            <ion-icon color=\"medium\" slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\n                        </ion-item>\n                    </ion-menu-toggle>\n                </ion-list>\n\n            </ion-content>\n        </ion-menu>\n\n        <!-- the main content -->\n        <ion-router-outlet id=\"main\"></ion-router-outlet>\n    </ion-split-pane>\n</ion-app>\n");

/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "54vc");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "VYYF");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ "h+qT");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage */ "e8h1");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "m/P+");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "B7Rs");















let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot({
                mode: 'ios'
            }),
            _ionic_storage__WEBPACK_IMPORTED_MODULE_11__["IonicStorageModule"].forRoot({
                name: '__skate',
                driverOrder: ['sqlite', 'websql', 'indexeddb']
            }),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
            _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__["NativeGeocoder"],
            _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_12__["InAppBrowser"],
            _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_13__["Camera"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_14__["FileTransfer"],
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "gb4m":
/*!***********************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepars-routers.enum.ts ***!
  \***********************************************************/
/*! exports provided: SKATEPARKS_ROUTES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SKATEPARKS_ROUTES", function() { return SKATEPARKS_ROUTES; });
var SKATEPARKS_ROUTES;
(function (SKATEPARKS_ROUTES) {
    SKATEPARKS_ROUTES["SEARCH"] = "search";
    SKATEPARKS_ROUTES["SKATEPARK"] = "skatepark";
})(SKATEPARKS_ROUTES || (SKATEPARKS_ROUTES = {}));


/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "mKaM":
/*!************************************************!*\
  !*** ./src/app/pages/auth/auth-routes.enum.ts ***!
  \************************************************/
/*! exports provided: AuthRoutesEnum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthRoutesEnum", function() { return AuthRoutesEnum; });
var AuthRoutesEnum;
(function (AuthRoutesEnum) {
    AuthRoutesEnum["ROOT"] = "auth";
    AuthRoutesEnum["LOGIN"] = "login";
    AuthRoutesEnum["REG"] = "register";
    AuthRoutesEnum["FORGOT_PASS"] = "forgot";
})(AuthRoutesEnum || (AuthRoutesEnum = {}));


/***/ }),

/***/ "phI0":
/*!***********************************************!*\
  !*** ./src/app/shared/configs/main.config.ts ***!
  \***********************************************/
/*! exports provided: GOOGLE_API_KEY, SITE_MAIN, DOMAIN, DATE_FORMAT, MIN_AGE, TRUE_VALUE, FALSE_VALUE, QUALITY_CAMERA */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GOOGLE_API_KEY", function() { return GOOGLE_API_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SITE_MAIN", function() { return SITE_MAIN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOMAIN", function() { return DOMAIN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DATE_FORMAT", function() { return DATE_FORMAT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MIN_AGE", function() { return MIN_AGE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRUE_VALUE", function() { return TRUE_VALUE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FALSE_VALUE", function() { return FALSE_VALUE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QUALITY_CAMERA", function() { return QUALITY_CAMERA; });
const GOOGLE_API_KEY = 'AIzaSyD4NsbNRut7TIheBfLcZzeT-0hZV8sxwCY';
const SITE_MAIN = 'https://myskate.sport80.app/app/';
const DOMAIN = 'myskate';
const DATE_FORMAT = 'DD/MM/YYYY';
const MIN_AGE = 5;
const TRUE_VALUE = '1';
const FALSE_VALUE = '0';
const QUALITY_CAMERA = 60;


/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_skateparks_skatepars_routers_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs/skateparks/skatepars-routers.enum */ "gb4m");
/* harmony import */ var _pages_game_game_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/game/game-routes */ "2DP2");
/* harmony import */ var _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/auth/auth-routes.enum */ "mKaM");
/* harmony import */ var _shared_guards_auth_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shared/guards/auth.guard */ "LjFu");







const routes = [
    {
        path: '',
        loadChildren: () => Promise.all(/*! import() | tabs-tabs-module */[__webpack_require__.e("common"), __webpack_require__.e("tabs-tabs-module")]).then(__webpack_require__.bind(null, /*! ./tabs/tabs.module */ "hO9l")).then(m => m.TabsPageModule),
    },
    {
        path: _pages_game_game_routes__WEBPACK_IMPORTED_MODULE_4__["GameRoutes"].ROOT,
        loadChildren: () => __webpack_require__.e(/*! import() | pages-game-game-module */ "pages-game-game-module").then(__webpack_require__.bind(null, /*! ./pages/game/game.module */ "kgeY")).then(m => m.GameModule),
        canLoad: [_shared_guards_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: _tabs_skateparks_skatepars_routers_enum__WEBPACK_IMPORTED_MODULE_3__["SKATEPARKS_ROUTES"].SEARCH,
        loadChildren: () => Promise.all(/*! import() | pages-search-skateparks-search-skateparks-module */[__webpack_require__.e("default~events-events-module~forgot-forgot-module~game-tab-game-tab-module~login-login-module~news-n~a54b75ee"), __webpack_require__.e("common"), __webpack_require__.e("pages-search-skateparks-search-skateparks-module")]).then(__webpack_require__.bind(null, /*! ./pages/search-skateparks/search-skateparks.module */ "Xidd")).then(m => m.SearchSkateparksPageModule),
        canLoad: [_shared_guards_auth_guard__WEBPACK_IMPORTED_MODULE_6__["AuthGuard"]]
    },
    {
        path: _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_5__["AuthRoutesEnum"].ROOT,
        loadChildren: () => __webpack_require__.e(/*! import() | pages-auth-auth-module */ "pages-auth-auth-module").then(__webpack_require__.bind(null, /*! ./pages/auth/auth.module */ "lBUW")).then(m => m.AuthModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "ynWL":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  padding-bottom: 18px;\n  --border-width: 0!important;\n}\n\nion-menu {\n  --width: 350px;\n}\n\nion-list.list-ios {\n  background: var(--ion-color-primary);\n}\n\nion-list.list-md {\n  background: var(--ion-color-primary);\n}\n\nion-thumbnail {\n  width: 80px;\n  height: 80px;\n}\n\n.person {\n  --padding-bottom: var(--ion-padding);\n}\n\n.person__name {\n  font-style: normal;\n  font-weight: 500;\n  font-size: 20px;\n  line-height: 25px;\n}\n\n.person__info {\n  font-style: normal;\n  font-weight: normal;\n  font-size: 17px;\n  line-height: 22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0JBQUE7RUFDQSwyQkFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGOztBQUlFO0VBQ0Usb0NBQUE7QUFESjs7QUFJRTtFQUNFLG9DQUFBO0FBRko7O0FBTUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQUhGOztBQU1BO0VBQ0Usb0NBQUE7QUFIRjs7QUFLRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFISjs7QUFNRTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFKSiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gIHBhZGRpbmctYm90dG9tOiAxOHB4O1xuICAtLWJvcmRlci13aWR0aDogMCFpbXBvcnRhbnQ7XG59XG5cbmlvbi1tZW51IHtcbiAgLS13aWR0aDogMzUwcHg7XG59XG5cbmlvbi1saXN0IHtcblxuICAmLmxpc3QtaW9zIHtcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cblxuICAmLmxpc3QtbWQge1xuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxufVxuXG5pb24tdGh1bWJuYWlsIHtcbiAgd2lkdGg6IDgwcHg7XG4gIGhlaWdodDogODBweDtcbn1cblxuLnBlcnNvbiB7XG4gIC0tcGFkZGluZy1ib3R0b206IHZhcigtLWlvbi1wYWRkaW5nKTtcblxuICAmX19uYW1lIHtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI1cHg7XG4gIH1cblxuICAmX19pbmZvIHtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "zEat":
/*!************************************************!*\
  !*** ./src/app/shared/store/abstract.store.ts ***!
  \************************************************/
/*! exports provided: Store */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Store", function() { return Store; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");


class Store {
    constructor(initialState) {
        this._state$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](initialState);
    }
    get state() {
        return this._state$.getValue();
    }
    set state(nextState) {
        this._state$.next(nextState);
    }
    select(selectFn) {
        return this._state$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(selectFn), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["distinctUntilChanged"])());
    }
}


/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");
/* harmony import */ var _ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/pwa-elements/loader */ "2Zi2");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));
Object(_ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__["defineCustomElements"])(window).then();


/***/ }),

/***/ "zbnG":
/*!********************************************!*\
  !*** ./src/app/pages/auth/auth.service.ts ***!
  \********************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/configs/main.config */ "phI0");




let AuthService = class AuthService {
    constructor(_http) {
        this._http = _http;
    }
    login(params) {
        // const hash = md5(params.password).toString();
        // const salt = sha1(hash).toString();
        return this._http.post(_shared_configs_main_config__WEBPACK_IMPORTED_MODULE_3__["SITE_MAIN"] + 'integration/sport80-login.php', { email: params.email, hash: params.password }, {
            headers: this._getHeader(),
        });
    }
    register(params) {
        return this._http.post(_shared_configs_main_config__WEBPACK_IMPORTED_MODULE_3__["SITE_MAIN"] + 'integration/sport80-create-account.php', params, {
            headers: this._getHeader(),
        });
    }
    forgot(params) {
        return this._http.post(_shared_configs_main_config__WEBPACK_IMPORTED_MODULE_3__["SITE_MAIN"] + 'integration/sport80-reset-pass.php', { email: params.email }, {
            headers: this._getHeader(),
        });
    }
    _getHeader() {
        return new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Accept': '*/*',
            'Content-Type': 'application/json',
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map