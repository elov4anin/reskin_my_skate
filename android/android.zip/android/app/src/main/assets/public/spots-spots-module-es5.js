(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["spots-spots-module"], {
    /***/
    "7t31":
    /*!****************************************************!*\
      !*** ./src/app/tabs/spots/spots-routing.module.ts ***!
      \****************************************************/

    /*! exports provided: SpotsPageRoutingModule */

    /***/
    function t31(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SpotsPageRoutingModule", function () {
        return SpotsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _spots_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./spots.page */
      "S/fo");

      var routes = [{
        path: '',
        component: _spots_page__WEBPACK_IMPORTED_MODULE_3__["SpotsPage"]
      }];

      var SpotsPageRoutingModule = function SpotsPageRoutingModule() {
        _classCallCheck(this, SpotsPageRoutingModule);
      };

      SpotsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SpotsPageRoutingModule);
      /***/
    },

    /***/
    "Cpw/":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/spots/modal-add-spot/modal-add-spot.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Cpw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n        <ion-text slot=\"start\" class=\"ion ion-margin-start title-20\">\n            Add a new spot\n        </ion-text>\n\n        <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n            Close\n        </ion-text>\n\n    </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"dark\">\n\n    <div class=\"ion-margin-start ion-margin-end\">\n        <ion-item color=\"dark\" class=\"ion-margin-top item-inline-padding\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Spot name</ion-text>\n            </ion-label>\n            <ion-input placeholder=\"Type here\"></ion-input>\n        </ion-item>\n\n        <ion-item color=\"dark\" class=\"item-inline-padding\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Location</ion-text>\n            </ion-label>\n            <ion-input placeholder=\"Type here\"></ion-input>\n        </ion-item>\n\n        <div class=\"ion-margin-top row\">\n            <ion-text color=\"tertiary\" class=\"text-15\">\n                Many spots won’t have an address - place the pin on a map to add the exact location\n            </ion-text>\n            <div class=\"mt12\">\n                <app-map-block></app-map-block>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"ion-margin-start ion-margin-top row\">\n        <ion-label position=\"stacked\">\n            <ion-text class=\"text-16\">Photos</ion-text>\n        </ion-label>\n        <div class=\"mt12\">\n            <app-add-photos-slider></app-add-photos-slider>\n        </div>\n    </div>\n\n    <div class=\"ion-margin-start ion-margin-end ion-margin-top row\">\n        <ion-label position=\"stacked\">\n            <ion-text class=\"text-16\">Add features</ion-text>\n        </ion-label>\n        <div class=\"mt12\">\n            <app-checkbox-list [checkboxes]=\"checkboxes\"></app-checkbox-list>\n        </div>\n    </div>\n\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar color=\"dark\">\n        <ion-button class=\"ion-margin-start ion-margin-end mb12 apply-btn\" fill=\"solid\" color=\"success\" expand=\"block\">\n            Save spot\n        </ion-button>\n    </ion-toolbar>\n</ion-footer>\n";
      /***/
    },

    /***/
    "FgCx":
    /*!********************************************!*\
      !*** ./src/app/tabs/spots/spots.page.scss ***!
      \********************************************/

    /*! exports provided: default */

    /***/
    function FgCx(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".empty-text {\n  margin-top: 36px;\n  margin-bottom: 80px;\n}\n\n.add-btn {\n  --padding-end: 0 ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzcG90cy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtBQUNGIiwiZmlsZSI6InNwb3RzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lbXB0eS10ZXh0IHtcclxuICBtYXJnaW4tdG9wOiAzNnB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDgwcHg7XHJcbn1cclxuXHJcbi5hZGQtYnRuIHtcclxuICAtLXBhZGRpbmctZW5kOiAwXHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "JE4V":
    /*!*************************************************************************!*\
      !*** ./src/app/tabs/spots/modal-add-spot/modal-add-spot.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function JE4V(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-input, ion-textarea {\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n}\n\nion-label {\n  white-space: normal !important;\n}\n\nion-checkbox {\n  --background: var(--ion-color-dark);\n  --background-checked: var(--ion-color-primary);\n  --border-color: var(--ion-color-dark);\n  --border-color-checked: var(--ion-color-primary);\n  --checkmark-color: var(--ion-color-secondary);\n}\n\nion-list {\n  background: var(--ion-color-dark);\n}\n\n.apply-btn {\n  width: 100%;\n  max-width: 320px;\n}\n\n.item-inline-padding {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbW9kYWwtYWRkLXNwb3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5REFBQTtFQUNBLHVEQUFBO0VBQ0EsMENBQUE7RUFDQSxnQ0FBQTtFQUNBLDhCQUFBO0VBQ0EsOEJBQUE7RUFDQSxpQ0FBQTtFQUNBLGdEQUFBO0FBQ0Y7O0FBRUE7RUFDRSw4QkFBQTtBQUNGOztBQUVBO0VBQ0UsbUNBQUE7RUFDQSw4Q0FBQTtFQUNBLHFDQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtBQUNGOztBQUVBO0VBQ0UsaUNBQUE7QUFDRjs7QUFDQTtFQUNFLFdBQUE7RUFDQSxnQkFBQTtBQUVGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtBQUVGIiwiZmlsZSI6Im1vZGFsLWFkZC1zcG90LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWlucHV0LCBpb24tdGV4dGFyZWEge1xyXG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1jb250cmFzdCkgIWltcG9ydGFudDtcclxuICAtLXBsYWNlaG9sZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKSAhaW1wb3J0YW50O1xyXG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCkgIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctZW5kOiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1ib3R0b246IDEwcHggIWltcG9ydGFudDtcclxuICAtLWJvcmRlci1yYWRpdXM6IHZhcigtLXRoZW1lLWJhc2UtYm9yZGVyLXJhZGl1cyk7XHJcblxyXG59XHJcbmlvbi1sYWJlbCB7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY2hlY2tib3gge1xyXG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gIC0tYmFja2dyb3VuZC1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgLS1ib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAtLWJvcmRlci1jb2xvci1jaGVja2VkOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgLS1jaGVja21hcmstY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG59XHJcbi5hcHBseS1idG4ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1heC13aWR0aDogMzIwcHg7XHJcbn1cclxuXHJcbi5pdGVtLWlubGluZS1wYWRkaW5nIHtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "Jp7q":
    /*!*******************************************************************!*\
      !*** ./src/app/tabs/spots/spot-photos/spot-photos.component.scss ***!
      \*******************************************************************/

    /*! exports provided: default */

    /***/
    function Jp7q(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main-photo {\n  width: auto;\n  height: 160px;\n  border-radius: var(--theme-base-border-radius);\n  background-repeat: no-repeat;\n  background-position: center;\n}\n\n.small-photo {\n  position: relative;\n  width: auto;\n  height: 74px;\n  border-radius: var(--theme-base-border-radius);\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 100%;\n}\n\n.last {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: var(--theme-divisor-color);\n  opacity: 0.8;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcc3BvdC1waG90b3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhDQUFBO0VBRUEsNEJBQUE7RUFDQSwyQkFBQTtBQUFGOztBQUVBO0VBQ0Usa0JBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDhDQUFBO0VBRUEsNEJBQUE7RUFDQSwyQkFBQTtFQUNBLHFCQUFBO0FBREY7O0FBR0E7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFFQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUVBLHNDQUFBO0VBQ0EsWUFBQTtBQUZGIiwiZmlsZSI6InNwb3QtcGhvdG9zLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4tcGhvdG8ge1xyXG4gIHdpZHRoOiBhdXRvO1xyXG4gIGhlaWdodDogMTYwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcclxuXHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcbn1cclxuLnNtYWxsLXBob3RvIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gIHdpZHRoOiBhdXRvO1xyXG4gIGhlaWdodDogNzRweDtcclxuICBib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XHJcbn1cclxuLmxhc3Qge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICByaWdodDogMDtcclxuICBib3R0b206IDA7XHJcblxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgYmFja2dyb3VuZDogdmFyKC0tdGhlbWUtZGl2aXNvci1jb2xvcik7XHJcbiAgb3BhY2l0eTogMC44O1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "S/fo":
    /*!******************************************!*\
      !*** ./src/app/tabs/spots/spots.page.ts ***!
      \******************************************/

    /*! exports provided: SpotsPage */

    /***/
    function SFo(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SpotsPage", function () {
        return SpotsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_spots_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./spots.page.html */
      "jdHS");
      /* harmony import */


      var _spots_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./spots.page.scss */
      "FgCx");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _modal_add_spot_modal_add_spot_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./modal-add-spot/modal-add-spot.component */
      "q9IE");

      var SpotsPage = /*#__PURE__*/function () {
        function SpotsPage(_modalController) {
          _classCallCheck(this, SpotsPage);

          this._modalController = _modalController;
        }

        _createClass(SpotsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "openAddSpotModal",
          value: function openAddSpotModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var modal;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._modalController.create({
                        component: _modal_add_spot_modal_add_spot_component__WEBPACK_IMPORTED_MODULE_5__["ModalAddSpotComponent"],
                        cssClass: 'modal-add-spot'
                      });

                    case 2:
                      modal = _context.sent;
                      _context.next = 5;
                      return modal.present();

                    case 5:
                      return _context.abrupt("return", _context.sent);

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return SpotsPage;
      }();

      SpotsPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }];
      };

      SpotsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-spots',
        template: _raw_loader_spots_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_spots_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SpotsPage);
      /***/
    },

    /***/
    "X330":
    /*!*****************************************************************!*\
      !*** ./src/app/tabs/spots/spot-photos/spot-photos.component.ts ***!
      \*****************************************************************/

    /*! exports provided: SpotPhotosComponent */

    /***/
    function X330(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SpotPhotosComponent", function () {
        return SpotPhotosComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_spot_photos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./spot-photos.component.html */
      "jzXV");
      /* harmony import */


      var _spot_photos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./spot-photos.component.scss */
      "Jp7q");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SpotPhotosComponent = /*#__PURE__*/function () {
        function SpotPhotosComponent() {
          _classCallCheck(this, SpotPhotosComponent);
        }

        _createClass(SpotPhotosComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SpotPhotosComponent;
      }();

      SpotPhotosComponent.ctorParameters = function () {
        return [];
      };

      SpotPhotosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-spot-photos',
        template: _raw_loader_spot_photos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_spot_photos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SpotPhotosComponent);
      /***/
    },

    /***/
    "fTpC":
    /*!********************************************!*\
      !*** ./src/app/tabs/spots/spots.module.ts ***!
      \********************************************/

    /*! exports provided: SpotsPageModule */

    /***/
    function fTpC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SpotsPageModule", function () {
        return SpotsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _spots_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./spots-routing.module */
      "7t31");
      /* harmony import */


      var _spots_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./spots.page */
      "S/fo");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../shared/shared.module */
      "PCNd");
      /* harmony import */


      var _spot_photos_spot_photos_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./spot-photos/spot-photos.component */
      "X330");
      /* harmony import */


      var _modal_add_spot_modal_add_spot_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./modal-add-spot/modal-add-spot.component */
      "q9IE");

      var SpotsPageModule = function SpotsPageModule() {
        _classCallCheck(this, SpotsPageModule);
      };

      SpotsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"], _spots_routing_module__WEBPACK_IMPORTED_MODULE_2__["SpotsPageRoutingModule"]],
        declarations: [_spots_page__WEBPACK_IMPORTED_MODULE_3__["SpotsPage"], _spot_photos_spot_photos_component__WEBPACK_IMPORTED_MODULE_5__["SpotPhotosComponent"], _modal_add_spot_modal_add_spot_component__WEBPACK_IMPORTED_MODULE_6__["ModalAddSpotComponent"]]
      })], SpotsPageModule);
      /***/
    },

    /***/
    "jdHS":
    /*!**********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/spots/spots.page.html ***!
      \**********************************************************************************/

    /*! exports provided: default */

    /***/
    function jdHS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-mail-layout [isNeedHeightWithTabsAndHeader]=\"true\">\n    <ng-container *ngIf=\"true; else emptyBlock\">\n        <header class=\"d-flex ion-justify-content-between ion-align-items-center\">\n            <ion-text color=\"light\" class=\"title-20\">My spots</ion-text>\n            <ion-button fill=\"solid\" (click)=\"openAddSpotModal()\" class=\"add-btn\">\n                <ion-text color=\"secondary\" class=\"text-16\">Add new</ion-text>\n            </ion-button>\n        </header>\n        <div class=\"d-flex flex-column\">\n            <div *ngFor=\"let spot of [1, 2, 5]\" class=\"mb20\">\n                <app-spot-photos></app-spot-photos>\n            </div>\n\n        </div>\n    </ng-container>\n    <ng-template #emptyBlock>\n        <div class=\"d-flex h100percent\">\n            <div class=\"d-flex flex-column ion-align-items-center ion-justify-content-center\">\n                <ion-text color=\"light\" class=\"title-34\">Nothing in here…</ion-text>\n                <ion-text color=\"tertiary\" class=\"text-15 empty-text\">Want to add some news spots? Easy. Just click the\n                    button below and fill in the details\n                </ion-text>\n                <ion-button color=\"success\" expand=\"block\" class=\"w100percent\" (click)=\"openAddSpotModal()\">\n                    Add new spot\n                </ion-button>\n            </div>\n        </div>\n    </ng-template>\n</app-mail-layout>\n";
      /***/
    },

    /***/
    "jzXV":
    /*!*********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/spots/spot-photos/spot-photos.component.html ***!
      \*********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function jzXV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-grid class=\"p0\">\n  <ion-row>\n    <ion-col size=\"9\" class=\"p0\">\n      <div class=\"main-photo mr8\" [ngStyle]=\"{'background-image':'url(assets/images/my_spots/1.png)'}\"></div>\n    </ion-col>\n    <ion-col size=\"3\" class=\"p0\">\n      <div class=\"d-flex h100percent flex-column ion-justify-content-between\">\n        <div class=\"small-photo\" [ngStyle]=\"{'background-image':'url(assets/images/my_spots/2.png)'}\"></div>\n        <div class=\"small-photo\" [ngStyle]=\"{'background-image':'url(assets/images/my_spots/2.png)'}\">\n          <div class=\"last\">\n            <ion-text color=\"light\" class=\"title-20\">6</ion-text>\n          </div>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-text color=\"light\" class=\"text-16-500\">Isleham Skatepark East</ion-text>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n";
      /***/
    },

    /***/
    "q9IE":
    /*!***********************************************************************!*\
      !*** ./src/app/tabs/spots/modal-add-spot/modal-add-spot.component.ts ***!
      \***********************************************************************/

    /*! exports provided: ModalAddSpotComponent */

    /***/
    function q9IE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ModalAddSpotComponent", function () {
        return ModalAddSpotComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_modal_add_spot_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./modal-add-spot.component.html */
      "Cpw/");
      /* harmony import */


      var _modal_add_spot_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./modal-add-spot.component.scss */
      "JE4V");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var ModalAddSpotComponent = /*#__PURE__*/function () {
        function ModalAddSpotComponent(_modalController) {
          _classCallCheck(this, ModalAddSpotComponent);

          this._modalController = _modalController;
          this.checkboxes = [{
            name: 'Curb',
            checked: true,
            value: 'Curb'
          }, {
            name: 'Rail',
            checked: false,
            value: 'Rail'
          }, {
            name: 'Steps',
            checked: true,
            value: 'Steps'
          }, {
            name: 'Other',
            checked: false,
            value: 'Other'
          }];
        }

        _createClass(ModalAddSpotComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "closeModal",
          value: function closeModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._modalController.dismiss();

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return ModalAddSpotComponent;
      }();

      ModalAddSpotComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }];
      };

      ModalAddSpotComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-add-spot',
        template: _raw_loader_modal_add_spot_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_add_spot_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ModalAddSpotComponent);
      /***/
    }
  }]);
})();
//# sourceMappingURL=spots-spots-module-es5.js.map