(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-congradulations-congradulations-module"], {
    /***/
    "8KOB":
    /*!****************************************************************************!*\
      !*** ./src/app/pages/game/pages/congradulations/congradulations.page.scss ***!
      \****************************************************************************/

    /*! exports provided: default */

    /***/
    function KOB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-fab-button {\n  border: 1px solid var(--theme-divisor-color);\n  border-radius: 50%;\n}\n\n.trick {\n  height: 100%;\n  box-sizing: border-box;\n  padding-top: 140px;\n  background-image: url(\"/assets/images/congradulations.png\");\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n}\n\n.buttons {\n  margin-top: auto;\n  margin-bottom: 40px;\n}\n\nion-avatar {\n  width: 80px;\n  height: 80px;\n  margin-top: 100px;\n}\n\n.game-btn {\n  width: 140px;\n  height: 177px;\n  border-radius: var(--theme-base-border-radius);\n}\n\n.game-btn:first-of-type {\n  margin-right: 28px;\n}\n\n.game-btn ion-icon {\n  width: 94px;\n  height: 55px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGNvbmdyYWR1bGF0aW9ucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw0Q0FBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUVBLDJEQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0FBQUY7O0FBR0E7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBQUY7O0FBR0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBQUY7O0FBR0E7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDhDQUFBO0FBQUY7O0FBRUU7RUFDRSxrQkFBQTtBQUFKOztBQUdFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFESiIsImZpbGUiOiJjb25ncmFkdWxhdGlvbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWZhYi1idXR0b24ge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLXRoZW1lLWRpdmlzb3ItY29sb3IpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuLnRyaWNrIHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBwYWRkaW5nLXRvcDogMTQwcHg7XHJcblxyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWFnZXMvY29uZ3JhZHVsYXRpb25zLnBuZycpO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5idXR0b25zIHtcclxuICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbn1cclxuXHJcbmlvbi1hdmF0YXIge1xyXG4gIHdpZHRoOiA4MHB4O1xyXG4gIGhlaWdodDogODBweDtcclxuICBtYXJnaW4tdG9wOiAxMDBweDtcclxufVxyXG5cclxuLmdhbWUtYnRuIHtcclxuICB3aWR0aDogMTQwcHg7XHJcbiAgaGVpZ2h0OiAxNzdweDtcclxuICBib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxuICAmOmZpcnN0LW9mLXR5cGUge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAyOHB4O1xyXG4gIH1cclxuXHJcbiAgaW9uLWljb24ge1xyXG4gICAgd2lkdGg6IDk0cHg7XHJcbiAgICBoZWlnaHQ6IDU1cHg7XHJcbiAgfVxyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "E4ZI":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/pages/congradulations/congradulations.page.html ***!
      \******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function E4ZI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content color=\"primary\">\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"stopGame()\">\n      <ion-icon name=\"power-outline\" color=\"danger\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <div class=\"d-flex flex-column ion-align-items-center ion-justify-content-start trick\">\n    <ion-text  color=\"secondary\" class=\"title-34\">Congradulations</ion-text>\n    <ion-avatar>\n      <img src=\"../../../../../assets/images/person.png\">\n    </ion-avatar>\n\n    <ion-text color=\"tertiary\" class=\"mt12 text-16\">Bobby Mount</ion-text>\n    <div class=\"d-flex ion-justify-content-between buttons\">\n\n      <ion-button class=\"game-btn\" color=\"success\" (click)=\"playAgain()\">\n        <div class=\"d-flex flex-column ion-justify-content-center\">\n          <ion-icon src=\"assets/images/svg-icons/again.svg\"></ion-icon>\n          <ion-text class=\"title-20 mt12\">Play</ion-text>\n          <ion-text class=\"title-20 mt4\">Again</ion-text>\n        </div>\n      </ion-button>\n\n      <ion-button class=\"game-btn\" color=\"dark\" (click)=\"openLeaderboard()\">\n        <div class=\"d-flex flex-column ion-justify-content-center\">\n          <ion-icon src=\"assets/images/svg-icons/leaderboard.svg\"></ion-icon>\n          <ion-text class=\"title-20 mt12\">Leader</ion-text>\n          <ion-text class=\"title-20 mt4\">board</ion-text>\n        </div>\n      </ion-button>\n\n    </div>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "fd/Q":
    /*!**************************************************************************!*\
      !*** ./src/app/pages/game/pages/congradulations/congradulations.page.ts ***!
      \**************************************************************************/

    /*! exports provided: CongradulationsPage */

    /***/
    function fdQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CongradulationsPage", function () {
        return CongradulationsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_congradulations_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./congradulations.page.html */
      "E4ZI");
      /* harmony import */


      var _congradulations_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./congradulations.page.scss */
      "8KOB");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../../tabs/tabs.enum */
      "162u");
      /* harmony import */


      var _game_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../game-routes */
      "2DP2");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _modals_modal_leaderboard_modal_leaderboard_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../modals/modal-leaderboard/modal-leaderboard.component */
      "yVue");

      var CongradulationsPage = /*#__PURE__*/function () {
        function CongradulationsPage(_router, _modalController) {
          _classCallCheck(this, CongradulationsPage);

          this._router = _router;
          this._modalController = _modalController;
        }

        _createClass(CongradulationsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "stopGame",
          value: function stopGame() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__["tabsEnum2RouteMapping"].GAME]);

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "playAgain",
          value: function playAgain() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._router.navigate(['/', _game_routes__WEBPACK_IMPORTED_MODULE_6__["GameRoutes"].ROOT, _game_routes__WEBPACK_IMPORTED_MODULE_6__["GameRoutes"].TRICK]);

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "openLeaderboard",
          value: function openLeaderboard() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var modal;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this._modalController.create({
                        component: _modals_modal_leaderboard_modal_leaderboard_component__WEBPACK_IMPORTED_MODULE_8__["ModalLeaderboardComponent"],
                        cssClass: 'modal-leaderboard'
                      });

                    case 2:
                      modal = _context3.sent;
                      _context3.next = 5;
                      return modal.present();

                    case 5:
                      return _context3.abrupt("return", _context3.sent);

                    case 6:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }]);

        return CongradulationsPage;
      }();

      CongradulationsPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"]
        }];
      };

      CongradulationsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-congradulations',
        template: _raw_loader_congradulations_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_congradulations_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CongradulationsPage);
      /***/
    },

    /***/
    "vwCh":
    /*!************************************************************************************!*\
      !*** ./src/app/pages/game/pages/congradulations/congradulations-routing.module.ts ***!
      \************************************************************************************/

    /*! exports provided: CongradulationsPageRoutingModule */

    /***/
    function vwCh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CongradulationsPageRoutingModule", function () {
        return CongradulationsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _congradulations_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./congradulations.page */
      "fd/Q");

      var routes = [{
        path: '',
        component: _congradulations_page__WEBPACK_IMPORTED_MODULE_3__["CongradulationsPage"]
      }];

      var CongradulationsPageRoutingModule = function CongradulationsPageRoutingModule() {
        _classCallCheck(this, CongradulationsPageRoutingModule);
      };

      CongradulationsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CongradulationsPageRoutingModule);
      /***/
    },

    /***/
    "xijz":
    /*!****************************************************************************!*\
      !*** ./src/app/pages/game/pages/congradulations/congradulations.module.ts ***!
      \****************************************************************************/

    /*! exports provided: CongradulationsPageModule */

    /***/
    function xijz(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CongradulationsPageModule", function () {
        return CongradulationsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _congradulations_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./congradulations-routing.module */
      "vwCh");
      /* harmony import */


      var _congradulations_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./congradulations.page */
      "fd/Q");

      var CongradulationsPageModule = function CongradulationsPageModule() {
        _classCallCheck(this, CongradulationsPageModule);
      };

      CongradulationsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _congradulations_routing_module__WEBPACK_IMPORTED_MODULE_5__["CongradulationsPageRoutingModule"]],
        declarations: [_congradulations_page__WEBPACK_IMPORTED_MODULE_6__["CongradulationsPage"]]
      })], CongradulationsPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-congradulations-congradulations-module-es5.js.map