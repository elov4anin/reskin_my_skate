(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "NKrf":
/*!************************************************!*\
  !*** ./src/app/pages/auth/login/login.page.ts ***!
  \************************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.page.html */ "tvH6");
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss */ "faZD");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth-routes.enum */ "mKaM");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../auth.service */ "zbnG");
/* harmony import */ var _shared_configs_response_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/configs/response.constants */ "N7aL");
/* harmony import */ var _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/helpers/toast-notification.service */ "b3vI");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../shared/enums/Storage.enum */ "03gG");
/* harmony import */ var _shared_classes_validation_messages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/classes/validation-messages */ "AEGu");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ "kU1M");















let LoginPage = class LoginPage {
    constructor(_router, _authService, _toast, _coreStore) {
        this._router = _router;
        this._authService = _authService;
        this._toast = _toast;
        this._coreStore = _coreStore;
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].email]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(40),
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/)
            ]),
        });
        this.isReqSending = false;
        this.validationMessages = _shared_classes_validation_messages__WEBPACK_IMPORTED_MODULE_12__["VALIDATION_MESSAGES"];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_13__["Subject"]();
    }
    ngOnInit() {
    }
    login() {
        this.isReqSending = true;
        this._authService.login(this.form.value)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_14__["takeUntil"])(this.componentDestroyed))
            .subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isReqSending = false;
            if (res.response_code === _shared_configs_response_constants__WEBPACK_IMPORTED_MODULE_8__["RESPONSE_CODES"].SUCCESS) {
                yield this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_11__["StorageEnum"].LOGGEDIN, true);
                yield this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_11__["StorageEnum"].PROFILE, res.user);
                yield this._router.navigate(['/']);
            }
            else {
                yield this._toast.error(res.response_msg);
            }
        }));
    }
    openRegistration() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].ROOT, _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].REG]);
        });
    }
    openForgot($event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].ROOT, _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].FORGOT_PASS]);
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] },
    { type: _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_9__["ToastNotificationService"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_10__["CoreStore"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginPage);



/***/ }),

/***/ "aWET":
/*!**********************************************************!*\
  !*** ./src/app/pages/auth/login/login-routing.module.ts ***!
  \**********************************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "NKrf");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "faZD":
/*!**************************************************!*\
  !*** ./src/app/pages/auth/login/login.page.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  margin-top: 38px;\n}\n\nion-input {\n  margin-top: 12px;\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.apply-btn {\n  width: 100%;\n  max-width: 375px;\n  margin-right: auto;\n  margin-left: auto;\n  margin-top: 40px;\n}\n\nion-item {\n  --inner-padding-end: 0;\n  --inner-padding-bottom: var(--ion-margin);\n  margin-right: 5px;\n  --padding-start: 0;\n}\n\n.forgot-btn {\n  --padding-top: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  --padding-bottom: 0;\n  height: 1.3em;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0EseURBQUE7RUFDQSx1REFBQTtFQUNBLDBDQUFBO0VBQ0EsZ0NBQUE7RUFDQSw4QkFBQTtFQUNBLDhCQUFBO0VBQ0EsaUNBQUE7RUFDQSxnREFBQTtFQUNBLDhDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLHNCQUFBO0VBQ0EseUNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBQ0YiLCJmaWxlIjoibG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlciB7XHJcbiAgbWFyZ2luLXRvcDogMzhweDtcclxufVxyXG5cclxuaW9uLWlucHV0IHtcclxuICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1jb250cmFzdCkgIWltcG9ydGFudDtcclxuICAtLXBsYWNlaG9sZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKSAhaW1wb3J0YW50O1xyXG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCkgIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctZW5kOiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1ib3R0b246IDEwcHggIWltcG9ydGFudDtcclxuICAtLWJvcmRlci1yYWRpdXM6IHZhcigtLXRoZW1lLWJhc2UtYm9yZGVyLXJhZGl1cyk7XHJcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcclxufVxyXG5cclxuLmFwcGx5LWJ0biB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAzNzVweDtcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgbWFyZ2luLXRvcDogNDBweDtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogdmFyKC0taW9uLW1hcmdpbik7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG59XHJcblxyXG4uZm9yZ290LWJ0biB7XHJcbiAgLS1wYWRkaW5nLXRvcDogMDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAtLXBhZGRpbmctYm90dG9tOiAwO1xyXG4gIGhlaWdodDogMS4zZW07XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "qdgq":
/*!**************************************************!*\
  !*** ./src/app/pages/auth/login/login.module.ts ***!
  \**************************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login-routing.module */ "aWET");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "NKrf");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/shared.module */ "PCNd");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");






let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_2__["LoginPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"]
        ],
        declarations: [
            _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"],
        ]
    })
], LoginPageModule);



/***/ }),

/***/ "tvH6":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/auth/login/login.page.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout [isNeeBackBtn]=\"false\" [footerSlot]=\"footer\" [isNeedHeightWithTabsAndHeader]=\"true\">\n    <header class=\"d-flex ion-justify-content-between ion-align-items-center ion-margin-bottom header\">\n        <ion-text color=\"light\" class=\"title-20\">Login</ion-text>\n    </header>\n\n    <form [formGroup]=\"form\" class=\"ion-margin-top\">\n        <ion-item color=\"primary\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Email</ion-text>\n            </ion-label>\n            <ion-input placeholder=\"Type here\" formControlName=\"email\" type=\"email\"\n                       [ngClass]=\"{'invalid-input': form.get('email').touched && form.get('email').invalid}\"\n            ></ion-input>\n            <div class=\"validation-errors\">\n                <ng-container *ngFor=\"let validation of validationMessages.email\">\n                    <div class=\"error-message\"\n                         *ngIf=\"form.get('email').hasError(validation.type) && (form.get('email').dirty || form.get('email').touched)\"\n                    >\n                        {{ validation.message }}\n                    </div>\n                </ng-container>\n            </div>\n        </ion-item>\n\n        <ion-item color=\"primary\">\n            <ion-label position=\"stacked\">\n                <div class=\"d-flex ion-justify-content-between\">\n                    <ion-text class=\"text-16\" color=\"light\">Password</ion-text>\n                    <ion-button class=\"forgot-btn\" fill=\"clear\" color=\"secondary\"(click)=\"openForgot($event)\">\n                        <ion-text class=\"text-16\" color=\"secondary\" >Forgot password</ion-text>\n                    </ion-button>\n\n                </div>\n            </ion-label>\n            <ion-input placeholder=\"Type here\" formControlName=\"password\" type=\"password\" autocomplete=\"off\"\n                       [minlength]=\"8\" [maxlength]=\"40\"\n                       [ngClass]=\"{'invalid-input': form.get('password').touched && form.get('password').invalid}\"\n            ></ion-input>\n            <div class=\"validation-errors\">\n                <ng-container *ngFor=\"let validation of validationMessages.password\">\n                    <div class=\"error-message\"\n                         *ngIf=\"form.get('password').hasError(validation.type) && (form.get('password').dirty || form.get('password').touched)\"\n                    >\n                        {{ validation.message }}\n                    </div>\n                </ng-container>\n            </div>\n        </ion-item>\n\n        <ion-button [disabled]=\"form.invalid\" (click)=\"login()\" class=\"mb12 apply-btn\" fill=\"solid\" color=\"success\" expand=\"block\">\n            <ng-container *ngIf=\"isReqSending; else textBlock\">\n                <ion-spinner name=\"lines-small\"></ion-spinner>Sending...\n            </ng-container>\n            <ng-template #textBlock>\n                Log in\n            </ng-template>\n        </ion-button>\n    </form>\n\n    <ng-template #footer>\n        <ion-footer>\n            <ion-toolbar color=\"primary\">\n                <ion-text class=\"text-15 d-block ion-text-center\" color=\"light\">\n                    Don’t have an account?\n                    <ion-text (click)=\"openRegistration()\" color=\"secondary\">Sign up</ion-text>\n                </ion-text>\n            </ion-toolbar>\n        </ion-footer>\n    </ng-template>\n\n</app-mail-layout>\n");

/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map