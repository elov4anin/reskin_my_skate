(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["store-detail-store-detail-module"], {
    /***/
    "4Ft+":
    /*!*****************************************************************!*\
      !*** ./src/app/tabs/stores/store-detail/store-detail.module.ts ***!
      \*****************************************************************/

    /*! exports provided: StoreDetailPageModule */

    /***/
    function Ft(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StoreDetailPageModule", function () {
        return StoreDetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _store_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./store-detail-routing.module */
      "Pz/F");
      /* harmony import */


      var _store_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./store-detail.page */
      "PNMb");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../shared/shared.module */
      "PCNd");

      var StoreDetailPageModule = function StoreDetailPageModule() {
        _classCallCheck(this, StoreDetailPageModule);
      };

      StoreDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"], _store_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__["StoreDetailPageRoutingModule"]],
        declarations: [_store_detail_page__WEBPACK_IMPORTED_MODULE_3__["StoreDetailPage"]]
      })], StoreDetailPageModule);
      /***/
    },

    /***/
    "PNMb":
    /*!***************************************************************!*\
      !*** ./src/app/tabs/stores/store-detail/store-detail.page.ts ***!
      \***************************************************************/

    /*! exports provided: StoreDetailPage */

    /***/
    function PNMb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StoreDetailPage", function () {
        return StoreDetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_store_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./store-detail.page.html */
      "kfUY");
      /* harmony import */


      var _store_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./store-detail.page.scss */
      "tG0L");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../shared/store/core.store */
      "8e7N");
      /* harmony import */


      var _shared_store_selectors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../shared/store/selectors */
      "OSWL");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _shared_interfaces_store_interfaces__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../../shared/interfaces/store.interfaces */
      "oaM1");
      /* harmony import */


      var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../../shared/enums/Storage.enum */
      "03gG");
      /* harmony import */


      var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @ionic-native/in-app-browser/ngx */
      "m/P+");

      var StoreDetailPage = /*#__PURE__*/function () {
        function StoreDetailPage(_location, _coreStore, _iab) {
          _classCallCheck(this, StoreDetailPage);

          this._location = _location;
          this._coreStore = _coreStore;
          this._iab = _iab;
          this.store = new _shared_interfaces_store_interfaces__WEBPACK_IMPORTED_MODULE_9__["Store"]();
          this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_8__["Subject"]();
        }

        _createClass(StoreDetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this._coreStore.getValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_10__["StorageEnum"].SELECTED_STORE).then(function (store) {
              return _this.setStore(store);
            });

            this._coreStore.select(_shared_store_selectors__WEBPACK_IMPORTED_MODULE_6__["selectStore"]).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["takeUntil"])(this.componentDestroyed)).subscribe(function (store) {
              return _this.setStore(store);
            });
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            this.componentDestroyed.next();
            this.componentDestroyed.unsubscribe();
          }
        }, {
          key: "back",
          value: function back() {
            this._location.back();
          }
        }, {
          key: "setStore",
          value: function setStore(store) {
            if (store) {
              this.store = store;
            }
          }
        }, {
          key: "openBrowser",
          value: function openBrowser() {
            this._iab.create(this.store.website);
          }
        }]);

        return StoreDetailPage;
      }();

      StoreDetailPage.ctorParameters = function () {
        return [{
          type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"]
        }, {
          type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_5__["CoreStore"]
        }, {
          type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_11__["InAppBrowser"]
        }];
      };

      StoreDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-store-detail',
        template: _raw_loader_store_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_store_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], StoreDetailPage);
      /***/
    },

    /***/
    "Pz/F":
    /*!*************************************************************************!*\
      !*** ./src/app/tabs/stores/store-detail/store-detail-routing.module.ts ***!
      \*************************************************************************/

    /*! exports provided: StoreDetailPageRoutingModule */

    /***/
    function PzF(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StoreDetailPageRoutingModule", function () {
        return StoreDetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _store_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./store-detail.page */
      "PNMb");

      var routes = [{
        path: '',
        component: _store_detail_page__WEBPACK_IMPORTED_MODULE_3__["StoreDetailPage"]
      }];

      var StoreDetailPageRoutingModule = function StoreDetailPageRoutingModule() {
        _classCallCheck(this, StoreDetailPageRoutingModule);
      };

      StoreDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], StoreDetailPageRoutingModule);
      /***/
    },

    /***/
    "kfUY":
    /*!*******************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/stores/store-detail/store-detail.page.html ***!
      \*******************************************************************************************************/

    /*! exports provided: default */

    /***/
    function kfUY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-mail-layout\n        [isNeedRightPadding]=\"false\"\n        [isNeedLeftPadding]=\"false\"\n        [isNotNeedPaddingTopHeader]=\"true\"\n>\n    <ion-grid class=\"ion-padding-start ion-padding-end\">\n        <ion-row>\n            <ion-col class=\"p0\">\n                <ion-icon\n                        class=\"icon-as-btn\"\n                        color=\"secondary\"\n                        name=\"arrow-back-outline\"\n                        size=\"large\"\n                        (click)=\"back()\"\n                ></ion-icon>\n            </ion-col>\n        </ion-row>\n        <ion-row class=\"mt16\">\n            <ion-col class=\"p0\">\n                <ion-text color=\"light\" class=\"title-20\">{{store.name}}</ion-text>\n            </ion-col>\n        </ion-row>\n        <ion-row class=\"mt20\">\n            <ion-col class=\"p0\">\n                <ion-img src=\"assets/images/store.png\"></ion-img>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n    <div class=\"divisor mt20 mb20\"></div>\n    <ion-list>\n        <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end mb16\">\n            <div class=\"icon-slot\" slot=\"start\">\n                <ion-icon src=\"assets/images/svg-icons/explore-24px.svg\"></ion-icon>\n            </div>\n            <div class=\"d-flex flex-column\">\n                <ion-label >\n                    <ion-text class=\"text-16\" color=\"light\">{{store.address_1}}</ion-text>\n                </ion-label>\n                <ion-text class=\"text-12\" color=\"tertiary\">{{store.city}}{{store.postcode ? ', ' + store.postcode: ''}}</ion-text>\n            </div>\n        </ion-item>\n        <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end mb16\">\n            <div class=\"icon-slot\" slot=\"start\">\n                <ion-icon src=\"assets/images/svg-icons/email-24px.svg\"></ion-icon>\n            </div>\n            <div class=\"d-flex flex-column\">\n                <ion-label >\n                    <ion-text class=\"text-16\" color=\"light\">\n                        <a [href]=\"'mailto:' + store.email\" target=\"_blank\">{{store.email}}</a>\n                    </ion-text>\n                </ion-label>\n            </div>\n        </ion-item>\n        <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end mb16\">\n            <div class=\"icon-slot\" slot=\"start\">\n                <ion-icon src=\"assets/images/svg-icons/call-24px.svg\"></ion-icon>\n            </div>\n            <ion-label>\n                <a class=\"text-16\" [href]=\"'tel:' + store.phone\" target=\"_blank\">{{store.phone}}</a>\n            </ion-label>\n        </ion-item>\n        <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end\">\n            <div class=\"icon-slot\" slot=\"start\">\n                <ion-icon src=\"assets/images/svg-icons/announcement-24px.svg\"></ion-icon>\n            </div>\n            <div class=\"d-flex flex-column\">\n                <ion-label >\n                    <ion-text class=\"text-16\" color=\"light\">SALE & Holiday work hours</ion-text>\n                </ion-label>\n                <ion-text class=\"text-12\" color=\"tertiary\">We want to inform you that our store will be open from 10AM to 4PM on December 24th and 31st.</ion-text>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-button\n            color=\"success\"\n            expand=\"block\"\n            class=\"ion-margin-top ion-padding-start ion-padding-end\"\n            (click)=\"openBrowser()\"\n    >\n        <ion-text class=\"text-15-500\">Visit Website</ion-text>\n    </ion-button>\n\n</app-mail-layout>\n";
      /***/
    },

    /***/
    "oaM1":
    /*!*******************************************************!*\
      !*** ./src/app/shared/interfaces/store.interfaces.ts ***!
      \*******************************************************/

    /*! exports provided: Store */

    /***/
    function oaM1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Store", function () {
        return Store;
      });

      var Store = function Store() {
        _classCallCheck(this, Store);

        this.id = '';
        this.name = '';
        this.city = '';
        this.address_1 = '';
        this.address_2 = '';
        this.address_3 = '';
        this.postcode = '';
        this.website = '';
        this.email = '';
        this.phone = '';
      };
      /***/

    },

    /***/
    "tG0L":
    /*!*****************************************************************!*\
      !*** ./src/app/tabs/stores/store-detail/store-detail.page.scss ***!
      \*****************************************************************/

    /*! exports provided: default */

    /***/
    function tG0L(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-img {\n  height: 180px;\n}\n\nion-list {\n  background: var(--ion-color-primary);\n}\n\n.icon-slot {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 40px;\n  height: 40px;\n  background: rgba(var(--ion-color-secondary-rgb), 0.1);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.icon-slot ion-icon {\n  font-size: 24px;\n}\n\na {\n  color: var(--ion-color-light);\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcc3RvcmUtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7QUFDRjs7QUFFQTtFQUNFLG9DQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBRUEscURBQUE7RUFDQSw4Q0FBQTtBQUFGOztBQUVFO0VBQ0UsZUFBQTtBQUFKOztBQUdBO0VBQ0UsNkJBQUE7RUFDQSxxQkFBQTtBQUFGIiwiZmlsZSI6InN0b3JlLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW1nIHtcclxuICBoZWlnaHQ6IDE4MHB4O1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG4uaWNvbi1zbG90IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG5cclxuICBiYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktcmdiKSwgMC4xKTtcclxuICBib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxuICBpb24taWNvbiB7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgfVxyXG59XHJcbmEge1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG4iXX0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=store-detail-store-detail-module-es5.js.map