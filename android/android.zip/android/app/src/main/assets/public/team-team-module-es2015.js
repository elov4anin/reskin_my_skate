(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["team-team-module"],{

/***/ "6eVv":
/*!*************************************************!*\
  !*** ./src/app/tabs/team/team-segments.enum.ts ***!
  \*************************************************/
/*! exports provided: TeamSegmentsEnum, teamSegmentsEnum2LabelMapping */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamSegmentsEnum", function() { return TeamSegmentsEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teamSegmentsEnum2LabelMapping", function() { return teamSegmentsEnum2LabelMapping; });
var TeamSegmentsEnum;
(function (TeamSegmentsEnum) {
    TeamSegmentsEnum["NEWS"] = "NEWS";
    TeamSegmentsEnum["EVENTS"] = "EVENTS";
})(TeamSegmentsEnum || (TeamSegmentsEnum = {}));
const teamSegmentsEnum2LabelMapping = {
    NEWS: 'News',
    EVENTS: 'Events',
};


/***/ }),

/***/ "8IV7":
/*!***********************************************************************************!*\
  !*** ./src/app/tabs/team/components/team-news-list/team-news-list.component.scss ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card {\n  box-shadow: none;\n  margin-inline: 0;\n}\n\nion-card-header {\n  padding-top: 8px;\n  padding-bottom: 0;\n  padding-inline: 0;\n}\n\nion-thumbnail {\n  width: 100%;\n  height: 160px;\n  --border-radius: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHRlYW0tbmV3cy1saXN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBRUY7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBRUYiLCJmaWxlIjoidGVhbS1uZXdzLWxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XHJcbiAgYm94LXNoYWRvdzogbm9uZTtcclxuICBtYXJnaW4taW5saW5lOiAwO1xyXG59XHJcbmlvbi1jYXJkLWhlYWRlciB7XHJcbiAgcGFkZGluZy10b3A6IDhweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMDtcclxuICBwYWRkaW5nLWlubGluZTogMFxyXG59XHJcblxyXG5pb24tdGh1bWJuYWlsIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDE2MHB4O1xyXG4gIC0tYm9yZGVyLXJhZGl1czogOHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "8zDS":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/team/team.page.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout class=\"mainLayoutHeight124\">\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center ion-margin-bottom\">\n    <ion-text color=\"light\" class=\"title-20\">Roll with Team GB</ion-text>\n\n  </header>\n\n  <ion-segment (ionChange)=\"segmentChanged($event)\" mode=\"md\"  [(ngModel)]=\"selectedSegment\" color=\"secondary\">\n    <ion-segment-button *ngFor=\"let s of segments\" [value]=\"s\" >\n      <ion-label>\n        <ion-text class=\"text-16-500 text-no-transform\">{{segmentsEnum2LabelMapping[s]}}</ion-text>\n      </ion-label>\n    </ion-segment-button>\n  </ion-segment>\n  <ng-container *ngIf=\"selectedSegment === segmentsEnum.NEWS\">\n    <app-team-news-list></app-team-news-list>\n  </ng-container>\n  <ng-container *ngIf=\"selectedSegment === segmentsEnum.EVENTS\">\n    <app-team-event-list></app-team-event-list>\n  </ng-container>\n</app-mail-layout>\n");

/***/ }),

/***/ "99M3":
/*!*********************************************************************************!*\
  !*** ./src/app/tabs/team/components/team-news-list/team-news-list.component.ts ***!
  \*********************************************************************************/
/*! exports provided: TeamNewsListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamNewsListComponent", function() { return TeamNewsListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_team_news_list_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./team-news-list.component.html */ "nA5K");
/* harmony import */ var _team_news_list_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./team-news-list.component.scss */ "8IV7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../shared/services/team.service */ "mqDS");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../shared/enums/Storage.enum */ "03gG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../tabs.enum */ "162u");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ "TEn/");












let TeamNewsListComponent = class TeamNewsListComponent {
    constructor(_teamService, _coreStore, _router) {
        this._teamService = _teamService;
        this._coreStore = _coreStore;
        this._router = _router;
        this.items = [];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
        this.page = 0;
        this.breakLoadMore = false;
    }
    ngOnInit() {
        this.getNews();
    }
    getNews() {
        this._teamService.getFeedList(this.page).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["takeUntil"])(this.componentDestroyed))
            .subscribe(res => {
            if (res.feed.length === 0) {
                this.breakLoadMore = true;
                this.infiniteScroll.complete().then();
            }
            this.items = this.items.concat(res.feed);
            this.page = this.page + 1;
        });
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    openNews(item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_8__["StorageEnum"].SELECTED_NEWS, item);
            yield this._router.navigate(['/', _tabs_enum__WEBPACK_IMPORTED_MODULE_10__["TABS_MAIN_ROUTE"], _tabs_enum__WEBPACK_IMPORTED_MODULE_10__["tabsEnum2RouteMapping"].NEWS, item.id]);
        });
    }
    loadData($event) {
        if (this.breakLoadMore) {
            $event.target.disabled = true;
            return;
        }
        else {
            this.getNews();
        }
    }
};
TeamNewsListComponent.ctorParameters = () => [
    { type: _shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__["TeamService"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__["CoreStore"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"] }
];
TeamNewsListComponent.propDecorators = {
    infiniteScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_11__["IonInfiniteScroll"],] }]
};
TeamNewsListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-team-news-list',
        template: _raw_loader_team_news_list_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_team_news_list_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TeamNewsListComponent);



/***/ }),

/***/ "BnsO":
/*!*************************************************************************************!*\
  !*** ./src/app/tabs/team/components/team-event-list/team-event-list.component.scss ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0ZWFtLWV2ZW50LWxpc3QuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "KrKz":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/team/components/team-event-list/team-event-list.component.html ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"events.length > 0; else emptyBlock\">\n    <app-event *ngFor=\"let item of events;\" [event]=\"events\"></app-event>\n</ng-container>\n<ng-template #emptyBlock>\n    <ion-text color=\"tertiary\" class=\"empty-title\">No events yet</ion-text>\n</ng-template>\n\n<ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n    <ion-infinite-scroll-content\n            loadingSpinner=\"bubbles\"\n            loadingText=\"Loading more...\"\n    >\n    </ion-infinite-scroll-content>\n</ion-infinite-scroll>\n");

/***/ }),

/***/ "QiPM":
/*!******************************************!*\
  !*** ./src/app/tabs/team/team.module.ts ***!
  \******************************************/
/*! exports provided: TeamPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamPageModule", function() { return TeamPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _team_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./team-routing.module */ "wIx9");
/* harmony import */ var _team_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./team.page */ "nmX6");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/shared.module */ "PCNd");
/* harmony import */ var _components_team_event_list_team_event_list_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/team-event-list/team-event-list.component */ "VXfP");
/* harmony import */ var _components_team_news_list_team_news_list_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/team-news-list/team-news-list.component */ "99M3");







let TeamPageModule = class TeamPageModule {
};
TeamPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _team_routing_module__WEBPACK_IMPORTED_MODULE_2__["TeamPageRoutingModule"]
        ],
        declarations: [
            _team_page__WEBPACK_IMPORTED_MODULE_3__["TeamPage"],
            _components_team_news_list_team_news_list_component__WEBPACK_IMPORTED_MODULE_6__["TeamNewsListComponent"],
            _components_team_event_list_team_event_list_component__WEBPACK_IMPORTED_MODULE_5__["TeamEventListComponent"],
        ]
    })
], TeamPageModule);



/***/ }),

/***/ "VXfP":
/*!***********************************************************************************!*\
  !*** ./src/app/tabs/team/components/team-event-list/team-event-list.component.ts ***!
  \***********************************************************************************/
/*! exports provided: TeamEventListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamEventListComponent", function() { return TeamEventListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_team_event_list_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./team-event-list.component.html */ "KrKz");
/* harmony import */ var _team_event_list_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./team-event-list.component.scss */ "BnsO");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../shared/services/team.service */ "mqDS");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");








let TeamEventListComponent = class TeamEventListComponent {
    constructor(_teamService) {
        this._teamService = _teamService;
        this.events = [];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Subject"]();
        this.page = 0;
        this.breakLoadMore = false;
    }
    ngOnInit() {
        this.getEvents();
    }
    getEvents() {
        this._teamService.getEventList(this.page)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["takeUntil"])(this.componentDestroyed))
            .subscribe(res => {
            if (res.events.length === 0) {
                this.breakLoadMore = true;
                this.infiniteScroll.complete().then();
            }
            this.events = this.events.concat(res.events);
            this.page = this.page + 1;
        });
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    loadData($event) {
        if (this.breakLoadMore) {
            $event.target.disabled = true;
            return;
        }
        else {
            this.getEvents();
        }
    }
};
TeamEventListComponent.ctorParameters = () => [
    { type: _shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__["TeamService"] }
];
TeamEventListComponent.propDecorators = {
    infiniteScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonInfiniteScroll"],] }]
};
TeamEventListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-team-event-list',
        template: _raw_loader_team_event_list_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_team_event_list_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TeamEventListComponent);



/***/ }),

/***/ "nA5K":
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/team/components/team-news-list/team-news-list.component.html ***!
  \*************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-card *ngFor=\"let item of items\" color=\"primary\" (click)=\"openNews(item)\">\n    <div>\n        <ion-thumbnail>\n            <ion-img [src]=\"item.image\" [alt]=\"item.title\">\n            </ion-img>\n        </ion-thumbnail>\n        <!-- <iframe *ngIf=\"item.video\"\n                 width=\"375\"\n                 height=\"160\"\n                 src=\"https://www.youtube.com/embed/aHrn3-Cb3iM\"\n                 frameborder=\"0\"\n                 allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\"\n                 allowfullscreen></iframe>-->\n    </div>\n    <ion-card-header>\n        <ion-card-subtitle>\n            <ion-text color=\"tertiary\" class=\"text-12 text-no-transform\">{{ item.user.name }}</ion-text>\n        </ion-card-subtitle>\n        <ion-card-title class=\"text-16-500\">\n            <ion-text color=\"light\" class=\"text-16-500\">{{ item.title }}</ion-text>\n        </ion-card-title>\n    </ion-card-header>\n</ion-card>\n\n<ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n    <ion-infinite-scroll-content\n            loadingSpinner=\"bubbles\"\n            loadingText=\"Loading more...\"\n    >\n    </ion-infinite-scroll-content>\n</ion-infinite-scroll>\n");

/***/ }),

/***/ "nmX6":
/*!****************************************!*\
  !*** ./src/app/tabs/team/team.page.ts ***!
  \****************************************/
/*! exports provided: TeamPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamPage", function() { return TeamPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_team_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./team.page.html */ "8zDS");
/* harmony import */ var _team_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./team.page.scss */ "p4Ys");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _shared_helpers_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/helpers/utils */ "Ua8l");
/* harmony import */ var _team_segments_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./team-segments.enum */ "6eVv");






let TeamPage = class TeamPage {
    constructor() {
        this.segmentsEnum = _team_segments_enum__WEBPACK_IMPORTED_MODULE_5__["TeamSegmentsEnum"];
        this.segments = Object(_shared_helpers_utils__WEBPACK_IMPORTED_MODULE_4__["getEnumAsArray"])(_team_segments_enum__WEBPACK_IMPORTED_MODULE_5__["TeamSegmentsEnum"]);
        this.segmentsEnum2LabelMapping = _team_segments_enum__WEBPACK_IMPORTED_MODULE_5__["teamSegmentsEnum2LabelMapping"];
        this.selectedSegment = _team_segments_enum__WEBPACK_IMPORTED_MODULE_5__["TeamSegmentsEnum"].NEWS;
    }
    ngOnInit() {
    }
    segmentChanged($event) {
    }
};
TeamPage.ctorParameters = () => [];
TeamPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-team',
        template: _raw_loader_team_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_team_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TeamPage);



/***/ }),

/***/ "p4Ys":
/*!******************************************!*\
  !*** ./src/app/tabs/team/team.page.scss ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-segment-button {\n  color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0ZWFtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLDZCQUFBO0FBQUYiLCJmaWxlIjoidGVhbS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvL0B0b2RvIHRoaW5rICAtIHNlZ21lbnRzIGFzIGNvbXBvbmVudFxyXG5pb24tc2VnbWVudC1idXR0b24ge1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "wIx9":
/*!**************************************************!*\
  !*** ./src/app/tabs/team/team-routing.module.ts ***!
  \**************************************************/
/*! exports provided: TeamPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamPageRoutingModule", function() { return TeamPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _team_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./team.page */ "nmX6");




const routes = [
    {
        path: '',
        component: _team_page__WEBPACK_IMPORTED_MODULE_3__["TeamPage"]
    }
];
let TeamPageRoutingModule = class TeamPageRoutingModule {
};
TeamPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TeamPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=team-team-module-es2015.js.map