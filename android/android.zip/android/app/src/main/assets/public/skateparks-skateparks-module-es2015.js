(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["skateparks-skateparks-module"],{

/***/ "0iRA":
/*!******************************************************!*\
  !*** ./src/app/tabs/skateparks/skateparks.module.ts ***!
  \******************************************************/
/*! exports provided: SkateparksPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkateparksPageModule", function() { return SkateparksPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _skateparks_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skateparks-routing.module */ "M3Yx");
/* harmony import */ var _skateparks_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./skateparks.page */ "6Uey");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/shared.module */ "PCNd");
/* harmony import */ var _components_slider_block_slider_block_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/slider-block/slider-block.component */ "VGLg");
/* harmony import */ var _components_add_spot_board_add_spot_board_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/add-spot-board/add-spot-board.component */ "ObZ8");
/* harmony import */ var _components_add_skatepark_board_add_skatepark_board_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/add-skatepark-board/add-skatepark-board.component */ "V3xS");
/* harmony import */ var _modals_modal_add_skatepark_modal_add_skatepark_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./modals/modal-add-skatepark/modal-add-skatepark.component */ "g5Oi");
/* harmony import */ var _modals_modal_skatepark_confirm_modal_skatepark_confirm_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./modals/modal-skatepark-confirm/modal-skatepark-confirm.component */ "mJD3");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "3Pt+");











let SkateparksPageModule = class SkateparksPageModule {
};
SkateparksPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"],
            _skateparks_routing_module__WEBPACK_IMPORTED_MODULE_2__["SkateparksPageRoutingModule"],
        ],
        declarations: [
            _skateparks_page__WEBPACK_IMPORTED_MODULE_3__["SkateparksPage"],
            _components_slider_block_slider_block_component__WEBPACK_IMPORTED_MODULE_5__["SliderBlockComponent"],
            _components_add_spot_board_add_spot_board_component__WEBPACK_IMPORTED_MODULE_6__["AddSpotBoardComponent"],
            _components_add_skatepark_board_add_skatepark_board_component__WEBPACK_IMPORTED_MODULE_7__["AddSkateparkBoardComponent"],
            _modals_modal_add_skatepark_modal_add_skatepark_component__WEBPACK_IMPORTED_MODULE_8__["ModalAddSkateparkComponent"],
            _modals_modal_skatepark_confirm_modal_skatepark_confirm_component__WEBPACK_IMPORTED_MODULE_9__["ModalSkateparkConfirmComponent"],
        ]
    })
], SkateparksPageModule);



/***/ }),

/***/ "19/K":
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/dom/ajax.js ***!
  \********************************************************************/
/*! exports provided: ajax */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajax", function() { return ajax; });
/* harmony import */ var _AjaxObservable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AjaxObservable */ "Sj+y");

const ajax = (() => _AjaxObservable__WEBPACK_IMPORTED_MODULE_0__["AjaxObservable"].create)();
//# sourceMappingURL=ajax.js.map

/***/ }),

/***/ "6Uey":
/*!****************************************************!*\
  !*** ./src/app/tabs/skateparks/skateparks.page.ts ***!
  \****************************************************/
/*! exports provided: SkateparksPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkateparksPage", function() { return SkateparksPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_skateparks_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./skateparks.page.html */ "Riob");
/* harmony import */ var _skateparks_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skateparks.page.scss */ "rvwN");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _demodata__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./demodata */ "96r+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _skatepars_routers_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./skatepars-routers.enum */ "gb4m");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _shared_modals_modal_location_list_modal_location_list_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/modals/modal-location-list/modal-location-list.component */ "Quud");
/* harmony import */ var _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/services/skateparks.service */ "ttFK");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../shared/enums/Storage.enum */ "03gG");














let SkateparksPage = class SkateparksPage {
    constructor(_router, _modalController, _skateparkService, _coreStore) {
        this._router = _router;
        this._modalController = _modalController;
        this._skateparkService = _skateparkService;
        this._coreStore = _coreStore;
        this.sliders = _demodata__WEBPACK_IMPORTED_MODULE_4__["sliders"];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_11__["Subject"]();
    }
    ngOnInit() {
        if (!this._coreStore.state.skateparkFeatures) {
            this._skateparkService.getFeatures().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["takeUntil"])(this.componentDestroyed)).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_13__["StorageEnum"].SKATEPARK_FEATURES, res.features);
            }));
        }
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    openSearchPage(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!evt.detail.value) {
                return;
            }
            const modal = yield this._modalController.create({
                component: _shared_modals_modal_location_list_modal_location_list_component__WEBPACK_IMPORTED_MODULE_8__["ModalLocationListComponent"],
                cssClass: 'modal-location-skateparks',
                componentProps: {
                    search: evt.detail.value
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data) {
                this.searchValue = '';
                yield this._router.navigate(['/', _skatepars_routers_enum__WEBPACK_IMPORTED_MODULE_6__["SKATEPARKS_ROUTES"].SEARCH], { queryParams: { search: data.selectedLocation } });
            }
        });
    }
};
SkateparksPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_9__["SkateparksService"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_12__["CoreStore"] }
];
SkateparksPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-skateparks',
        template: _raw_loader_skateparks_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_skateparks_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SkateparksPage);



/***/ }),

/***/ "8RYy":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/components/slider-block/slider-block.component.html ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<section class=\"slider-block\">\n  <header class=\"ion-margin-bottom\">\n    <ion-text class=\"title-20\">{{title}}</ion-text>\n  </header>\n\n  <div class=\"slider-block__list\">\n    <ion-slides #slider pager=\"false\" [options]=\"slideOpts\" class=\"custom-slides\" pager=\"false\">\n      <ion-slide *ngFor =\" let slide of sliders\" (click)=\"openSkatepark()\">\n        <div class=\"slide\" (click)=\"openSlide()\">\n          <div class=\"slide__img\"  [ngStyle]=\"{'background-image':'url('+slide.imgSrc+')'}\"></div>\n          <!--  <img src=\"{{slide.imgSrc}}\">-->\n          <div class=\"slide__wrap\" [ngClass]=\"{'mt8': !isNeedRating}\">\n            <ionic-rating-component\n                    *ngIf=\"isNeedRating\"\n                    #rating\n                    activeIcon = \"star\"\n                    defaultIcon = \"star-outline\"\n                    [activeColor] = activeRatingColor\n                    [defaultColor] = defaultRatingColor\n                    readonly=\"false\"\n                    rating=\"3\"\n                    fontSize = \"16px\">\n            </ionic-rating-component>\n              <span class=\"text-15-500 slide__title\">\n                {{slide.title}}\n              </span>\n          </div>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n</section>\n");

/***/ }),

/***/ "96r+":
/*!*********************************************!*\
  !*** ./src/app/tabs/skateparks/demodata.ts ***!
  \*********************************************/
/*! exports provided: sliders */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sliders", function() { return sliders; });
const sliders = [
    {
        title: "Isleham Skatepark East",
        imgSrc: "/assets/images/popular_slides/isleham.jpg"
    },
    {
        title: "Newquay Concrete",
        imgSrc: "/assets/images/popular_slides/newquay.jpg"
    },
    {
        title: "Isleham Skatepark East 1",
        imgSrc: "/assets/images/popular_slides/isleham.jpg"
    },
    {
        title: "Newquay Concrete 1",
        imgSrc: "/assets/images/popular_slides/newquay.jpg"
    },
    {
        title: "Isleham Skatepark East 2",
        imgSrc: "/assets/images/popular_slides/isleham.jpg"
    },
    {
        title: "Newquay Concrete 2",
        imgSrc: "/assets/images/popular_slides/newquay.jpg"
    },
];


/***/ }),

/***/ "JrR6":
/*!*************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/components/slider-block/slider-block.component.scss ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".slider-block {\n  margin-top: calc(var(--theme-base-margin) * 6);\n}\n\n.slide {\n  position: relative;\n  min-width: 180px;\n  background-repeat: no-repeat;\n}\n\n.slide__img {\n  height: 200px;\n  width: auto;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  background-color: var(--ion-color-tertiary);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.slide__wrap {\n  text-align: left;\n}\n\n.slide__title {\n  display: block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHNsaWRlci1ibG9jay5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDhDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7QUFDRjs7QUFDRTtFQUNFLGFBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsMkNBQUE7RUFFQSw4Q0FBQTtBQUFKOztBQUlFO0VBQ0UsZ0JBQUE7QUFGSjs7QUFLRTtFQUNFLGNBQUE7RUFFQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFKSiIsImZpbGUiOiJzbGlkZXItYmxvY2suY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2xpZGVyLWJsb2NrIHtcbiAgbWFyZ2luLXRvcDogY2FsYyh2YXIoLS10aGVtZS1iYXNlLW1hcmdpbikgKiA2KTtcbn1cblxuLnNsaWRlIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtaW4td2lkdGg6IDE4MHB4O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuXG4gICZfX2ltZyB7XG4gICAgaGVpZ2h0OiAyMDBweDtcbiAgICB3aWR0aDogYXV0bztcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSk7XG5cbiAgICBib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xuXG4gIH1cblxuICAmX193cmFwIHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB9XG5cbiAgJl9fdGl0bGUge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "M3Yx":
/*!**************************************************************!*\
  !*** ./src/app/tabs/skateparks/skateparks-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: SkateparksPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkateparksPageRoutingModule", function() { return SkateparksPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _skateparks_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./skateparks.page */ "6Uey");




const routes = [
    {
        path: '',
        component: _skateparks_page__WEBPACK_IMPORTED_MODULE_3__["SkateparksPage"]
    },
    {
        path: ':id',
        loadChildren: () => __webpack_require__.e(/*! import() | skatepark-detail-skatepark-detail-module */ "skatepark-detail-skatepark-detail-module").then(__webpack_require__.bind(null, /*! ./skatepark-detail/skatepark-detail.module */ "o0p/")).then(m => m.SkateparkDetailPageModule)
    },
];
let SkateparksPageRoutingModule = class SkateparksPageRoutingModule {
};
SkateparksPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SkateparksPageRoutingModule);



/***/ }),

/***/ "Mj4Y":
/*!************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/fromIterable.js ***!
  \************************************************************************/
/*! exports provided: fromIterable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fromIterable", function() { return fromIterable; });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Observable */ "HDdC");
/* harmony import */ var _util_subscribeToIterable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/subscribeToIterable */ "pLzU");
/* harmony import */ var _scheduled_scheduleIterable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../scheduled/scheduleIterable */ "MBAA");



function fromIterable(input, scheduler) {
    if (!input) {
        throw new Error('Iterable cannot be null');
    }
    if (!scheduler) {
        return new _Observable__WEBPACK_IMPORTED_MODULE_0__["Observable"](Object(_util_subscribeToIterable__WEBPACK_IMPORTED_MODULE_1__["subscribeToIterable"])(input));
    }
    else {
        return Object(_scheduled_scheduleIterable__WEBPACK_IMPORTED_MODULE_2__["scheduleIterable"])(input, scheduler);
    }
}
//# sourceMappingURL=fromIterable.js.map

/***/ }),

/***/ "ObZ8":
/*!***************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/components/add-spot-board/add-spot-board.component.ts ***!
  \***************************************************************************************/
/*! exports provided: AddSpotBoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSpotBoardComponent", function() { return AddSpotBoardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_add_spot_board_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./add-spot-board.component.html */ "YD2c");
/* harmony import */ var _add_spot_board_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./add-spot-board.component.scss */ "yrQ5");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let AddSpotBoardComponent = class AddSpotBoardComponent {
    constructor() { }
    ngOnInit() { }
};
AddSpotBoardComponent.ctorParameters = () => [];
AddSpotBoardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-spot-board',
        template: _raw_loader_add_spot_board_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_add_spot_board_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AddSpotBoardComponent);



/***/ }),

/***/ "Of7M":
/*!*****************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/util/applyMixins.js ***!
  \*****************************************************************/
/*! exports provided: applyMixins */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyMixins", function() { return applyMixins; });
function applyMixins(derivedCtor, baseCtors) {
    for (let i = 0, len = baseCtors.length; i < len; i++) {
        const baseCtor = baseCtors[i];
        const propertyKeys = Object.getOwnPropertyNames(baseCtor.prototype);
        for (let j = 0, len2 = propertyKeys.length; j < len2; j++) {
            const name = propertyKeys[j];
            derivedCtor.prototype[name] = baseCtor.prototype[name];
        }
    }
}
//# sourceMappingURL=applyMixins.js.map

/***/ }),

/***/ "Oje0":
/*!*************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/modals/modal-add-skatepark/modal-add-skatepark.component.html ***!
  \*************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion ion-margin-start title-20\">\n      Add new Skatepark\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"dark\">\n  <from [formGroup]=\"form\">\n  <div class=\"ion-margin-start ion-margin-end\">\n    <ion-item color=\"dark\" class=\"ion-margin-top item-inline-padding\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Park name</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"name\"></ion-input>\n    </ion-item>\n\n    <ion-item color=\"dark\" class=\"item-inline-padding\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Location</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"city\"></ion-input>\n    </ion-item>\n\n    <div class=\"ion-margin-top row\">\n      <ion-text color=\"tertiary\" class=\"text-15\">\n        Some parks won’t have an address - place the pin on a map to add the exact location\n      </ion-text>\n      <div class=\"mt12\">\n        <app-map-block\n                [location$]=\"form.get('city').valueChanges\"\n                (address$)=\"getAddressFromMap($event)\"\n        ></app-map-block>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"ion-margin-start ion-margin-top row\">\n    <ion-label position=\"stacked\">\n      <ion-text class=\"text-16\">Photos</ion-text>\n    </ion-label>\n    <div class=\"mt12\">\n      <app-add-photos-slider (images$)=\"changeImages($event)\"></app-add-photos-slider>\n    </div>\n  </div>\n\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top row\">\n    <ion-label position=\"stacked\">\n      <ion-text class=\"text-16\">Type</ion-text>\n    </ion-label>\n    <app-custom-toggle-control [buttons]=\"types\" formControlName=\"type\"></app-custom-toggle-control>\n  </div>\n\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top row\">\n    <ion-label position=\"stacked\">\n      <ion-text class=\"text-16\">Surface</ion-text>\n    </ion-label>\n    <app-custom-toggle-control [buttons]=\"surfaces\" formControlName=\"material\"></app-custom-toggle-control>\n  </div>\n\n    <div class=\"ion-margin-start ion-margin-end ion-margin-top row\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Skatelite</ion-text>\n      </ion-label>\n      <app-custom-toggle-control [buttons]=\"skatelities\" formControlName=\"skatelite\"></app-custom-toggle-control>\n    </div>\n\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top row\">\n    <ion-label position=\"stacked\">\n      <ion-text class=\"text-16\">Add features</ion-text>\n    </ion-label>\n    <div class=\"mt12\">\n      <app-checkbox-list [checkboxes]=\"checkboxes\" formControlName=\"features\"></app-checkbox-list>\n    </div>\n  </div>\n  </from>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar color=\"dark\">\n    <ion-button\n            class=\"ion-margin-start ion-margin-end mb12 apply-btn\"\n            fill=\"solid\"\n            color=\"success\"\n            expand=\"block\"\n            [disabled]=\"form.invalid\"\n            (click)=\"confirmSave()\"\n    >\n      Save skatepark\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>\n");

/***/ }),

/***/ "Riob":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/skateparks.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout\n        [isNeedRightPadding]=\"false\"\n>\n    <div class=\"ion-margin-end\">\n        <ion-searchbar\n                class=\"search-field\"\n                inputmode=\"search\"\n                mode=\"ios\"\n                color=\"dark\"\n                placeholder=\"Looking for a skatepark?\"\n                clearIcon=\"close-outline\"\n                debounce=\"600\"\n                [(ngModel)]=\"searchValue\"\n                (ionChange)=\"openSearchPage($event)\"\n        ></ion-searchbar>\n    </div>\n    <app-slider-block\n            title=\"Most popular\"\n            [sliders]=\"sliders\"\n            [isNeedRating]=\"true\"\n    >\n    </app-slider-block>\n    <div class=\"ion-margin-top ion-margin-bottom ion-margin-end\">\n        <app-add-skatepark-board></app-add-skatepark-board>\n    </div>\n    <app-slider-block\n            title=\"Favourite skateparks\"\n            [sliders]=\"sliders\"\n    >\n    </app-slider-block>\n    <div class=\"ion-margin-top ion-margin-bottom ion-margin-end\">\n        <app-add-spot-board></app-add-spot-board>\n    </div>\n</app-mail-layout>\n");

/***/ }),

/***/ "Sj+y":
/*!******************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/dom/AjaxObservable.js ***!
  \******************************************************************************/
/*! exports provided: ajaxGet, ajaxPost, ajaxDelete, ajaxPut, ajaxPatch, ajaxGetJSON, AjaxObservable, AjaxSubscriber, AjaxResponse, AjaxError, AjaxTimeoutError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxGet", function() { return ajaxGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxPost", function() { return ajaxPost; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxDelete", function() { return ajaxDelete; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxPut", function() { return ajaxPut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxPatch", function() { return ajaxPatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxGetJSON", function() { return ajaxGetJSON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxObservable", function() { return AjaxObservable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxSubscriber", function() { return AjaxSubscriber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxResponse", function() { return AjaxResponse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxError", function() { return AjaxError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxTimeoutError", function() { return AjaxTimeoutError; });
/* harmony import */ var _util_root__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../util/root */ "xJj7");
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../Observable */ "HDdC");
/* harmony import */ var _Subscriber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../Subscriber */ "7o/Q");
/* harmony import */ var _operators_map__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../operators/map */ "lJxs");




function getCORSRequest() {
    if (_util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XMLHttpRequest) {
        return new _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XMLHttpRequest();
    }
    else if (!!_util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XDomainRequest) {
        return new _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XDomainRequest();
    }
    else {
        throw new Error('CORS is not supported by your browser');
    }
}
function getXMLHttpRequest() {
    if (_util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XMLHttpRequest) {
        return new _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XMLHttpRequest();
    }
    else {
        let progId;
        try {
            const progIds = ['Msxml2.XMLHTTP', 'Microsoft.XMLHTTP', 'Msxml2.XMLHTTP.4.0'];
            for (let i = 0; i < 3; i++) {
                try {
                    progId = progIds[i];
                    if (new _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].ActiveXObject(progId)) {
                        break;
                    }
                }
                catch (e) {
                }
            }
            return new _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].ActiveXObject(progId);
        }
        catch (e) {
            throw new Error('XMLHttpRequest is not supported by your browser');
        }
    }
}
function ajaxGet(url, headers = null) {
    return new AjaxObservable({ method: 'GET', url, headers });
}
function ajaxPost(url, body, headers) {
    return new AjaxObservable({ method: 'POST', url, body, headers });
}
function ajaxDelete(url, headers) {
    return new AjaxObservable({ method: 'DELETE', url, headers });
}
function ajaxPut(url, body, headers) {
    return new AjaxObservable({ method: 'PUT', url, body, headers });
}
function ajaxPatch(url, body, headers) {
    return new AjaxObservable({ method: 'PATCH', url, body, headers });
}
const mapResponse = Object(_operators_map__WEBPACK_IMPORTED_MODULE_3__["map"])((x, index) => x.response);
function ajaxGetJSON(url, headers) {
    return mapResponse(new AjaxObservable({
        method: 'GET',
        url,
        responseType: 'json',
        headers
    }));
}
class AjaxObservable extends _Observable__WEBPACK_IMPORTED_MODULE_1__["Observable"] {
    constructor(urlOrRequest) {
        super();
        const request = {
            async: true,
            createXHR: function () {
                return this.crossDomain ? getCORSRequest() : getXMLHttpRequest();
            },
            crossDomain: true,
            withCredentials: false,
            headers: {},
            method: 'GET',
            responseType: 'json',
            timeout: 0
        };
        if (typeof urlOrRequest === 'string') {
            request.url = urlOrRequest;
        }
        else {
            for (const prop in urlOrRequest) {
                if (urlOrRequest.hasOwnProperty(prop)) {
                    request[prop] = urlOrRequest[prop];
                }
            }
        }
        this.request = request;
    }
    _subscribe(subscriber) {
        return new AjaxSubscriber(subscriber, this.request);
    }
}
AjaxObservable.create = (() => {
    const create = (urlOrRequest) => {
        return new AjaxObservable(urlOrRequest);
    };
    create.get = ajaxGet;
    create.post = ajaxPost;
    create.delete = ajaxDelete;
    create.put = ajaxPut;
    create.patch = ajaxPatch;
    create.getJSON = ajaxGetJSON;
    return create;
})();
class AjaxSubscriber extends _Subscriber__WEBPACK_IMPORTED_MODULE_2__["Subscriber"] {
    constructor(destination, request) {
        super(destination);
        this.request = request;
        this.done = false;
        const headers = request.headers = request.headers || {};
        if (!request.crossDomain && !this.getHeader(headers, 'X-Requested-With')) {
            headers['X-Requested-With'] = 'XMLHttpRequest';
        }
        let contentTypeHeader = this.getHeader(headers, 'Content-Type');
        if (!contentTypeHeader && !(_util_root__WEBPACK_IMPORTED_MODULE_0__["root"].FormData && request.body instanceof _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].FormData) && typeof request.body !== 'undefined') {
            headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        }
        request.body = this.serializeBody(request.body, this.getHeader(request.headers, 'Content-Type'));
        this.send();
    }
    next(e) {
        this.done = true;
        const { xhr, request, destination } = this;
        let result;
        try {
            result = new AjaxResponse(e, xhr, request);
        }
        catch (err) {
            return destination.error(err);
        }
        destination.next(result);
    }
    send() {
        const { request, request: { user, method, url, async, password, headers, body } } = this;
        try {
            const xhr = this.xhr = request.createXHR();
            this.setupEvents(xhr, request);
            if (user) {
                xhr.open(method, url, async, user, password);
            }
            else {
                xhr.open(method, url, async);
            }
            if (async) {
                xhr.timeout = request.timeout;
                xhr.responseType = request.responseType;
            }
            if ('withCredentials' in xhr) {
                xhr.withCredentials = !!request.withCredentials;
            }
            this.setHeaders(xhr, headers);
            if (body) {
                xhr.send(body);
            }
            else {
                xhr.send();
            }
        }
        catch (err) {
            this.error(err);
        }
    }
    serializeBody(body, contentType) {
        if (!body || typeof body === 'string') {
            return body;
        }
        else if (_util_root__WEBPACK_IMPORTED_MODULE_0__["root"].FormData && body instanceof _util_root__WEBPACK_IMPORTED_MODULE_0__["root"].FormData) {
            return body;
        }
        if (contentType) {
            const splitIndex = contentType.indexOf(';');
            if (splitIndex !== -1) {
                contentType = contentType.substring(0, splitIndex);
            }
        }
        switch (contentType) {
            case 'application/x-www-form-urlencoded':
                return Object.keys(body).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(body[key])}`).join('&');
            case 'application/json':
                return JSON.stringify(body);
            default:
                return body;
        }
    }
    setHeaders(xhr, headers) {
        for (let key in headers) {
            if (headers.hasOwnProperty(key)) {
                xhr.setRequestHeader(key, headers[key]);
            }
        }
    }
    getHeader(headers, headerName) {
        for (let key in headers) {
            if (key.toLowerCase() === headerName.toLowerCase()) {
                return headers[key];
            }
        }
        return undefined;
    }
    setupEvents(xhr, request) {
        const progressSubscriber = request.progressSubscriber;
        function xhrTimeout(e) {
            const { subscriber, progressSubscriber, request } = xhrTimeout;
            if (progressSubscriber) {
                progressSubscriber.error(e);
            }
            let error;
            try {
                error = new AjaxTimeoutError(this, request);
            }
            catch (err) {
                error = err;
            }
            subscriber.error(error);
        }
        xhr.ontimeout = xhrTimeout;
        xhrTimeout.request = request;
        xhrTimeout.subscriber = this;
        xhrTimeout.progressSubscriber = progressSubscriber;
        if (xhr.upload && 'withCredentials' in xhr) {
            if (progressSubscriber) {
                let xhrProgress;
                xhrProgress = function (e) {
                    const { progressSubscriber } = xhrProgress;
                    progressSubscriber.next(e);
                };
                if (_util_root__WEBPACK_IMPORTED_MODULE_0__["root"].XDomainRequest) {
                    xhr.onprogress = xhrProgress;
                }
                else {
                    xhr.upload.onprogress = xhrProgress;
                }
                xhrProgress.progressSubscriber = progressSubscriber;
            }
            let xhrError;
            xhrError = function (e) {
                const { progressSubscriber, subscriber, request } = xhrError;
                if (progressSubscriber) {
                    progressSubscriber.error(e);
                }
                let error;
                try {
                    error = new AjaxError('ajax error', this, request);
                }
                catch (err) {
                    error = err;
                }
                subscriber.error(error);
            };
            xhr.onerror = xhrError;
            xhrError.request = request;
            xhrError.subscriber = this;
            xhrError.progressSubscriber = progressSubscriber;
        }
        function xhrReadyStateChange(e) {
            return;
        }
        xhr.onreadystatechange = xhrReadyStateChange;
        xhrReadyStateChange.subscriber = this;
        xhrReadyStateChange.progressSubscriber = progressSubscriber;
        xhrReadyStateChange.request = request;
        function xhrLoad(e) {
            const { subscriber, progressSubscriber, request } = xhrLoad;
            if (this.readyState === 4) {
                let status = this.status === 1223 ? 204 : this.status;
                let response = (this.responseType === 'text' ? (this.response || this.responseText) : this.response);
                if (status === 0) {
                    status = response ? 200 : 0;
                }
                if (status < 400) {
                    if (progressSubscriber) {
                        progressSubscriber.complete();
                    }
                    subscriber.next(e);
                    subscriber.complete();
                }
                else {
                    if (progressSubscriber) {
                        progressSubscriber.error(e);
                    }
                    let error;
                    try {
                        error = new AjaxError('ajax error ' + status, this, request);
                    }
                    catch (err) {
                        error = err;
                    }
                    subscriber.error(error);
                }
            }
        }
        xhr.onload = xhrLoad;
        xhrLoad.subscriber = this;
        xhrLoad.progressSubscriber = progressSubscriber;
        xhrLoad.request = request;
    }
    unsubscribe() {
        const { done, xhr } = this;
        if (!done && xhr && xhr.readyState !== 4 && typeof xhr.abort === 'function') {
            xhr.abort();
        }
        super.unsubscribe();
    }
}
class AjaxResponse {
    constructor(originalEvent, xhr, request) {
        this.originalEvent = originalEvent;
        this.xhr = xhr;
        this.request = request;
        this.status = xhr.status;
        this.responseType = xhr.responseType || request.responseType;
        this.response = parseXhrResponse(this.responseType, xhr);
    }
}
const AjaxErrorImpl = (() => {
    function AjaxErrorImpl(message, xhr, request) {
        Error.call(this);
        this.message = message;
        this.name = 'AjaxError';
        this.xhr = xhr;
        this.request = request;
        this.status = xhr.status;
        this.responseType = xhr.responseType || request.responseType;
        this.response = parseXhrResponse(this.responseType, xhr);
        return this;
    }
    AjaxErrorImpl.prototype = Object.create(Error.prototype);
    return AjaxErrorImpl;
})();
const AjaxError = AjaxErrorImpl;
function parseJson(xhr) {
    if ('response' in xhr) {
        return xhr.responseType ? xhr.response : JSON.parse(xhr.response || xhr.responseText || 'null');
    }
    else {
        return JSON.parse(xhr.responseText || 'null');
    }
}
function parseXhrResponse(responseType, xhr) {
    switch (responseType) {
        case 'json':
            return parseJson(xhr);
        case 'xml':
            return xhr.responseXML;
        case 'text':
        default:
            return ('response' in xhr) ? xhr.response : xhr.responseText;
    }
}
function AjaxTimeoutErrorImpl(xhr, request) {
    AjaxError.call(this, 'ajax timeout', xhr, request);
    this.name = 'AjaxTimeoutError';
    return this;
}
const AjaxTimeoutError = AjaxTimeoutErrorImpl;
//# sourceMappingURL=AjaxObservable.js.map

/***/ }),

/***/ "V3xS":
/*!*************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/components/add-skatepark-board/add-skatepark-board.component.ts ***!
  \*************************************************************************************************/
/*! exports provided: AddSkateparkBoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddSkateparkBoardComponent", function() { return AddSkateparkBoardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_add_skatepark_board_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./add-skatepark-board.component.html */ "d7nz");
/* harmony import */ var _add_skatepark_board_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./add-skatepark-board.component.scss */ "qvlw");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _modals_modal_add_skatepark_modal_add_skatepark_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../modals/modal-add-skatepark/modal-add-skatepark.component */ "g5Oi");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let AddSkateparkBoardComponent = class AddSkateparkBoardComponent {
    constructor(_modalController) {
        this._modalController = _modalController;
    }
    ngOnInit() { }
    openModalAddSkatepark() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modals_modal_add_skatepark_modal_add_skatepark_component__WEBPACK_IMPORTED_MODULE_4__["ModalAddSkateparkComponent"],
                cssClass: 'modal-add-spot',
                id: 'addSkateparkId'
            });
            return yield modal.present();
        });
    }
};
AddSkateparkBoardComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] }
];
AddSkateparkBoardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-skatepark-board',
        template: _raw_loader_add_skatepark_board_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_add_skatepark_board_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AddSkateparkBoardComponent);



/***/ }),

/***/ "VGLg":
/*!***********************************************************************************!*\
  !*** ./src/app/tabs/skateparks/components/slider-block/slider-block.component.ts ***!
  \***********************************************************************************/
/*! exports provided: SliderBlockComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SliderBlockComponent", function() { return SliderBlockComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_slider_block_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./slider-block.component.html */ "8RYy");
/* harmony import */ var _slider_block_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./slider-block.component.scss */ "JrR6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../tabs.enum */ "162u");






let SliderBlockComponent = class SliderBlockComponent {
    constructor(_router) {
        this._router = _router;
        this.title = 'Example title';
        this.sliders = [];
        this.isNeedRating = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            loop: true,
            slidesPerView: 1,
            spaceBetween: 16,
            width: 180
        };
        this.defaultRatingColor = getComputedStyle(document.documentElement).getPropertyValue('--ion-color-light');
        this.activeRatingColor = getComputedStyle(document.documentElement).getPropertyValue('--ion-color-secondary');
    }
    ngOnInit() {
    }
    openSlide() {
    }
    openSkatepark() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _tabs_enum__WEBPACK_IMPORTED_MODULE_5__["TABS_MAIN_ROUTE"], _tabs_enum__WEBPACK_IMPORTED_MODULE_5__["tabsEnum2RouteMapping"].SKATEPARKS, 1]);
        });
    }
};
SliderBlockComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
SliderBlockComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    sliders: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    isNeedRating: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    sliderRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slider', { static: false },] }]
};
SliderBlockComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-slider-block',
        template: _raw_loader_slider_block_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_slider_block_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SliderBlockComponent);



/***/ }),

/***/ "YD2c":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/components/add-spot-board/add-spot-board.component.html ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"spot-board\">\n  <ion-text color=\"light\" class=\"text-15-500\">Found a new spot?</ion-text>\n  <ion-text color=\"secondary\" class=\"text-15-500\">Add it to My Skate Spots</ion-text>\n</div>\n");

/***/ }),

/***/ "d7nz":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/components/add-skatepark-board/add-skatepark-board.component.html ***!
  \*****************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"skatepark-board\">\n    <ion-text (click)=\"openModalAddSkatepark()\" color=\"secondary\" class=\"text-15-500 skatepark-board__text\">Add a Skatepark</ion-text>\n</div>\n");

/***/ }),

/***/ "dJRF":
/*!*****************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/util/errorObject.js ***!
  \*****************************************************************/
/*! exports provided: errorObject */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "errorObject", function() { return errorObject; });
const errorObject = { e: {} };
//# sourceMappingURL=errorObject.js.map

/***/ }),

/***/ "f7vj":
/*!*******************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/modals/modal-skatepark-confirm/modal-skatepark-confirm.component.scss ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".wrapper {\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLXNrYXRlcGFyay1jb25maXJtLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGIiwiZmlsZSI6Im1vZGFsLXNrYXRlcGFyay1jb25maXJtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXBwZXIge1xyXG4gIG1hcmdpbjogYXV0bztcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "g5Oi":
/*!*********************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/modals/modal-add-skatepark/modal-add-skatepark.component.ts ***!
  \*********************************************************************************************/
/*! exports provided: ModalAddSkateparkComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalAddSkateparkComponent", function() { return ModalAddSkateparkComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_add_skatepark_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-add-skatepark.component.html */ "Oje0");
/* harmony import */ var _modal_add_skatepark_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-add-skatepark.component.scss */ "llB/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_skatepark_confirm_modal_skatepark_confirm_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../modal-skatepark-confirm/modal-skatepark-confirm.component */ "mJD3");
/* harmony import */ var _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../shared/services/skateparks.service */ "ttFK");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../shared/store/core.store */ "8e7N");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _pages_search_skateparks_modal_filter_skateparks_dictionaries__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../pages/search-skateparks/modal-filter-skateparks/dictionaries */ "s9Q0");
/* harmony import */ var _pages_search_skateparks_modal_filter_skateparks_surfaces__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../pages/search-skateparks/modal-filter-skateparks/surfaces */ "Di3u");











let ModalAddSkateparkComponent = class ModalAddSkateparkComponent {
    constructor(_modalController, _skateparkService, _coreStore, _fb) {
        this._modalController = _modalController;
        this._skateparkService = _skateparkService;
        this._coreStore = _coreStore;
        this._fb = _fb;
        this.checkboxes = [];
        this.types = _pages_search_skateparks_modal_filter_skateparks_dictionaries__WEBPACK_IMPORTED_MODULE_9__["TYPES"];
        this.skatelities = _pages_search_skateparks_modal_filter_skateparks_dictionaries__WEBPACK_IMPORTED_MODULE_9__["SKATELITIES"];
        this.surfaces = _pages_search_skateparks_modal_filter_skateparks_surfaces__WEBPACK_IMPORTED_MODULE_10__["SURFACES"];
        this.images = [];
    }
    ngOnInit() {
        this.checkboxes = this._coreStore.state.skateparkFeatures;
        this.creatForm();
    }
    creatForm() {
        this.form = this._fb.group({
            name: '',
            city: '',
            type: '',
            material: '',
            features: [[]],
            skatelite: false,
        });
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
    confirmSave() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modal_skatepark_confirm_modal_skatepark_confirm_component__WEBPACK_IMPORTED_MODULE_5__["ModalSkateparkConfirmComponent"],
                cssClass: 'modal-confirm',
                id: 'addSkateparkConfirmId',
                componentProps: {
                    candidate: Object.assign(Object.assign(Object.assign({}, this.form.value), this.location), { image: this.images })
                }
            });
            yield modal.present();
        });
    }
    getAddressFromMap($event) {
        this.location = $event;
    }
    changeImages(slides) {
        this.images = slides.map(s => s.imgSrc);
    }
};
ModalAddSkateparkComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_6__["SkateparksService"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__["CoreStore"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"] }
];
ModalAddSkateparkComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-add-skatepark',
        template: _raw_loader_modal_add_skatepark_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_add_skatepark_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalAddSkateparkComponent);



/***/ }),

/***/ "hPQ2":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/modals/modal-skatepark-confirm/modal-skatepark-confirm.component.html ***!
  \*********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion ion-margin-start title-20\">\n      Submit a Skatepark\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"dark\" class=\"ion-padding-start ion-padding-end\">\n  <div class=\"d-flex flex-column h100percent\">\n    <div class=\"d-flex flex-column ion-text-center wrapper\">\n      <ion-text color=\"light\" class=\"ion-margin-bottom title-34\">Confirm submission?</ion-text>\n      <ion-text color=\"tertiary\" class=\"ion-margin-bottom text-16-500\">Skatepark will not display automatically, as needs to be authorized by admin.\n      </ion-text>\n      <div class=\"d-flex flex-column ion-margin-top\">\n        <ion-button [disabled]=\"!candidate\" expand=\"block\" color=\"success\" (click)=\"savePark()\">Confirm</ion-button>\n        <ion-button fill=\"clear\" color=\"danger\" (click)=\"closeModal()\">Cancel</ion-button>\n      </div>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "lcII":
/*!*************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/dom/webSocket.js ***!
  \*************************************************************************/
/*! exports provided: webSocket */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "webSocket", function() { return webSocket; });
/* harmony import */ var _WebSocketSubject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WebSocketSubject */ "wxn8");

function webSocket(urlConfigOrSource) {
    return new _WebSocketSubject__WEBPACK_IMPORTED_MODULE_0__["WebSocketSubject"](urlConfigOrSource);
}
//# sourceMappingURL=webSocket.js.map

/***/ }),

/***/ "llB/":
/*!***********************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/modals/modal-add-skatepark/modal-add-skatepark.component.scss ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-input, ion-textarea {\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n}\n\nion-label {\n  white-space: normal !important;\n}\n\nion-checkbox {\n  --background: var(--ion-color-dark);\n  --background-checked: var(--ion-color-primary);\n  --border-color: var(--ion-color-dark);\n  --border-color-checked: var(--ion-color-primary);\n  --checkmark-color: var(--ion-color-secondary);\n}\n\nion-list {\n  background: var(--ion-color-dark);\n}\n\n.apply-btn {\n  width: 100%;\n  max-width: 320px;\n}\n\n.item-inline-padding {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLWFkZC1za2F0ZXBhcmsuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5REFBQTtFQUNBLHVEQUFBO0VBQ0EsMENBQUE7RUFDQSxnQ0FBQTtFQUNBLDhCQUFBO0VBQ0EsOEJBQUE7RUFDQSxpQ0FBQTtFQUNBLGdEQUFBO0FBQ0Y7O0FBRUE7RUFDRSw4QkFBQTtBQUNGOztBQUVBO0VBQ0UsbUNBQUE7RUFDQSw4Q0FBQTtFQUNBLHFDQUFBO0VBQ0EsZ0RBQUE7RUFDQSw2Q0FBQTtBQUNGOztBQUVBO0VBQ0UsaUNBQUE7QUFDRjs7QUFDQTtFQUNFLFdBQUE7RUFDQSxnQkFBQTtBQUVGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtBQUVGIiwiZmlsZSI6Im1vZGFsLWFkZC1za2F0ZXBhcmsuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW5wdXQsIGlvbi10ZXh0YXJlYSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLWNvbnRyYXN0KSAhaW1wb3J0YW50O1xyXG4gIC0tcGxhY2Vob2xkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pICFpbXBvcnRhbnQ7XHJcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KSAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1zdGFydDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDE2cHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbjogMTBweCAhaW1wb3J0YW50O1xyXG4gIC0tYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcclxuXHJcbn1cclxuaW9uLWxhYmVsIHtcclxuICB3aGl0ZS1zcGFjZTogbm9ybWFsICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jaGVja2JveCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAtLWJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gIC0tYm9yZGVyLWNvbG9yLWNoZWNrZWQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAtLWNoZWNrbWFyay1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbn1cclxuLmFwcGx5LWJ0biB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiAzMjBweDtcclxufVxyXG5cclxuLml0ZW0taW5saW5lLXBhZGRpbmcge1xyXG4gIC0tcGFkZGluZy1zdGFydDogMDtcclxuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "mJD3":
/*!*****************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/modals/modal-skatepark-confirm/modal-skatepark-confirm.component.ts ***!
  \*****************************************************************************************************/
/*! exports provided: ModalSkateparkConfirmComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalSkateparkConfirmComponent", function() { return ModalSkateparkConfirmComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_skatepark_confirm_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-skatepark-confirm.component.html */ "hPQ2");
/* harmony import */ var _modal_skatepark_confirm_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-skatepark-confirm.component.scss */ "f7vj");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../shared/services/skateparks.service */ "ttFK");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../shared/helpers/toast-notification.service */ "b3vI");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "B7Rs");
/* harmony import */ var _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../shared/configs/main.config */ "phI0");
/* harmony import */ var rxjs_internal_compatibility__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/internal-compatibility */ "w0v+");












let ModalSkateparkConfirmComponent = class ModalSkateparkConfirmComponent {
    constructor(_modalController, _skateParkService, _toast, _transfer) {
        this._modalController = _modalController;
        this._skateParkService = _skateParkService;
        this._toast = _toast;
        this._transfer = _transfer;
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Subject"]();
    }
    ngOnInit() {
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
    savePark() {
        console.log(this.candidate);
        // this._toast.success('Skate park added!').then();
        //  this._modalController.dismiss(undefined, undefined, 'addSkateparkId').then();
        //  this._modalController.dismiss({success: true}, undefined, 'addSkateparkConfirmId').then();
        this.toggleMethod(this.candidate.image.length > 0)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["takeUntil"])(this.componentDestroyed))
            .subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (res.success) {
                yield this._toast.success('Skate park added!');
                this._modalController.dismiss(undefined, undefined, 'addSkateparkId').then();
                this._modalController.dismiss({ success: true }, undefined, 'addSkateparkConfirmId').then();
            }
            else {
                yield this._toast.success(res.response_msg);
                this._modalController.dismiss({ success: true }, undefined, 'addSkateparkConfirmId').then();
            }
        }));
    }
    toggleMethod(isImage) {
        if (isImage) {
            const image = this.candidate.image[0];
            const options = Object.assign(Object.assign({}, this.candidate), { fileKey: "image", fileName: image.substr(image.lastIndexOf('/') + 1), chunkedMode: false, 
                // @ts-ignore
                image: null });
            const url = _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_10__["SITE_MAIN"] + 'integration/myskate/myskate-park-save-image.php';
            const fileTransfer = this._transfer.create();
            return Object(rxjs_internal_compatibility__WEBPACK_IMPORTED_MODULE_11__["fromPromise"])(fileTransfer.upload(image, url, options));
            return this._skateParkService.addSkateparkWithImage(this.candidate);
        }
        return this._skateParkService.addSkatepark(this.candidate);
    }
};
ModalSkateparkConfirmComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_5__["SkateparksService"] },
    { type: _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_8__["ToastNotificationService"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_9__["FileTransfer"] }
];
ModalSkateparkConfirmComponent.propDecorators = {
    candidate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
ModalSkateparkConfirmComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-skatepark-confirm',
        template: _raw_loader_modal_skatepark_confirm_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_skatepark_confirm_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalSkateparkConfirmComponent);



/***/ }),

/***/ "mtqP":
/*!**************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/util/tryCatch.js ***!
  \**************************************************************/
/*! exports provided: tryCatch */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tryCatch", function() { return tryCatch; });
/* harmony import */ var _errorObject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./errorObject */ "dJRF");

let tryCatchTarget;
function tryCatcher() {
    _errorObject__WEBPACK_IMPORTED_MODULE_0__["errorObject"].e = undefined;
    try {
        return tryCatchTarget.apply(this, arguments);
    }
    catch (e) {
        _errorObject__WEBPACK_IMPORTED_MODULE_0__["errorObject"].e = e;
        return _errorObject__WEBPACK_IMPORTED_MODULE_0__["errorObject"];
    }
    finally {
        tryCatchTarget = undefined;
    }
}
function tryCatch(fn) {
    tryCatchTarget = fn;
    return tryCatcher;
}
//# sourceMappingURL=tryCatch.js.map

/***/ }),

/***/ "qvlw":
/*!***************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/components/add-skatepark-board/add-skatepark-board.component.scss ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".skatepark-board {\n  display: flex;\n  justify-content: flex-end;\n  padding: var(--ion-padding);\n  background-color: var(--ion-color-dark);\n  background-image: url(\"/../../assets/images/backgrouds/skatepark-board.png\");\n  background-position: center;\n  background-size: contain;\n  background-repeat: no-repeat;\n  border-radius: var(--theme-base-border-radius);\n}\n.skatepark-board__text {\n  display: block;\n  width: 82px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGFkZC1za2F0ZXBhcmstYm9hcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EseUJBQUE7RUFFQSwyQkFBQTtFQUVBLHVDQUFBO0VBQ0EsNEVBQUE7RUFDQSwyQkFBQTtFQUNBLHdCQUFBO0VBQ0EsNEJBQUE7RUFFQSw4Q0FBQTtBQUZGO0FBSUU7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUVBLGtCQUFBO0FBSEoiLCJmaWxlIjoiYWRkLXNrYXRlcGFyay1ib2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5za2F0ZXBhcmstYm9hcmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuXG4gIHBhZGRpbmc6IHZhcigtLWlvbi1wYWRkaW5nKTtcblxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi8uLi8uLi9hc3NldHMvaW1hZ2VzL2JhY2tncm91ZHMvc2thdGVwYXJrLWJvYXJkLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG5cbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcblxuICAmX190ZXh0IHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB3aWR0aDogODJweDtcblxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "rvwN":
/*!******************************************************!*\
  !*** ./src/app/tabs/skateparks/skateparks.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-searchbar {\n  --placeholder-font-weight: 500;\n  --placeholder-color: var(--ion-color-light);\n  --placeholder-opacity: 0.9;\n  --border-radius: var(--theme-base-border-radius);\n  --box-shadow: 0 0px 2px 0px var(--ion-color-secondary);\n  -webkit-padding-start: 1px;\n          padding-inline-start: 1px;\n  -webkit-padding-end: 1px;\n          padding-inline-end: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxza2F0ZXBhcmtzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDhCQUFBO0VBQ0EsMkNBQUE7RUFDQSwwQkFBQTtFQUNBLGdEQUFBO0VBQ0Esc0RBQUE7RUFFQSwwQkFBQTtVQUFBLHlCQUFBO0VBQ0Esd0JBQUE7VUFBQSx1QkFBQTtBQUFGIiwiZmlsZSI6InNrYXRlcGFya3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXNlYXJjaGJhciB7XG4gIC0tcGxhY2Vob2xkZXItZm9udC13ZWlnaHQ6IDUwMDtcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgLS1wbGFjZWhvbGRlci1vcGFjaXR5OiAwLjk7XG4gIC0tYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcbiAgLS1ib3gtc2hhZG93OiAwIDBweCAycHggMHB4IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuXG4gIHBhZGRpbmctaW5saW5lLXN0YXJ0OjFweDtcbiAgcGFkZGluZy1pbmxpbmUtZW5kOiAxcHg7XG59XG4iXX0= */");

/***/ }),

/***/ "w0v+":
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal-compatibility/index.js ***!
  \********************************************************************/
/*! exports provided: config, InnerSubscriber, OuterSubscriber, Scheduler, AnonymousSubject, SubjectSubscription, Subscriber, fromPromise, fromIterable, ajax, webSocket, ajaxGet, ajaxPost, ajaxDelete, ajaxPut, ajaxPatch, ajaxGetJSON, AjaxObservable, AjaxSubscriber, AjaxResponse, AjaxError, AjaxTimeoutError, WebSocketSubject, CombineLatestOperator, dispatch, SubscribeOnObservable, Timestamp, TimeInterval, GroupedObservable, defaultThrottleConfig, rxSubscriber, iterator, observable, ArgumentOutOfRangeError, EmptyError, Immediate, ObjectUnsubscribedError, TimeoutError, UnsubscriptionError, applyMixins, errorObject, hostReportError, identity, isArray, isArrayLike, isDate, isFunction, isIterable, isNumeric, isObject, isObservable, isPromise, isScheduler, noop, not, pipe, root, subscribeTo, subscribeToArray, subscribeToIterable, subscribeToObservable, subscribeToPromise, subscribeToResult, toSubscriber, tryCatch */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _internal_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../internal/config */ "2fFW");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "config", function() { return _internal_config__WEBPACK_IMPORTED_MODULE_0__["config"]; });

/* harmony import */ var _internal_InnerSubscriber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../internal/InnerSubscriber */ "51Dv");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InnerSubscriber", function() { return _internal_InnerSubscriber__WEBPACK_IMPORTED_MODULE_1__["InnerSubscriber"]; });

/* harmony import */ var _internal_OuterSubscriber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../internal/OuterSubscriber */ "l7GE");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OuterSubscriber", function() { return _internal_OuterSubscriber__WEBPACK_IMPORTED_MODULE_2__["OuterSubscriber"]; });

/* harmony import */ var _internal_Scheduler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../internal/Scheduler */ "Y/cZ");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Scheduler", function() { return _internal_Scheduler__WEBPACK_IMPORTED_MODULE_3__["Scheduler"]; });

/* harmony import */ var _internal_Subject__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../internal/Subject */ "XNiG");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AnonymousSubject", function() { return _internal_Subject__WEBPACK_IMPORTED_MODULE_4__["AnonymousSubject"]; });

/* harmony import */ var _internal_SubjectSubscription__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../internal/SubjectSubscription */ "Ylt2");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SubjectSubscription", function() { return _internal_SubjectSubscription__WEBPACK_IMPORTED_MODULE_5__["SubjectSubscription"]; });

/* harmony import */ var _internal_Subscriber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../internal/Subscriber */ "7o/Q");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Subscriber", function() { return _internal_Subscriber__WEBPACK_IMPORTED_MODULE_6__["Subscriber"]; });

/* harmony import */ var _internal_observable_fromPromise__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../internal/observable/fromPromise */ "x4c3");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fromPromise", function() { return _internal_observable_fromPromise__WEBPACK_IMPORTED_MODULE_7__["fromPromise"]; });

/* harmony import */ var _internal_observable_fromIterable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../internal/observable/fromIterable */ "Mj4Y");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fromIterable", function() { return _internal_observable_fromIterable__WEBPACK_IMPORTED_MODULE_8__["fromIterable"]; });

/* harmony import */ var _internal_observable_dom_ajax__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../internal/observable/dom/ajax */ "19/K");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajax", function() { return _internal_observable_dom_ajax__WEBPACK_IMPORTED_MODULE_9__["ajax"]; });

/* harmony import */ var _internal_observable_dom_webSocket__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../internal/observable/dom/webSocket */ "lcII");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "webSocket", function() { return _internal_observable_dom_webSocket__WEBPACK_IMPORTED_MODULE_10__["webSocket"]; });

/* harmony import */ var _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../internal/observable/dom/AjaxObservable */ "Sj+y");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajaxGet", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["ajaxGet"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajaxPost", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["ajaxPost"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajaxDelete", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["ajaxDelete"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajaxPut", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["ajaxPut"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajaxPatch", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["ajaxPatch"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ajaxGetJSON", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["ajaxGetJSON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AjaxObservable", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["AjaxObservable"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AjaxSubscriber", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["AjaxSubscriber"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AjaxResponse", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["AjaxResponse"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AjaxError", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["AjaxError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AjaxTimeoutError", function() { return _internal_observable_dom_AjaxObservable__WEBPACK_IMPORTED_MODULE_11__["AjaxTimeoutError"]; });

/* harmony import */ var _internal_observable_dom_WebSocketSubject__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../internal/observable/dom/WebSocketSubject */ "wxn8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "WebSocketSubject", function() { return _internal_observable_dom_WebSocketSubject__WEBPACK_IMPORTED_MODULE_12__["WebSocketSubject"]; });

/* harmony import */ var _internal_observable_combineLatest__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../internal/observable/combineLatest */ "itXk");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CombineLatestOperator", function() { return _internal_observable_combineLatest__WEBPACK_IMPORTED_MODULE_13__["CombineLatestOperator"]; });

/* harmony import */ var _internal_observable_range__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../internal/observable/range */ "NNCq");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "dispatch", function() { return _internal_observable_range__WEBPACK_IMPORTED_MODULE_14__["dispatch"]; });

/* harmony import */ var _internal_observable_SubscribeOnObservable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../internal/observable/SubscribeOnObservable */ "O4y0");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SubscribeOnObservable", function() { return _internal_observable_SubscribeOnObservable__WEBPACK_IMPORTED_MODULE_15__["SubscribeOnObservable"]; });

/* harmony import */ var _internal_operators_timestamp__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../internal/operators/timestamp */ "r0WS");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Timestamp", function() { return _internal_operators_timestamp__WEBPACK_IMPORTED_MODULE_16__["Timestamp"]; });

/* harmony import */ var _internal_operators_timeInterval__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../internal/operators/timeInterval */ "4hIw");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TimeInterval", function() { return _internal_operators_timeInterval__WEBPACK_IMPORTED_MODULE_17__["TimeInterval"]; });

/* harmony import */ var _internal_operators_groupBy__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../internal/operators/groupBy */ "OQgR");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupedObservable", function() { return _internal_operators_groupBy__WEBPACK_IMPORTED_MODULE_18__["GroupedObservable"]; });

/* harmony import */ var _internal_operators_throttle__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../internal/operators/throttle */ "yuhW");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "defaultThrottleConfig", function() { return _internal_operators_throttle__WEBPACK_IMPORTED_MODULE_19__["defaultThrottleConfig"]; });

/* harmony import */ var _internal_symbol_rxSubscriber__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../internal/symbol/rxSubscriber */ "2QA8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "rxSubscriber", function() { return _internal_symbol_rxSubscriber__WEBPACK_IMPORTED_MODULE_20__["rxSubscriber"]; });

/* harmony import */ var _internal_symbol_iterator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../internal/symbol/iterator */ "Lhse");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "iterator", function() { return _internal_symbol_iterator__WEBPACK_IMPORTED_MODULE_21__["iterator"]; });

/* harmony import */ var _internal_symbol_observable__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../internal/symbol/observable */ "kJWO");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "observable", function() { return _internal_symbol_observable__WEBPACK_IMPORTED_MODULE_22__["observable"]; });

/* harmony import */ var _internal_util_ArgumentOutOfRangeError__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../internal/util/ArgumentOutOfRangeError */ "4I5i");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ArgumentOutOfRangeError", function() { return _internal_util_ArgumentOutOfRangeError__WEBPACK_IMPORTED_MODULE_23__["ArgumentOutOfRangeError"]; });

/* harmony import */ var _internal_util_EmptyError__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../internal/util/EmptyError */ "sVev");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EmptyError", function() { return _internal_util_EmptyError__WEBPACK_IMPORTED_MODULE_24__["EmptyError"]; });

/* harmony import */ var _internal_util_Immediate__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../internal/util/Immediate */ "c7jc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Immediate", function() { return _internal_util_Immediate__WEBPACK_IMPORTED_MODULE_25__["Immediate"]; });

/* harmony import */ var _internal_util_ObjectUnsubscribedError__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../internal/util/ObjectUnsubscribedError */ "9ppp");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ObjectUnsubscribedError", function() { return _internal_util_ObjectUnsubscribedError__WEBPACK_IMPORTED_MODULE_26__["ObjectUnsubscribedError"]; });

/* harmony import */ var _internal_util_TimeoutError__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../internal/util/TimeoutError */ "Y6u4");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TimeoutError", function() { return _internal_util_TimeoutError__WEBPACK_IMPORTED_MODULE_27__["TimeoutError"]; });

/* harmony import */ var _internal_util_UnsubscriptionError__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../internal/util/UnsubscriptionError */ "pjAE");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsubscriptionError", function() { return _internal_util_UnsubscriptionError__WEBPACK_IMPORTED_MODULE_28__["UnsubscriptionError"]; });

/* harmony import */ var _internal_util_applyMixins__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../internal/util/applyMixins */ "Of7M");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "applyMixins", function() { return _internal_util_applyMixins__WEBPACK_IMPORTED_MODULE_29__["applyMixins"]; });

/* harmony import */ var _internal_util_errorObject__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ../internal/util/errorObject */ "dJRF");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "errorObject", function() { return _internal_util_errorObject__WEBPACK_IMPORTED_MODULE_30__["errorObject"]; });

/* harmony import */ var _internal_util_hostReportError__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../internal/util/hostReportError */ "NJ4a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "hostReportError", function() { return _internal_util_hostReportError__WEBPACK_IMPORTED_MODULE_31__["hostReportError"]; });

/* harmony import */ var _internal_util_identity__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../internal/util/identity */ "SpAZ");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "identity", function() { return _internal_util_identity__WEBPACK_IMPORTED_MODULE_32__["identity"]; });

/* harmony import */ var _internal_util_isArray__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../internal/util/isArray */ "DH7j");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isArray", function() { return _internal_util_isArray__WEBPACK_IMPORTED_MODULE_33__["isArray"]; });

/* harmony import */ var _internal_util_isArrayLike__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../internal/util/isArrayLike */ "I55L");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isArrayLike", function() { return _internal_util_isArrayLike__WEBPACK_IMPORTED_MODULE_34__["isArrayLike"]; });

/* harmony import */ var _internal_util_isDate__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ../internal/util/isDate */ "mlxB");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isDate", function() { return _internal_util_isDate__WEBPACK_IMPORTED_MODULE_35__["isDate"]; });

/* harmony import */ var _internal_util_isFunction__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ../internal/util/isFunction */ "n6bG");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isFunction", function() { return _internal_util_isFunction__WEBPACK_IMPORTED_MODULE_36__["isFunction"]; });

/* harmony import */ var _internal_util_isIterable__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ../internal/util/isIterable */ "CMyj");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isIterable", function() { return _internal_util_isIterable__WEBPACK_IMPORTED_MODULE_37__["isIterable"]; });

/* harmony import */ var _internal_util_isNumeric__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ../internal/util/isNumeric */ "Y7HM");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isNumeric", function() { return _internal_util_isNumeric__WEBPACK_IMPORTED_MODULE_38__["isNumeric"]; });

/* harmony import */ var _internal_util_isObject__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../internal/util/isObject */ "XoHu");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isObject", function() { return _internal_util_isObject__WEBPACK_IMPORTED_MODULE_39__["isObject"]; });

/* harmony import */ var _internal_util_isInteropObservable__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ../internal/util/isInteropObservable */ "QIAL");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isObservable", function() { return _internal_util_isInteropObservable__WEBPACK_IMPORTED_MODULE_40__["isInteropObservable"]; });

/* harmony import */ var _internal_util_isPromise__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ../internal/util/isPromise */ "c2HN");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isPromise", function() { return _internal_util_isPromise__WEBPACK_IMPORTED_MODULE_41__["isPromise"]; });

/* harmony import */ var _internal_util_isScheduler__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ../internal/util/isScheduler */ "z+Ro");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "isScheduler", function() { return _internal_util_isScheduler__WEBPACK_IMPORTED_MODULE_42__["isScheduler"]; });

/* harmony import */ var _internal_util_noop__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ../internal/util/noop */ "KqfI");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return _internal_util_noop__WEBPACK_IMPORTED_MODULE_43__["noop"]; });

/* harmony import */ var _internal_util_not__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ../internal/util/not */ "F97/");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "not", function() { return _internal_util_not__WEBPACK_IMPORTED_MODULE_44__["not"]; });

/* harmony import */ var _internal_util_pipe__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ../internal/util/pipe */ "mCNh");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "pipe", function() { return _internal_util_pipe__WEBPACK_IMPORTED_MODULE_45__["pipe"]; });

/* harmony import */ var _internal_util_root__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ../internal/util/root */ "xJj7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "root", function() { return _internal_util_root__WEBPACK_IMPORTED_MODULE_46__["root"]; });

/* harmony import */ var _internal_util_subscribeTo__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ../internal/util/subscribeTo */ "SeVD");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "subscribeTo", function() { return _internal_util_subscribeTo__WEBPACK_IMPORTED_MODULE_47__["subscribeTo"]; });

/* harmony import */ var _internal_util_subscribeToArray__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ../internal/util/subscribeToArray */ "ngJS");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "subscribeToArray", function() { return _internal_util_subscribeToArray__WEBPACK_IMPORTED_MODULE_48__["subscribeToArray"]; });

/* harmony import */ var _internal_util_subscribeToIterable__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ../internal/util/subscribeToIterable */ "pLzU");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "subscribeToIterable", function() { return _internal_util_subscribeToIterable__WEBPACK_IMPORTED_MODULE_49__["subscribeToIterable"]; });

/* harmony import */ var _internal_util_subscribeToObservable__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ../internal/util/subscribeToObservable */ "CRDf");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "subscribeToObservable", function() { return _internal_util_subscribeToObservable__WEBPACK_IMPORTED_MODULE_50__["subscribeToObservable"]; });

/* harmony import */ var _internal_util_subscribeToPromise__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ../internal/util/subscribeToPromise */ "a7t3");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "subscribeToPromise", function() { return _internal_util_subscribeToPromise__WEBPACK_IMPORTED_MODULE_51__["subscribeToPromise"]; });

/* harmony import */ var _internal_util_subscribeToResult__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ../internal/util/subscribeToResult */ "ZUHj");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "subscribeToResult", function() { return _internal_util_subscribeToResult__WEBPACK_IMPORTED_MODULE_52__["subscribeToResult"]; });

/* harmony import */ var _internal_util_toSubscriber__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ../internal/util/toSubscriber */ "WyKG");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "toSubscriber", function() { return _internal_util_toSubscriber__WEBPACK_IMPORTED_MODULE_53__["toSubscriber"]; });

/* harmony import */ var _internal_util_tryCatch__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ../internal/util/tryCatch */ "mtqP");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "tryCatch", function() { return _internal_util_tryCatch__WEBPACK_IMPORTED_MODULE_54__["tryCatch"]; });
























































//# sourceMappingURL=index.js.map

/***/ }),

/***/ "wxn8":
/*!********************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/dom/WebSocketSubject.js ***!
  \********************************************************************************/
/*! exports provided: WebSocketSubject */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebSocketSubject", function() { return WebSocketSubject; });
/* harmony import */ var _Subject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../Subject */ "XNiG");
/* harmony import */ var _Subscriber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../Subscriber */ "7o/Q");
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../Observable */ "HDdC");
/* harmony import */ var _Subscription__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../Subscription */ "quSY");
/* harmony import */ var _ReplaySubject__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../ReplaySubject */ "jtHE");





const DEFAULT_WEBSOCKET_CONFIG = {
    url: '',
    deserializer: (e) => JSON.parse(e.data),
    serializer: (value) => JSON.stringify(value),
};
const WEBSOCKETSUBJECT_INVALID_ERROR_OBJECT = 'WebSocketSubject.error must be called with an object with an error code, and an optional reason: { code: number, reason: string }';
class WebSocketSubject extends _Subject__WEBPACK_IMPORTED_MODULE_0__["AnonymousSubject"] {
    constructor(urlConfigOrSource, destination) {
        super();
        if (urlConfigOrSource instanceof _Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"]) {
            this.destination = destination;
            this.source = urlConfigOrSource;
        }
        else {
            const config = this._config = Object.assign({}, DEFAULT_WEBSOCKET_CONFIG);
            this._output = new _Subject__WEBPACK_IMPORTED_MODULE_0__["Subject"]();
            if (typeof urlConfigOrSource === 'string') {
                config.url = urlConfigOrSource;
            }
            else {
                for (let key in urlConfigOrSource) {
                    if (urlConfigOrSource.hasOwnProperty(key)) {
                        config[key] = urlConfigOrSource[key];
                    }
                }
            }
            if (!config.WebSocketCtor && WebSocket) {
                config.WebSocketCtor = WebSocket;
            }
            else if (!config.WebSocketCtor) {
                throw new Error('no WebSocket constructor can be found');
            }
            this.destination = new _ReplaySubject__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]();
        }
    }
    lift(operator) {
        const sock = new WebSocketSubject(this._config, this.destination);
        sock.operator = operator;
        sock.source = this;
        return sock;
    }
    _resetState() {
        this._socket = null;
        if (!this.source) {
            this.destination = new _ReplaySubject__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]();
        }
        this._output = new _Subject__WEBPACK_IMPORTED_MODULE_0__["Subject"]();
    }
    multiplex(subMsg, unsubMsg, messageFilter) {
        const self = this;
        return new _Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"]((observer) => {
            try {
                self.next(subMsg());
            }
            catch (err) {
                observer.error(err);
            }
            const subscription = self.subscribe(x => {
                try {
                    if (messageFilter(x)) {
                        observer.next(x);
                    }
                }
                catch (err) {
                    observer.error(err);
                }
            }, err => observer.error(err), () => observer.complete());
            return () => {
                try {
                    self.next(unsubMsg());
                }
                catch (err) {
                    observer.error(err);
                }
                subscription.unsubscribe();
            };
        });
    }
    _connectSocket() {
        const { WebSocketCtor, protocol, url, binaryType } = this._config;
        const observer = this._output;
        let socket = null;
        try {
            socket = protocol ?
                new WebSocketCtor(url, protocol) :
                new WebSocketCtor(url);
            this._socket = socket;
            if (binaryType) {
                this._socket.binaryType = binaryType;
            }
        }
        catch (e) {
            observer.error(e);
            return;
        }
        const subscription = new _Subscription__WEBPACK_IMPORTED_MODULE_3__["Subscription"](() => {
            this._socket = null;
            if (socket && socket.readyState === 1) {
                socket.close();
            }
        });
        socket.onopen = (e) => {
            const { _socket } = this;
            if (!_socket) {
                socket.close();
                this._resetState();
                return;
            }
            const { openObserver } = this._config;
            if (openObserver) {
                openObserver.next(e);
            }
            const queue = this.destination;
            this.destination = _Subscriber__WEBPACK_IMPORTED_MODULE_1__["Subscriber"].create((x) => {
                if (socket.readyState === 1) {
                    try {
                        const { serializer } = this._config;
                        socket.send(serializer(x));
                    }
                    catch (e) {
                        this.destination.error(e);
                    }
                }
            }, (e) => {
                const { closingObserver } = this._config;
                if (closingObserver) {
                    closingObserver.next(undefined);
                }
                if (e && e.code) {
                    socket.close(e.code, e.reason);
                }
                else {
                    observer.error(new TypeError(WEBSOCKETSUBJECT_INVALID_ERROR_OBJECT));
                }
                this._resetState();
            }, () => {
                const { closingObserver } = this._config;
                if (closingObserver) {
                    closingObserver.next(undefined);
                }
                socket.close();
                this._resetState();
            });
            if (queue && queue instanceof _ReplaySubject__WEBPACK_IMPORTED_MODULE_4__["ReplaySubject"]) {
                subscription.add(queue.subscribe(this.destination));
            }
        };
        socket.onerror = (e) => {
            this._resetState();
            observer.error(e);
        };
        socket.onclose = (e) => {
            this._resetState();
            const { closeObserver } = this._config;
            if (closeObserver) {
                closeObserver.next(e);
            }
            if (e.wasClean) {
                observer.complete();
            }
            else {
                observer.error(e);
            }
        };
        socket.onmessage = (e) => {
            try {
                const { deserializer } = this._config;
                observer.next(deserializer(e));
            }
            catch (err) {
                observer.error(err);
            }
        };
    }
    _subscribe(subscriber) {
        const { source } = this;
        if (source) {
            return source.subscribe(subscriber);
        }
        if (!this._socket) {
            this._connectSocket();
        }
        this._output.subscribe(subscriber);
        subscriber.add(() => {
            const { _socket } = this;
            if (this._output.observers.length === 0) {
                if (_socket && _socket.readyState === 1) {
                    _socket.close();
                }
                this._resetState();
            }
        });
        return subscriber;
    }
    unsubscribe() {
        const { _socket } = this;
        if (_socket && _socket.readyState === 1) {
            _socket.close();
        }
        this._resetState();
        super.unsubscribe();
    }
}
//# sourceMappingURL=WebSocketSubject.js.map

/***/ }),

/***/ "x4c3":
/*!***********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/fromPromise.js ***!
  \***********************************************************************/
/*! exports provided: fromPromise */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fromPromise", function() { return fromPromise; });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Observable */ "HDdC");
/* harmony import */ var _util_subscribeToPromise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/subscribeToPromise */ "a7t3");
/* harmony import */ var _scheduled_schedulePromise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../scheduled/schedulePromise */ "4yVj");



function fromPromise(input, scheduler) {
    if (!scheduler) {
        return new _Observable__WEBPACK_IMPORTED_MODULE_0__["Observable"](Object(_util_subscribeToPromise__WEBPACK_IMPORTED_MODULE_1__["subscribeToPromise"])(input));
    }
    else {
        return Object(_scheduled_schedulePromise__WEBPACK_IMPORTED_MODULE_2__["schedulePromise"])(input, scheduler);
    }
}
//# sourceMappingURL=fromPromise.js.map

/***/ }),

/***/ "xJj7":
/*!**********************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/util/root.js ***!
  \**********************************************************/
/*! exports provided: root */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "root", function() { return _root; });
const __window = typeof window !== 'undefined' && window;
const __self = typeof self !== 'undefined' && typeof WorkerGlobalScope !== 'undefined' &&
    self instanceof WorkerGlobalScope && self;
const __global = typeof global !== 'undefined' && global;
const _root = __window || __global || __self;
(function () {
    if (!_root) {
        throw new Error('RxJS could not find any global context (window, self, global)');
    }
})();

//# sourceMappingURL=root.js.map

/***/ }),

/***/ "yrQ5":
/*!*****************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/components/add-spot-board/add-spot-board.component.scss ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".spot-board {\n  display: flex;\n  flex-direction: column;\n  padding: calc(var(--ion-padding) / 2) var(--ion-padding);\n  background-color: var(--ion-color-dark);\n  background-image: url(\"/../../assets/images/backgrouds/spot-board.png\");\n  background-position: right;\n  background-size: contain;\n  background-repeat: no-repeat;\n  border-radius: var(--theme-base-border-radius);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGFkZC1zcG90LWJvYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBRUEsd0RBQUE7RUFFQSx1Q0FBQTtFQUNBLHVFQUFBO0VBQ0EsMEJBQUE7RUFDQSx3QkFBQTtFQUNBLDRCQUFBO0VBRUEsOENBQUE7QUFGRiIsImZpbGUiOiJhZGQtc3BvdC1ib2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zcG90LWJvYXJkIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblxuICBwYWRkaW5nOiBjYWxjKHZhcigtLWlvbi1wYWRkaW5nKSAvIDIpIHZhcigtLWlvbi1wYWRkaW5nKTtcblxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi8uLi8uLi9hc3NldHMvaW1hZ2VzL2JhY2tncm91ZHMvc3BvdC1ib2FyZC5wbmdcIik7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IHJpZ2h0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG5cbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcbn1cbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=skateparks-skateparks-module-es2015.js.map