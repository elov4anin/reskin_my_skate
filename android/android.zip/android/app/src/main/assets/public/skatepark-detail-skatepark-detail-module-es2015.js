(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["skatepark-detail-skatepark-detail-module"],{

/***/ "1s5z":
/*!*******************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/closet-store/closet-store.component.scss ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".closest {\n  display: flex;\n}\n.closest__img {\n  width: 80px;\n  height: 72px;\n  background-color: var(--ion-color-primary);\n  background-image: url(\"/../../assets/images/closest.png\");\n  background-repeat: no-repeat;\n  background-size: contain;\n}\n.closest__store {\n  display: flex;\n  flex-direction: column;\n  margin-left: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGNsb3NldC1zdG9yZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7QUFDRjtBQUNFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFFQSwwQ0FBQTtFQUNBLHlEQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtBQUFKO0FBR0U7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtBQURKIiwiZmlsZSI6ImNsb3NldC1zdG9yZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jbG9zZXN0IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAmX19pbWcge1xyXG4gICAgd2lkdGg6IDgwcHg7XHJcbiAgICBoZWlnaHQ6IDcycHg7XHJcblxyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLy4uLy4uL2Fzc2V0cy9pbWFnZXMvY2xvc2VzdC5wbmdcIik7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xyXG4gIH1cclxuXHJcbiAgJl9fc3RvcmUge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBtYXJnaW4tbGVmdDogMTZweDtcclxuICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "2Pv0":
/*!*******************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/slider-photos/slider-photos.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: SliderPhotosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SliderPhotosComponent", function() { return SliderPhotosComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_slider_photos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./slider-photos.component.html */ "aNYs");
/* harmony import */ var _slider_photos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./slider-photos.component.scss */ "PjZN");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _demodata__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../demodata */ "96r+");





let SliderPhotosComponent = class SliderPhotosComponent {
    constructor() {
        this.slides = _demodata__WEBPACK_IMPORTED_MODULE_4__["sliders"];
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            loop: true,
            slidesPerView: 1,
            spaceBetween: 16,
            width: 375,
        };
    }
    ngOnInit() { }
};
SliderPhotosComponent.ctorParameters = () => [];
SliderPhotosComponent.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SliderPhotosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-slider-photos',
        template: _raw_loader_slider_photos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_slider_photos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SliderPhotosComponent);



/***/ }),

/***/ "3GIS":
/*!*********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/skatepark-detail/closet-store/closet-store.component.html ***!
  \*********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"closest\">\n  <div class=\"closest__img\">\n  </div>\n  <div class=\"closest__store\">\n    <ion-text class=\"mb4 text-16\" color=\"light\">Second Skate</ion-text>\n    <ion-text class=\"mb4 text-15\" color=\"medium\">West Alderman’s Walk</ion-text>\n    <ion-text class=\"text-15\" color=\"secondary\">3.1 miles</ion-text>\n  </div>\n</div>\n");

/***/ }),

/***/ "CJa6":
/*!*****************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/skatepark-detail.page.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-chip {\n  padding-inline: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcc2thdGVwYXJrLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSxpQkFBQTtBQURGIiwiZmlsZSI6InNrYXRlcGFyay1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5pb24tY2hpcCB7XHJcbiAgcGFkZGluZy1pbmxpbmU6IDA7XHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "GEdn":
/*!***********************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/modal-report-closure/modal-report-closure.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-input, ion-textarea {\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n}\n\nion-label {\n  white-space: normal !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLXJlcG9ydC1jbG9zdXJlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UseURBQUE7RUFDQSx1REFBQTtFQUNBLDBDQUFBO0VBQ0EsZ0NBQUE7RUFDQSw4QkFBQTtFQUNBLDhCQUFBO0VBQ0EsaUNBQUE7RUFDQSxnREFBQTtBQUNGOztBQUVBO0VBQ0UsOEJBQUE7QUFDRiIsImZpbGUiOiJtb2RhbC1yZXBvcnQtY2xvc3VyZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pbnB1dCwgaW9uLXRleHRhcmVhIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9uOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxufVxyXG5pb24tbGFiZWwge1xyXG4gIHdoaXRlLXNwYWNlOiBub3JtYWwgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "Jjiz":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/skatepark-detail/modal-report-closure/modal-report-closure.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion ion-margin-start title-20\">\n      Skatepark closure\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <form [formGroup]=\"form\" class=\"ion-margin-top ion-margin-end ion-margin-end\">\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">When did the skatepark close (or replaced)?</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"dateClosure\"></ion-input>\n    </ion-item>\n    <ion-item color=\"dark\" class=\"ion-margin-top\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Has the skatepark been removed or replaced or other?</ion-text>\n      </ion-label>\n      <ion-textarea rows=\"4\" placeholder=\"Type here\" formControlName=\"description\"></ion-textarea>\n    </ion-item>\n    <div class=\"ion-margin-start ion-margin-end ion-margin-top\">\n      <ion-text color=\"medium\" class=\"text-15\">\n        Are you sure you want to submit closure of this skate park? Temporary closures are NOT necessary. Skatepark closures will authorsied by an admin before being displayed on the App.\n      </ion-text>\n\n      <ion-button\n              color=\"secondary\"\n              expand=\"block\"\n              class=\"ion-margin-top\"\n              (click)=\"closeModal()\"\n              [disabled]=\"form.invalid\"\n      >\n        <ion-text color=\"light\" class=\"text-15-500\">Submit closure</ion-text>\n      </ion-button>\n\n      <ion-button color=\"dark\" expand=\"block\" class=\"mt12\" (click)=\"closeModal()\">\n        <ion-text color=\"danger\" class=\"text-16\" (click)=\"closeModal()\">Cancel</ion-text>\n      </ion-button>\n\n    </div>\n\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "Kr6v":
/*!*********************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/modal-report-closure/modal-report-closure.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: ModalReportClosureComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalReportClosureComponent", function() { return ModalReportClosureComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_report_closure_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-report-closure.component.html */ "Jjiz");
/* harmony import */ var _modal_report_closure_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-report-closure.component.scss */ "GEdn");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");






let ModalReportClosureComponent = class ModalReportClosureComponent {
    constructor(_modalController) {
        this._modalController = _modalController;
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            dateClosure: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]),
            description: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]),
        });
    }
    ngOnInit() { }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
};
ModalReportClosureComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ModalReportClosureComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-report-closure',
        template: _raw_loader_modal_report_closure_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_report_closure_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalReportClosureComponent);



/***/ }),

/***/ "PAk5":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/skatepark-detail/skatepark-detail.page.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout\n        [isNeedRightPadding]=\"false\"\n        [isNeedLeftPadding]=\"false\"\n        [isNotNeedPaddingTopHeader]=\"true\"\n>\n    <ion-grid class=\"ion-padding-start ion-padding-end mb12\">\n        <ion-row>\n            <ion-col class=\"p0\" size=\"6\">\n                <ion-icon\n                        class=\"icon-as-btn\"\n                        color=\"secondary\"\n                        name=\"arrow-back-outline\"\n                        size=\"large\"\n                        (click)=\"back()\"\n                ></ion-icon>\n            </ion-col>\n            <ion-col class=\"p0\" size=\"4\" offset=\"2\">\n                <ion-chip color=\"primary\">\n                    <ion-icon color=\"secondary\" name=\"location-outline\"></ion-icon>\n                    <ion-label color=\"secondary\"  class=\"text-16\">Location</ion-label>\n                </ion-chip>\n            </ion-col>\n        </ion-row>\n        <ion-row>\n            <ion-col class=\"p0\">\n                <ion-text color=\"light\" class=\"title-28\">{{skatepark?.name}}</ion-text>\n            </ion-col>\n        </ion-row>\n        <ion-row>\n            <ion-col class=\"p0\">\n                <ion-text color=\"light\"  class=\"text-15\">{{skatepark?.city}}</ion-text>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n    <app-slider-photos [slides]=\"slides\"></app-slider-photos>\n    <ion-grid class=\"ion-padding-start ion-padding-end mt16\">\n        <ion-row>\n            <ion-col class=\"p0\" size=\"9\">\n                <ion-button expand=\"block\" color=\"dark\">Add Photos</ion-button>\n            </ion-col>\n            <ion-col class=\"p0\" offset=\"1\" size=\"2\">\n                <ion-button color=\"dark\" (click)=\"addFavourite(skatepark)\">\n                    <ion-icon\n                            slot=\"icon-only\"\n                            [color]=\"skatepark.is_favourite ? 'secondary': 'light'\"\n                            [name]=\"skatepark.is_favourite ? 'heart' : 'heart-outline'\"\n                    ></ion-icon>\n                </ion-button>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n\n    <div class=\"divisor mt16 mb16\"></div>\n    <section class=\"ion-padding-start ion-padding-end d-flex ion-justify-content-between ion-align-items-center \">\n        <ionic-rating-component\n                #rating\n                activeIcon = \"star\"\n                defaultIcon = \"star-outline\"\n                [activeColor] = activeRatingColor\n                [defaultColor] = defaultRatingColor\n                readonly=\"true\"\n                [rating]=\"skatepark.rating\"\n                fontSize = \"16px\">\n        </ionic-rating-component>\n        <ion-text color=\"light\" class=\"text-16 text--underline\">Read all ratings</ion-text>\n    </section>\n    <div class=\"divisor mt16 mb16\"></div>\n    <section class=\"ion-padding-start\">\n        <app-slider-features [slides]=\"featuresSlides\"></app-slider-features>\n    </section>\n    <section class=\"ion-margin-top ion-padding-start ion-padding-end d-flex flex-column\">\n        <header class=\"mb16\">\n            <ion-text color=\"light\" class=\"title-18\">Closest skate store</ion-text>\n        </header>\n        <app-closet-store>\n        </app-closet-store>\n    </section>\n    <div class=\"divisor mt16 mb16\"></div>\n    <section class=\"ion-padding-start ion-padding-end ion-text-center\">\n        <ion-text color=\"danger\" class=\"text-hover\" (click)=\"openModalReportClosure()\">Report park closure</ion-text>\n    </section>\n</app-mail-layout>\n");

/***/ }),

/***/ "PjZN":
/*!*********************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/slider-photos/slider-photos.component.scss ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".slide {\n  position: relative;\n  min-width: 375px;\n  background-repeat: no-repeat;\n}\n.slide__img {\n  height: 240px;\n  width: auto;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  background-color: var(--ion-color-tertiary);\n  border-radius: var(--theme-base-border-radius);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHNsaWRlci1waG90b3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7QUFDRjtBQUNFO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7RUFDQSwyQ0FBQTtFQUNBLDhDQUFBO0FBQ0oiLCJmaWxlIjoic2xpZGVyLXBob3Rvcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zbGlkZSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG1pbi13aWR0aDogMzc1cHg7XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuXHJcbiAgJl9faW1nIHtcclxuICAgIGhlaWdodDogMjQwcHg7XHJcbiAgICB3aWR0aDogYXV0bztcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IHZhcigtLXRoZW1lLWJhc2UtYm9yZGVyLXJhZGl1cyk7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "Zt3W":
/*!*************************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/slider-features/slider-features.component.scss ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".slider-block {\n  margin-top: calc(var(--theme-base-margin) * 6);\n}\n\n.slide {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  min-width: 80px;\n  height: 90px;\n  background-color: var(--ion-color-dark);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.slide__img {\n  height: 28px;\n  width: 28px;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n}\n\n.slide__wrap {\n  display: block;\n  width: 80px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  text-align: center;\n}\n\nion-progress-bar {\n  --buffer-background: var(--ion-color-dark-tint);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHNsaWRlci1mZWF0dXJlcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLDhDQUFBO0FBQUY7O0FBSUE7RUFDRSxrQkFBQTtFQUVBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUVBLHVDQUFBO0VBQ0EsOENBQUE7QUFIRjs7QUFLRTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0FBSEo7O0FBTUU7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUVBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBTEo7O0FBUUE7RUFDRSwrQ0FBQTtBQUxGIiwiZmlsZSI6InNsaWRlci1mZWF0dXJlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uc2xpZGVyLWJsb2NrIHtcclxuICBtYXJnaW4tdG9wOiBjYWxjKHZhcigtLXRoZW1lLWJhc2UtbWFyZ2luKSAqIDYpO1xyXG59XHJcblxyXG5cclxuLnNsaWRlIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1pbi13aWR0aDogODBweDtcclxuICBoZWlnaHQ6IDkwcHg7XHJcblxyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICBib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxuICAmX19pbWcge1xyXG4gICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgd2lkdGg6IDI4cHg7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICB9XHJcblxyXG4gICZfX3dyYXAge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB3aWR0aDogODBweDtcclxuXHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxufVxyXG5pb24tcHJvZ3Jlc3MtYmFyIHtcclxuICAtLWJ1ZmZlci1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "aNYs":
/*!***********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/skatepark-detail/slider-photos/slider-photos.component.html ***!
  \***********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-slides #slider pager=\"false\" [options]=\"slideOpts\" class=\"custom-slides\" pager=\"true\">\n  <ion-slide *ngFor =\" let slide of slides\">\n    <div class=\"slide\" >\n      <div class=\"slide__img\"  [ngStyle]=\"{'background-image':'url('+slide.imgSrc+')'}\"></div>\n      <!--  <img src=\"{{slide.imgSrc}}\">-->\n    </div>\n  </ion-slide>\n</ion-slides>\n");

/***/ }),

/***/ "e0uL":
/*!***********************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/slider-features/slider-features.component.ts ***!
  \***********************************************************************************************/
/*! exports provided: SliderFeaturesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SliderFeaturesComponent", function() { return SliderFeaturesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_slider_features_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./slider-features.component.html */ "fJKM");
/* harmony import */ var _slider_features_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./slider-features.component.scss */ "Zt3W");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SliderFeaturesComponent = class SliderFeaturesComponent {
    constructor() {
        this.title = 'Features';
        this.slides = [];
        this.isNeedRating = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            loop: false,
            slidesPerView: 1,
            spaceBetween: 20,
            width: 80
        };
        this.defaultRatingColor = getComputedStyle(document.documentElement)
            .getPropertyValue('--ion-color-light');
        this.activeRatingColor = getComputedStyle(document.documentElement)
            .getPropertyValue('--ion-color-secondary');
        this.progress = 0;
    }
    ngOnInit() {
    }
    ionSlideDidChange() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const idx = yield this.sliderRef.getActiveIndex();
            if (idx > this.slides.length) {
                this.progress = 0;
                return;
            }
            this.progress = idx / this.slides.length;
        });
    }
};
SliderFeaturesComponent.ctorParameters = () => [];
SliderFeaturesComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    isNeedRating: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    sliderRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slider',] }]
};
SliderFeaturesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-slider-features',
        template: _raw_loader_slider_features_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_slider_features_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SliderFeaturesComponent);



/***/ }),

/***/ "fJKM":
/*!***************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/skateparks/skatepark-detail/slider-features/slider-features.component.html ***!
  \***************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<section class=\"slider-block\">\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center mb16 ion-padding-end\">\n    <ion-text class=\"title-18\">{{title}}</ion-text>\n    <ion-progress-bar color=\"secondary\" [value]=\"progress\" style=\"width: 56px\"></ion-progress-bar>\n  </header>\n\n  <div class=\"slider-block__list\">\n    <ion-slides\n            #slider\n            [options]=\"slideOpts\"\n            class=\"custom-slides\"\n            (ionSlideNextStart)=\"ionSlideDidChange()\"\n            (ionSlidePrevStart)=\"ionSlideDidChange()\"\n    >\n      <ion-slide *ngFor =\" let slide of slides\">\n        <div class=\"slide\">\n          <div class=\"slide__img\"  [ngStyle]=\"{'background-image':'url('+slide?.imgSrc+')'}\"></div>\n          <!--  <img src=\"{{slide.imgSrc}}\">-->\n          <div class=\"slide__wrap\">\n            <span class=\"text-10-500\">\n                {{slide?.title}}\n              </span>\n          </div>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n</section>\n");

/***/ }),

/***/ "jD5F":
/*!***************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/skatepark-detail.page.ts ***!
  \***************************************************************************/
/*! exports provided: SkateparkDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkateparkDetailPage", function() { return SkateparkDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_skatepark_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./skatepark-detail.page.html */ "PAk5");
/* harmony import */ var _skatepark_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skatepark-detail.page.scss */ "CJa6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_report_closure_modal_report_closure_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modal-report-closure/modal-report-closure.component */ "Kr6v");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/configs/main.config */ "phI0");
/* harmony import */ var _feature_heper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./feature.heper */ "xidA");










let SkateparkDetailPage = class SkateparkDetailPage {
    constructor(_location, _modalController, _coreStore) {
        this._location = _location;
        this._modalController = _modalController;
        this._coreStore = _coreStore;
        this.isFavor = false;
        this.defaultRatingColor = getComputedStyle(document.documentElement)
            .getPropertyValue('--ion-color-light');
        this.activeRatingColor = getComputedStyle(document.documentElement)
            .getPropertyValue('--ion-color-secondary');
        this.featuresSlides = [];
        this.slides = [];
    }
    ngOnInit() {
        this.skatepark = this._coreStore.state.selectedSkatepark;
        this.featuresSlides = Object(_feature_heper__WEBPACK_IMPORTED_MODULE_9__["prepareFeatures"])(this.skatepark);
        this.featuresSlides = Object(_feature_heper__WEBPACK_IMPORTED_MODULE_9__["addToFeatures"])(this.skatepark, this.featuresSlides);
        if (this.skatepark.has_images === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_8__["TRUE_VALUE"]) {
            this.slides = this.skatepark.images.map(image => {
                return { imgSrc: image };
            });
        }
        console.log(this.skatepark);
    }
    back() {
        this._location.back();
    }
    addFavourite(skatepark) {
        skatepark.is_favourite = !skatepark.is_favourite;
    }
    openModalReportClosure() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modal_report_closure_modal_report_closure_component__WEBPACK_IMPORTED_MODULE_6__["ModalReportClosureComponent"],
                cssClass: 'modal-report-closure'
            });
            return yield modal.present();
        });
    }
};
SkateparkDetailPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__["CoreStore"] }
];
SkateparkDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-skatepark-detail',
        template: _raw_loader_skatepark_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_skatepark_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SkateparkDetailPage);



/***/ }),

/***/ "jl5R":
/*!*************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/skatepark-detail-routing.module.ts ***!
  \*************************************************************************************/
/*! exports provided: SkateparkDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkateparkDetailPageRoutingModule", function() { return SkateparkDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _skatepark_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./skatepark-detail.page */ "jD5F");




const routes = [
    {
        path: '',
        component: _skatepark_detail_page__WEBPACK_IMPORTED_MODULE_3__["SkateparkDetailPage"]
    }
];
let SkateparkDetailPageRoutingModule = class SkateparkDetailPageRoutingModule {
};
SkateparkDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SkateparkDetailPageRoutingModule);



/***/ }),

/***/ "o0p/":
/*!*****************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/skatepark-detail.module.ts ***!
  \*****************************************************************************/
/*! exports provided: SkateparkDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkateparkDetailPageModule", function() { return SkateparkDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _skatepark_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./skatepark-detail-routing.module */ "jl5R");
/* harmony import */ var _skatepark_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./skatepark-detail.page */ "jD5F");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/shared.module */ "PCNd");
/* harmony import */ var _slider_photos_slider_photos_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./slider-photos/slider-photos.component */ "2Pv0");
/* harmony import */ var _slider_features_slider_features_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./slider-features/slider-features.component */ "e0uL");
/* harmony import */ var _closet_store_closet_store_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./closet-store/closet-store.component */ "vfH5");
/* harmony import */ var _modal_report_closure_modal_report_closure_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./modal-report-closure/modal-report-closure.component */ "Kr6v");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "3Pt+");










let SkateparkDetailPageModule = class SkateparkDetailPageModule {
};
SkateparkDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _skatepark_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__["SkateparkDetailPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ReactiveFormsModule"]
        ],
        declarations: [
            _skatepark_detail_page__WEBPACK_IMPORTED_MODULE_3__["SkateparkDetailPage"],
            _slider_photos_slider_photos_component__WEBPACK_IMPORTED_MODULE_5__["SliderPhotosComponent"],
            _slider_features_slider_features_component__WEBPACK_IMPORTED_MODULE_6__["SliderFeaturesComponent"],
            _closet_store_closet_store_component__WEBPACK_IMPORTED_MODULE_7__["ClosetStoreComponent"],
            _modal_report_closure_modal_report_closure_component__WEBPACK_IMPORTED_MODULE_8__["ModalReportClosureComponent"],
        ]
    })
], SkateparkDetailPageModule);



/***/ }),

/***/ "vfH5":
/*!*****************************************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/closet-store/closet-store.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: ClosetStoreComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClosetStoreComponent", function() { return ClosetStoreComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_closet_store_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./closet-store.component.html */ "3GIS");
/* harmony import */ var _closet_store_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./closet-store.component.scss */ "1s5z");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let ClosetStoreComponent = class ClosetStoreComponent {
    constructor() { }
    ngOnInit() { }
};
ClosetStoreComponent.ctorParameters = () => [];
ClosetStoreComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-closet-store',
        template: _raw_loader_closet_store_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_closet_store_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ClosetStoreComponent);



/***/ }),

/***/ "xidA":
/*!*******************************************************************!*\
  !*** ./src/app/tabs/skateparks/skatepark-detail/feature.heper.ts ***!
  \*******************************************************************/
/*! exports provided: FeaturesSkateparkEnum, featuresSlides, prepareFeatures, addToFeatures */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeaturesSkateparkEnum", function() { return FeaturesSkateparkEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "featuresSlides", function() { return featuresSlides; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "prepareFeatures", function() { return prepareFeatures; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addToFeatures", function() { return addToFeatures; });
/* harmony import */ var _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/configs/main.config */ "phI0");
/* harmony import */ var _shared_helpers_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/helpers/utils */ "Ua8l");


var FeaturesSkateparkEnum;
(function (FeaturesSkateparkEnum) {
    FeaturesSkateparkEnum["TOILET"] = "toilet";
    FeaturesSkateparkEnum["STORE"] = "store";
    FeaturesSkateparkEnum["PAID"] = "paid";
    FeaturesSkateparkEnum["FREE"] = "free";
    FeaturesSkateparkEnum["UNDERCOVER"] = "undercover";
    FeaturesSkateparkEnum["CAFE"] = "cafe";
    FeaturesSkateparkEnum["LIGHTING"] = "lighting";
    FeaturesSkateparkEnum["LOCKER"] = "locker";
    FeaturesSkateparkEnum["RELAXING_AREA"] = "relaxing_area";
    FeaturesSkateparkEnum["VIEWING_AREA"] = "viewing_area";
})(FeaturesSkateparkEnum || (FeaturesSkateparkEnum = {}));
const FeaturesSkatepark = Object(_shared_helpers_utils__WEBPACK_IMPORTED_MODULE_1__["getEnumAsArray"])(FeaturesSkateparkEnum);
const featuresSlides = [
    {
        title: 'Lightning',
        imgSrc: '/assets/images/features_icons/lightning.svg',
        type: FeaturesSkateparkEnum.LIGHTING
    },
    {
        title: 'Cafe',
        imgSrc: '/assets/images/features_icons/cafe.svg',
        type: FeaturesSkateparkEnum.CAFE
    },
    {
        title: 'Locker',
        imgSrc: '/assets/images/features_icons/lock.svg',
        type: FeaturesSkateparkEnum.LOCKER
    },
    {
        title: 'Paid',
        imgSrc: '/assets/images/features_icons/paid.svg',
        type: FeaturesSkateparkEnum.PAID
    },
    {
        title: 'Store',
        imgSrc: '/assets/images/features_icons/store.svg',
        type: FeaturesSkateparkEnum.STORE
    },
    {
        title: 'Free',
        imgSrc: '/assets/images/features_icons/free.svg',
        type: FeaturesSkateparkEnum.FREE
    },
    {
        title: 'Undercover',
        imgSrc: '/assets/images/features_icons/secret.svg',
        type: FeaturesSkateparkEnum.UNDERCOVER
    },
    {
        title: 'Toilet',
        imgSrc: '/assets/images/features_icons/wc.svg',
        type: FeaturesSkateparkEnum.TOILET
    },
    {
        title: 'Relaxing area',
        imgSrc: '/assets/images/features_icons/relax.svg',
        type: FeaturesSkateparkEnum.RELAXING_AREA
    },
    {
        title: 'Viewing area',
        imgSrc: '/assets/images/features_icons/view.svg',
        type: FeaturesSkateparkEnum.VIEWING_AREA
    },
];
function prepareFeatures(skatepark) {
    let slides = [];
    Object.keys(skatepark).forEach(skateparkKey => {
        if (checkFeature(skateparkKey, skatepark)) {
            slides = slides.concat(featuresSlides.filter(f => f.type === skateparkKey));
        }
    });
    return slides;
}
function addToFeatures(skatepark, slides) {
    if (skatepark.outdoors === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__["TRUE_VALUE"]) {
        slides.push({
            title: 'Outdoors',
            imgSrc: '/assets/images/features_icons/outside.svg',
            type: 'outdoors'
        });
    }
    if (skatepark.indoors === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__["TRUE_VALUE"]) {
        slides.push({
            title: 'Indoors',
            imgSrc: '/assets/images/features_icons/inside.svg',
            type: 'indoors'
        });
    }
    if (skatepark.concrete === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__["TRUE_VALUE"]) {
        slides.push({
            title: 'Concrete',
            imgSrc: '/assets/images/features_icons/concrete-mixer.svg',
            type: 'concrete'
        });
    }
    if (skatepark.wood === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__["TRUE_VALUE"]) {
        slides.push({
            title: 'Wood',
            imgSrc: '/assets/images/features_icons/board.svg',
            type: 'wood'
        });
    }
    if (skatepark.skatelite === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__["TRUE_VALUE"]) {
        slides.push({
            title: 'Skatelite',
            imgSrc: '/assets/images/features_icons/skateboard.svg',
            type: 'skatelite'
        });
    }
    return slides;
}
function checkFeature(key, skatepark) {
    return FeaturesSkatepark.includes(key) && skatepark[key] === _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_0__["TRUE_VALUE"];
}


/***/ })

}]);
//# sourceMappingURL=skatepark-detail-skatepark-detail-module-es2015.js.map