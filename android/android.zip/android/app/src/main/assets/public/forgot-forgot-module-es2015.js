(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forgot-forgot-module"],{

/***/ "CY9t":
/*!************************************************************!*\
  !*** ./src/app/pages/auth/forgot/forgot-routing.module.ts ***!
  \************************************************************/
/*! exports provided: ForgotPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPageRoutingModule", function() { return ForgotPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _forgot_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot.page */ "aQor");




const routes = [
    {
        path: '',
        component: _forgot_page__WEBPACK_IMPORTED_MODULE_3__["ForgotPage"]
    }
];
let ForgotPageRoutingModule = class ForgotPageRoutingModule {
};
ForgotPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ForgotPageRoutingModule);



/***/ }),

/***/ "XYNV":
/*!****************************************************!*\
  !*** ./src/app/pages/auth/forgot/forgot.page.scss ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  margin-top: 38px;\n}\n\nion-input {\n  margin-top: 12px;\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.apply-btn {\n  width: 100%;\n  max-width: 320px;\n  margin-top: 40px;\n}\n\nion-item {\n  --inner-padding-end: 0;\n  --inner-padding-bottom: var(--ion-margin);\n  margin-right: 5px;\n  --padding-start: 0;\n}\n\n.forgot-btn {\n  --padding-top: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  --padding-bottom: 0;\n  height: 1.3em;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcZm9yZ290LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwwQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLGlDQUFBO0VBQ0EsZ0RBQUE7RUFDQSw4Q0FBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLHNCQUFBO0VBQ0EseUNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRUY7O0FBQUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBR0YiLCJmaWxlIjoiZm9yZ290LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xyXG4gIG1hcmdpbi10b3A6IDM4cHg7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgbWFyZ2luLXRvcDogMTJweDtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9uOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG4gIGJvcmRlci1yYWRpdXM6IHZhcigtLXRoZW1lLWJhc2UtYm9yZGVyLXJhZGl1cyk7XHJcbn1cclxuXHJcbi5hcHBseS1idG4ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1heC13aWR0aDogMzIwcHg7XHJcbiAgbWFyZ2luLXRvcDogNDBweDtcclxufVxyXG5pb24taXRlbSB7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcclxuICAtLWlubmVyLXBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tbWFyZ2luKTtcclxuICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbn1cclxuLmZvcmdvdC1idG4ge1xyXG4gIC0tcGFkZGluZy10b3A6IDA7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbTogMDtcclxuICBoZWlnaHQ6IDEuM2VtO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "Ykc6":
/*!****************************************************!*\
  !*** ./src/app/pages/auth/forgot/forgot.module.ts ***!
  \****************************************************/
/*! exports provided: ForgotPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPageModule", function() { return ForgotPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _forgot_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./forgot-routing.module */ "CY9t");
/* harmony import */ var _forgot_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot.page */ "aQor");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/shared.module */ "PCNd");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");






let ForgotPageModule = class ForgotPageModule {
};
ForgotPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _forgot_routing_module__WEBPACK_IMPORTED_MODULE_2__["ForgotPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"]
        ],
        declarations: [_forgot_page__WEBPACK_IMPORTED_MODULE_3__["ForgotPage"]]
    })
], ForgotPageModule);



/***/ }),

/***/ "aQor":
/*!**************************************************!*\
  !*** ./src/app/pages/auth/forgot/forgot.page.ts ***!
  \**************************************************/
/*! exports provided: ForgotPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPage", function() { return ForgotPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_forgot_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./forgot.page.html */ "nivt");
/* harmony import */ var _forgot_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./forgot.page.scss */ "XYNV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth-routes.enum */ "mKaM");
/* harmony import */ var _shared_configs_response_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/configs/response.constants */ "N7aL");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../auth.service */ "zbnG");
/* harmony import */ var _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/helpers/toast-notification.service */ "b3vI");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _shared_classes_validation_messages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/classes/validation-messages */ "AEGu");













let ForgotPage = class ForgotPage {
    constructor(_router, _authService, _toast) {
        this._router = _router;
        this._authService = _authService;
        this._toast = _toast;
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].email]),
        });
        this.isReqSending = false;
        this.validationMessages = _shared_classes_validation_messages__WEBPACK_IMPORTED_MODULE_12__["VALIDATION_MESSAGES"];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_11__["Subject"]();
    }
    ngOnInit() {
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    openLogin() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].ROOT, _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].LOGIN]);
        });
    }
    reset() {
        this.isReqSending = true;
        this._authService.forgot(this.form.value)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["takeUntil"])(this.componentDestroyed))
            .subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isReqSending = false;
            if (res.response_code === _shared_configs_response_constants__WEBPACK_IMPORTED_MODULE_7__["RESPONSE_CODES"].SUCCESS) {
                yield this._toast.success(res.response_msg);
                yield this._router.navigate(['/', _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].ROOT, _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].LOGIN]);
            }
            else {
                yield this._toast.error(res.response_msg);
            }
        }));
    }
};
ForgotPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"] },
    { type: _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_9__["ToastNotificationService"] }
];
ForgotPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-forgot',
        template: _raw_loader_forgot_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_forgot_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ForgotPage);



/***/ }),

/***/ "nivt":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/auth/forgot/forgot.page.html ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout [isNeeBackBtn]=\"false\" [footerSlot]=\"footer\" [isNeedHeightWithTabsAndHeader]=\"true\">\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center ion-margin-bottom header\">\n    <ion-text color=\"light\" class=\"title-20\">Forgot password</ion-text>\n  </header>\n\n  <div class=\"ion-margin-top\">\n    <ion-text color=\"tertiary\" class=\"text-15\">We just need your registered email address to send you password reset instructions</ion-text>\n  </div>\n\n  <form [formGroup]=\"form\" class=\"ion-margin-top\">\n    <ion-item color=\"primary\" lines=\"none\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Email</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"email\"\n                 [ngClass]=\"{'invalid-input': form.get('email').touched && form.get('email').invalid}\"\n      ></ion-input>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.email\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('email').hasError(validation.type) && (form.get('email').dirty || form.get('email').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <ion-button\n            [disabled]=\"form.invalid\"\n            (click)=\"reset()\"\n            class=\"mb12 apply-btn\"\n            fill=\"solid\" color=\"success\" expand=\"block\"\n    >\n      <ng-container *ngIf=\"isReqSending; else textBlock\">\n        <ion-spinner name=\"lines-small\"></ion-spinner>Sending...\n      </ng-container>\n      <ng-template #textBlock>\n        Reset\n      </ng-template>\n    </ion-button>\n  </form>\n\n  <ng-template #footer>\n    <ion-footer>\n      <ion-toolbar color=\"primary\">\n        <ion-text (click)=\"openLogin()\" class=\"text-15 d-block ion-text-center\" color=\"secondary\">Back to Log in</ion-text>\n      </ion-toolbar>\n    </ion-footer>\n  </ng-template>\n\n</app-mail-layout>\n");

/***/ })

}]);
//# sourceMappingURL=forgot-forgot-module-es2015.js.map