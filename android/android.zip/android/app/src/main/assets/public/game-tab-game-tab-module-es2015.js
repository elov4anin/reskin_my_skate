(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["game-tab-game-tab-module"],{

/***/ "+R0m":
/*!***********************************************************************!*\
  !*** ./src/app/tabs/game-tab/components/person/person.component.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".person {\n  width: 44px;\n  height: 44px;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: contain;\n  border-radius: 50%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHBlcnNvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBRUEsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0Esa0JBQUE7QUFBRiIsImZpbGUiOiJwZXJzb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGVyc29uIHtcbiAgd2lkdGg6IDQ0cHg7XG4gIGhlaWdodDogNDRweDtcblxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuIl19 */");

/***/ }),

/***/ "3zGi":
/*!***************************************************************************!*\
  !*** ./src/app/tabs/game-tab/modals/modal-howto/modal-howto.component.ts ***!
  \***************************************************************************/
/*! exports provided: ModalHowtoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalHowtoComponent", function() { return ModalHowtoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_howto_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-howto.component.html */ "Y3qx");
/* harmony import */ var _modal_howto_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-howto.component.scss */ "WTLA");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let ModalHowtoComponent = class ModalHowtoComponent {
    constructor(_modalController) {
        this._modalController = _modalController;
    }
    ngOnInit() { }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
};
ModalHowtoComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ModalHowtoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-howto',
        template: _raw_loader_modal_howto_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_howto_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalHowtoComponent);



/***/ }),

/***/ "4jh1":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/game-tab/components/person/person.component.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"person\"  [ngStyle]=\"{'background-image':'url(assets/images/person.png)'}\"></div>\n");

/***/ }),

/***/ "4n5D":
/*!**************************************************!*\
  !*** ./src/app/tabs/game-tab/game-tab.page.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("app-checkbox-list {\n  width: 100%;\n}\n\nion-avatar {\n  width: 44px;\n  height: 44px;\n}\n\n.person {\n  margin-left: -4px;\n}\n\n.person--add {\n  position: relative;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 44px;\n  height: 44px;\n  border-radius: 50%;\n  background: var(--ion-color-dark);\n}\n\n.person--add ion-icon {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxnYW1lLXRhYi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUNBO0VBQ0UsaUJBQUE7QUFFRjs7QUFBRTtFQUNFLGtCQUFBO0VBRUEsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUVBLGtCQUFBO0VBQ0EsaUNBQUE7QUFESjs7QUFHSTtFQUNFLGVBQUE7QUFETiIsImZpbGUiOiJnYW1lLXRhYi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJhcHAtY2hlY2tib3gtbGlzdCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbmlvbi1hdmF0YXIge1xyXG4gIHdpZHRoOiA0NHB4O1xyXG4gIGhlaWdodDogNDRweDtcclxufVxyXG4ucGVyc29uIHtcclxuICBtYXJnaW4tbGVmdDogLTRweDtcclxuXHJcbiAgJi0tYWRkIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIHdpZHRoOiA0NHB4O1xyXG4gICAgaGVpZ2h0OiA0NHB4O1xyXG5cclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuXHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "DVDl":
/*!***************************************************************************************!*\
  !*** ./src/app/tabs/game-tab/modals/modal-add-players/modal-add-players.component.ts ***!
  \***************************************************************************************/
/*! exports provided: ModalAddPlayersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalAddPlayersComponent", function() { return ModalAddPlayersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_add_players_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-add-players.component.html */ "Pu85");
/* harmony import */ var _modal_add_players_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-add-players.component.scss */ "if0f");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let ModalAddPlayersComponent = class ModalAddPlayersComponent {
    constructor(_modalController) {
        this._modalController = _modalController;
    }
    ngOnInit() { }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
    removePlayer() {
        this.players.pop();
    }
    addPlayer() {
    }
    savePlayers() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss({
                players: this.players
            });
        });
    }
    showProfile() {
    }
};
ModalAddPlayersComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ModalAddPlayersComponent.propDecorators = {
    players: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
ModalAddPlayersComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-add-players',
        template: _raw_loader_modal_add_players_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_add_players_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalAddPlayersComponent);



/***/ }),

/***/ "FWgI":
/*!***********************************************!*\
  !*** ./src/app/tabs/game-tab/difficulties.ts ***!
  \***********************************************/
/*! exports provided: difficulties */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "difficulties", function() { return difficulties; });
const difficulties = [
    {
        id: 1,
        name: 'Easy',
        icon: 'assets/images/game/easy.svg',
        iconSelected: 'assets/images/game/easy-active.svg',
        isSelected: false
    },
    {
        id: 2,
        name: 'Medium',
        icon: 'assets/images/game/medium.svg',
        iconSelected: 'assets/images/game/medium-active.svg',
        isSelected: true
    },
    {
        id: 3,
        name: 'Hard',
        icon: 'assets/images/game/hard.svg',
        iconSelected: 'assets/images/game/hard-active.svg',
        isSelected: false
    }
];


/***/ }),

/***/ "HFI4":
/*!**************************************************!*\
  !*** ./src/app/tabs/game-tab/game-tab.module.ts ***!
  \**************************************************/
/*! exports provided: GameTabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GameTabPageModule", function() { return GameTabPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/shared.module */ "PCNd");
/* harmony import */ var _components_difficulty_difficulty_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/difficulty/difficulty.component */ "uLVO");
/* harmony import */ var _components_person_person_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/person/person.component */ "Tpvn");
/* harmony import */ var _modals_modal_howto_modal_howto_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modals/modal-howto/modal-howto.component */ "3zGi");
/* harmony import */ var _modals_modal_add_players_modal_add_players_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modals/modal-add-players/modal-add-players.component */ "DVDl");
/* harmony import */ var _game_tab_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./game-tab-routing.module */ "v7W0");
/* harmony import */ var _game_tab_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./game-tab.page */ "Ou0j");









let GameTabPageModule = class GameTabPageModule {
};
GameTabPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__["SharedModule"],
            _game_tab_routing_module__WEBPACK_IMPORTED_MODULE_7__["GameTabRoutingModule"]
        ],
        declarations: [
            _game_tab_page__WEBPACK_IMPORTED_MODULE_8__["GameTabPage"],
            _components_difficulty_difficulty_component__WEBPACK_IMPORTED_MODULE_3__["DifficultyComponent"],
            _components_person_person_component__WEBPACK_IMPORTED_MODULE_4__["PersonComponent"],
            _modals_modal_howto_modal_howto_component__WEBPACK_IMPORTED_MODULE_5__["ModalHowtoComponent"],
            _modals_modal_add_players_modal_add_players_component__WEBPACK_IMPORTED_MODULE_6__["ModalAddPlayersComponent"]
        ]
    })
], GameTabPageModule);



/***/ }),

/***/ "Ou0j":
/*!************************************************!*\
  !*** ./src/app/tabs/game-tab/game-tab.page.ts ***!
  \************************************************/
/*! exports provided: GameTabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GameTabPage", function() { return GameTabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_game_tab_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./game-tab.page.html */ "a6Mk");
/* harmony import */ var _game_tab_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./game-tab.page.scss */ "4n5D");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _difficulties__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./difficulties */ "FWgI");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modals_modal_howto_modal_howto_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modals/modal-howto/modal-howto.component */ "3zGi");
/* harmony import */ var _modals_modal_add_players_modal_add_players_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./modals/modal-add-players/modal-add-players.component */ "DVDl");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _pages_game_game_routes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../pages/game/game-routes */ "2DP2");










let GameTabPage = class GameTabPage {
    constructor(_modalController, _router) {
        this._modalController = _modalController;
        this._router = _router;
        this.difficulties = _difficulties__WEBPACK_IMPORTED_MODULE_4__["difficulties"];
        this.checkboxes = [
            {
                name: 'Straight, Spin, Shove Tricks',
                checked: true,
                value: 'Straight, Spin, Shove Tricks'
            },
            {
                name: 'Rail & Ledge Tricks',
                checked: true,
                value: 'Rail & Ledge Tricks'
            },
            {
                name: 'Ramp Tricks',
                value: 'Ramp Tricks',
                checked: true
            },
            {
                name: 'Flip Tricks',
                checked: true,
                value: 'Flip Tricks'
            },
        ];
        this.players = [1, 2, 3];
    }
    ngOnInit() {
    }
    openHowPlayModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modals_modal_howto_modal_howto_component__WEBPACK_IMPORTED_MODULE_6__["ModalHowtoComponent"],
                cssClass: 'modal-howto'
            });
            return yield modal.present();
        });
    }
    selectDifficulty(d) {
        this.difficulties.forEach(v => v.isSelected = false);
        d.isSelected = true;
    }
    addPlayer() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modals_modal_add_players_modal_add_players_component__WEBPACK_IMPORTED_MODULE_7__["ModalAddPlayersComponent"],
                cssClass: 'modal-add-players',
                componentProps: {
                    players: this.players
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data) {
                this.players = data.players;
            }
        });
    }
    startGame() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _pages_game_game_routes__WEBPACK_IMPORTED_MODULE_9__["GameRoutes"].ROOT, _pages_game_game_routes__WEBPACK_IMPORTED_MODULE_9__["GameRoutes"].TRICK]);
        });
    }
};
GameTabPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] }
];
GameTabPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-game',
        template: _raw_loader_game_tab_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_game_tab_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], GameTabPage);



/***/ }),

/***/ "Pu85":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/game-tab/modals/modal-add-players/modal-add-players.component.html ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion-margin-start title-20\">\n      Add players\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <ion-list class=\"ion-list-dark\">\n    <ion-list-header color=\"dark\" class=\"mb16\"><ion-text color=\"light\" class=\"text-16\">Player name</ion-text></ion-list-header>\n    <ion-item   color=\"dark\" lines=\"none\" class=\"mb12\">\n\n      <ion-input placeholder=\"Type here\"></ion-input>\n      <ion-button class=\"add-player\" slot=\"end\" color=\"secondary\" (click)=\"addPlayer()\">\n        <ion-icon slot=\"icon-only\" name=\"add-outline\"></ion-icon>\n      </ion-button>\n    </ion-item>\n\n    <ion-item   color=\"dark\" lines=\"none\" class=\"mb12\">\n      <ion-icon color=\"secondary\" slot=\"start\" name=\"link-outline\"></ion-icon>\n      <ion-label color=\"secondary\">Link profile</ion-label>\n      <ion-button fill=\"clear\" slot=\"end\" (click)=\"showProfile()\">\n        <ion-icon slot=\"icon-only\"  color=\"secondary\" name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-list>\n\n  <div class=\"divisor mt20 mb20\"></div>\n\n  <ion-list class=\"ion-list-dark\">\n    <ion-list-header color=\"dark\" class=\"mb16\"><ion-text color=\"light\" class=\"text-16\">Players</ion-text></ion-list-header>\n    <ion-item  *ngFor=\"let p of players\" color=\"dark\" lines=\"none\" class=\"mb12\">\n      <ion-avatar slot=\"start\">\n        <img src=\"https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y\">\n      </ion-avatar>\n        <ion-label>Matt Jones</ion-label>\n      <ion-button fill=\"clear\" slot=\"end\" (click)=\"removePlayer()\">\n        <ion-icon color=\"light\" slot=\"icon-only\" name=\"close-outline\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-list>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar color=\"dark\">\n    <ion-button (click)=\"savePlayers()\" class=\"ion-margin-start ion-margin-end mb12 apply-btn\" fill=\"solid\" color=\"success\" expand=\"block\">\n      Save\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>\n");

/***/ }),

/***/ "Tpvn":
/*!*********************************************************************!*\
  !*** ./src/app/tabs/game-tab/components/person/person.component.ts ***!
  \*********************************************************************/
/*! exports provided: PersonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonComponent", function() { return PersonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_person_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./person.component.html */ "4jh1");
/* harmony import */ var _person_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./person.component.scss */ "+R0m");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PersonComponent = class PersonComponent {
    constructor() { }
    ngOnInit() { }
};
PersonComponent.ctorParameters = () => [];
PersonComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-person',
        template: _raw_loader_person_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_person_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PersonComponent);



/***/ }),

/***/ "WTLA":
/*!*****************************************************************************!*\
  !*** ./src/app/tabs/game-tab/modals/modal-howto/modal-howto.component.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1ob3d0by5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "Y3qx":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/game-tab/modals/modal-howto/modal-howto.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion-margin-start title-20\">\n      How to play\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <div class=\"ion-margin-start ion-margin-end\">\n    <p  class=\"text-15\">\n      <ion-text color=\"tertiary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolorem doloribus est et nesciunt obcaecati\n        quasi repellat tenetur vitae? Animi at fugiat iusto praesentium quaerat, quisquam rerum sapiente similique ut!\n      </ion-text>\n    </p>\n\n    <p  class=\"text-15\">\n      <ion-text color=\"tertiary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolorem doloribus est et nesciunt obcaecati\n        quasi repellat tenetur vitae? Animi at fugiat iusto praesentium quaerat, quisquam rerum sapiente similique ut!\n      </ion-text>\n    </p>\n    <p  class=\"text-15\">\n      <ion-text color=\"tertiary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolorem doloribus est et nesciunt obcaecati\n        quasi repellat tenetur vitae? Animi at fugiat iusto praesentium quaerat, quisquam rerum sapiente similique ut!\n      </ion-text>\n    </p>\n\n    <p  class=\"text-15\">\n      <ion-text color=\"tertiary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolorem doloribus est et nesciunt obcaecati\n        quasi repellat tenetur vitae? Animi at fugiat iusto praesentium quaerat, quisquam rerum sapiente similique ut!\n      </ion-text>\n    </p>\n    <p  class=\"text-15\">\n      <ion-text color=\"tertiary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolorem doloribus est et nesciunt obcaecati\n        quasi repellat tenetur vitae? Animi at fugiat iusto praesentium quaerat, quisquam rerum sapiente similique ut!\n      </ion-text>\n    </p>\n    <p  class=\"text-15\">\n      <ion-text color=\"tertiary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt dolorem doloribus est et nesciunt obcaecati\n        quasi repellat tenetur vitae? Animi at fugiat iusto praesentium quaerat, quisquam rerum sapiente similique ut!\n      </ion-text>\n    </p>\n  </div>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar color=\"dark\">\n    <ion-button class=\"ion-margin-start ion-margin-end mb12 apply-btn\" fill=\"solid\" color=\"success\" expand=\"block\">\n     Go it\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>\n");

/***/ }),

/***/ "ZVPp":
/*!*******************************************************************************!*\
  !*** ./src/app/tabs/game-tab/components/difficulty/difficulty.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".difficulty {\n  box-sizing: border-box;\n  width: 96px;\n  height: 142px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  background: var(--ion-color-dark);\n  border-radius: var(--theme-base-border-radius);\n  transition: all 0.3s;\n}\n.difficulty ion-icon {\n  width: 66px;\n  height: 90px;\n}\n.difficulty--active {\n  border: 2px solid var(--ion-color-secondary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGRpZmZpY3VsdHkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUVBLGlDQUFBO0VBQ0EsOENBQUE7RUFFQSxvQkFBQTtBQURGO0FBR0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQURKO0FBSUU7RUFDRSw0Q0FBQTtBQUZKIiwiZmlsZSI6ImRpZmZpY3VsdHkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZGlmZmljdWx0eSB7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICB3aWR0aDogOTZweDtcclxuICBoZWlnaHQ6IDE0MnB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcclxuXHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3M7XHJcblxyXG4gIGlvbi1pY29uIHtcclxuICAgIHdpZHRoOiA2NnB4O1xyXG4gICAgaGVpZ2h0OiA5MHB4O1xyXG4gIH1cclxuXHJcbiAgJi0tYWN0aXZlIHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ "a6Mk":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/game-tab/game-tab.page.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout\n        [isNeedLeftPadding]=\"false\"\n        [isNeedRightPadding]=\"false\"\n>\n  <div class=\"ion-margin-start ion-margin-end d-flex flex-column ion-justify-content-center ion-align-items-center\">\n    <ion-text color=\"light\" class=\"title-34\">Play S.K.A.T.E</ion-text>\n    <ion-button fill=\"clear\" (click)=\"openHowPlayModal()\">\n      <ion-icon color=\"secondary\" name=\"information-circle-outline\" slot=\"start\"></ion-icon>\n      <ion-text color=\"secondary\">How do I play?</ion-text>\n    </ion-button>\n  </div>\n  <div class=\"divisor mt12 mb20\"></div>\n  <div class=\"ion-margin-start ion-margin-end d-flex flex-column\">\n    <ion-label slot=\"stacked\">\n      <ion-text color=\"light\" class=\"text-16\">Choose difficulty</ion-text>\n      <div class=\"d-flex ion-justify-content-between mt12\">\n        <app-difficulty *ngFor=\"let d of difficulties\" [difficulty]=\"d\" (click)=\"selectDifficulty(d)\"></app-difficulty>\n      </div>\n    </ion-label>\n  </div>\n\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top d-flex flex-column\">\n    <ion-label slot=\"stacked\">\n      <ion-text color=\"light\" class=\"text-16\">Add players</ion-text>\n      <div class=\"d-flex mt12\">\n        <div class=\"person\" *ngFor=\"let p of players\">\n          <app-person></app-person>\n        </div>\n        <div class=\"person person--add text-hover\" (click)=\"addPlayer()\">\n          <ion-icon name=\"add-outline\" color=\"light\"></ion-icon>\n        </div>\n      </div>\n    </ion-label>\n  </div>\n\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top d-flex flex-column\">\n    <ion-label slot=\"stacked\">\n      <ion-text color=\"light\" class=\"text-16\">Type of tricks</ion-text>\n      <div class=\"d-flex mt12\">\n        <app-checkbox-list\n                [checkboxes]=\"checkboxes\"\n                [defaultCheckedColor]=\"'darktwo'\"\n                [defaultUncheckedColor]=\"'primary'\"\n        ></app-checkbox-list>\n      </div>\n    </ion-label>\n  </div>\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top ion-margin-bottom\">\n    <ion-button class=\" w100percent\" fill=\"solid\" color=\"success\" expand=\"block\" (click)=\"startGame()\">\n      Start game\n    </ion-button>\n  </div>\n</app-mail-layout>\n");

/***/ }),

/***/ "if0f":
/*!*****************************************************************************************!*\
  !*** ./src/app/tabs/game-tab/modals/modal-add-players/modal-add-players.component.scss ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-avatar, .add-player {\n  width: 44px;\n  height: 44px;\n}\n\nion-input {\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 6px !important;\n  --padding-botton: 6px !important;\n  border-radius: var(--theme-base-border-radius);\n  border: 1px solid var(--ion-color-secondary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLWFkZC1wbGF5ZXJzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFDRjs7QUFFQTtFQUNFLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwwQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsOEJBQUE7RUFDQSw2QkFBQTtFQUNBLGdDQUFBO0VBQ0EsOENBQUE7RUFDQSw0Q0FBQTtBQUNGIiwiZmlsZSI6Im1vZGFsLWFkZC1wbGF5ZXJzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWF2YXRhciwgLmFkZC1wbGF5ZXIge1xyXG4gIHdpZHRoOiA0NHB4O1xyXG4gIGhlaWdodDogNDRweDtcclxufVxyXG5cclxuaW9uLWlucHV0IHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1ib3R0b246IDZweCAhaW1wb3J0YW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IHZhcigtLXRoZW1lLWJhc2UtYm9yZGVyLXJhZGl1cyk7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "lyuE":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/game-tab/components/difficulty/difficulty.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"difficulty\" [ngClass]=\"{'difficulty--active': difficulty.isSelected}\">\n  <ion-icon [src]=\"difficulty.isSelected ?  difficulty.iconSelected : difficulty.icon\"></ion-icon>\n  <ion-text [color]=\"difficulty.isSelected ? 'secondary' : 'light'\">{{difficulty.name}}</ion-text>\n</div>\n");

/***/ }),

/***/ "uLVO":
/*!*****************************************************************************!*\
  !*** ./src/app/tabs/game-tab/components/difficulty/difficulty.component.ts ***!
  \*****************************************************************************/
/*! exports provided: DifficultyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DifficultyComponent", function() { return DifficultyComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_difficulty_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./difficulty.component.html */ "lyuE");
/* harmony import */ var _difficulty_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./difficulty.component.scss */ "ZVPp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let DifficultyComponent = class DifficultyComponent {
    constructor() { }
    ngOnInit() { }
};
DifficultyComponent.ctorParameters = () => [];
DifficultyComponent.propDecorators = {
    difficulty: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
DifficultyComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-difficulty',
        template: _raw_loader_difficulty_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_difficulty_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], DifficultyComponent);



/***/ }),

/***/ "v7W0":
/*!**********************************************************!*\
  !*** ./src/app/tabs/game-tab/game-tab-routing.module.ts ***!
  \**********************************************************/
/*! exports provided: GameTabRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GameTabRoutingModule", function() { return GameTabRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _game_tab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./game-tab.page */ "Ou0j");




const routes = [
    {
        path: '',
        component: _game_tab_page__WEBPACK_IMPORTED_MODULE_3__["GameTabPage"]
    }
];
let GameTabRoutingModule = class GameTabRoutingModule {
};
GameTabRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], GameTabRoutingModule);



/***/ })

}]);
//# sourceMappingURL=game-tab-game-tab-module-es2015.js.map