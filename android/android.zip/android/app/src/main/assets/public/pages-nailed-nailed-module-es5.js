(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-nailed-nailed-module"], {
    /***/
    "BmTL":
    /*!************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/pages/nailed/nailed.page.html ***!
      \************************************************************************************************/

    /*! exports provided: default */

    /***/
    function BmTL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content color=\"primary\">\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"stopGame()\">\n      <ion-icon name=\"power-outline\" color=\"danger\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <div class=\"d-flex flex-column ion-align-items-center nailed\">\n    <ion-text class=\"nailed__text title-34\" color=\"secondary\">Nailed it!</ion-text>\n    <ion-text class=\"nailed__text title-34\" color=\"secondary\">Nailed it!</ion-text>\n    <ion-text class=\"nailed__text title-34\" color=\"secondary\">Nailed it!</ion-text>\n    <ion-text class=\"nailed__text title-34\" color=\"secondary\">Nailed it!</ion-text>\n\n    <div class=\"d-flex flex-column ion-align-self-center ion-align-items-center ion-padding-start ion-padding-end nailed__wrapper\">\n      <ion-avatar>\n        <img src=\"../../../../../assets/images/person.png\">\n      </ion-avatar>\n\n      <ion-text color=\"tertiary\" class=\"mt12 text-16\">Bobby Mount</ion-text>\n      <ion-text class=\" skate title-34\">\n        <ion-text>S.</ion-text>\n        <ion-text>K.</ion-text>\n        <ion-text>A.</ion-text>\n        <ion-text>T.</ion-text>\n        <ion-text>E</ion-text>\n      </ion-text>\n      <ion-button class=\"w100percent next-btn\" fill=\"solid\" color=\"success\" expand=\"block\" (click)=\"nextPlayer()\">\n        Next Player\n      </ion-button>\n    </div>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "DIJX":
    /*!**********************************************************!*\
      !*** ./src/app/pages/game/pages/nailed/nailed.module.ts ***!
      \**********************************************************/

    /*! exports provided: NailedPageModule */

    /***/
    function DIJX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NailedPageModule", function () {
        return NailedPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _nailed_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./nailed-routing.module */
      "Srx9");
      /* harmony import */


      var _nailed_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./nailed.page */
      "XY5a");

      var NailedPageModule = function NailedPageModule() {
        _classCallCheck(this, NailedPageModule);
      };

      NailedPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _nailed_routing_module__WEBPACK_IMPORTED_MODULE_5__["NailedPageRoutingModule"]],
        declarations: [_nailed_page__WEBPACK_IMPORTED_MODULE_6__["NailedPage"]]
      })], NailedPageModule);
      /***/
    },

    /***/
    "Srx9":
    /*!******************************************************************!*\
      !*** ./src/app/pages/game/pages/nailed/nailed-routing.module.ts ***!
      \******************************************************************/

    /*! exports provided: NailedPageRoutingModule */

    /***/
    function Srx9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NailedPageRoutingModule", function () {
        return NailedPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _nailed_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./nailed.page */
      "XY5a");

      var routes = [{
        path: '',
        component: _nailed_page__WEBPACK_IMPORTED_MODULE_3__["NailedPage"]
      }];

      var NailedPageRoutingModule = function NailedPageRoutingModule() {
        _classCallCheck(this, NailedPageRoutingModule);
      };

      NailedPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], NailedPageRoutingModule);
      /***/
    },

    /***/
    "XY5a":
    /*!********************************************************!*\
      !*** ./src/app/pages/game/pages/nailed/nailed.page.ts ***!
      \********************************************************/

    /*! exports provided: NailedPage */

    /***/
    function XY5a(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NailedPage", function () {
        return NailedPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_nailed_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./nailed.page.html */
      "BmTL");
      /* harmony import */


      var _nailed_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./nailed.page.scss */
      "aKjl");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../../tabs/tabs.enum */
      "162u");
      /* harmony import */


      var _game_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../game-routes */
      "2DP2");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var NailedPage = /*#__PURE__*/function () {
        function NailedPage(_router) {
          _classCallCheck(this, NailedPage);

          this._router = _router;
        }

        _createClass(NailedPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "stopGame",
          value: function stopGame() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_4__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_4__["tabsEnum2RouteMapping"].GAME]);

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "nextPlayer",
          value: function nextPlayer() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._router.navigate(['/', _game_routes__WEBPACK_IMPORTED_MODULE_5__["GameRoutes"].ROOT, _game_routes__WEBPACK_IMPORTED_MODULE_5__["GameRoutes"].FAILED]);

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return NailedPage;
      }();

      NailedPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
        }];
      };

      NailedPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-nailed',
        template: _raw_loader_nailed_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_nailed_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], NailedPage);
      /***/
    },

    /***/
    "aKjl":
    /*!**********************************************************!*\
      !*** ./src/app/pages/game/pages/nailed/nailed.page.scss ***!
      \**********************************************************/

    /*! exports provided: default */

    /***/
    function aKjl(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".nailed {\n  height: 100%;\n  background-image: url(\"/assets/images/nailed.png\");\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n}\n.nailed__text {\n  position: absolute;\n  top: 130px;\n  transform: rotate(-45deg);\n}\n.nailed__wrapper {\n  margin-top: 300px;\n  width: 100%;\n  height: 100%;\n}\n.next-btn {\n  margin-top: auto;\n  margin-bottom: 40px;\n}\n.skate {\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG5haWxlZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0Esa0RBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7QUFDRjtBQUNFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EseUJBQUE7QUFDSjtBQUVFO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUFKO0FBS0E7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBRkY7QUFJQTtFQUNFLFlBQUE7QUFERiIsImZpbGUiOiJuYWlsZWQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5haWxlZCB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWFnZXMvbmFpbGVkLnBuZycpO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcblxyXG4gICZfX3RleHQge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMzBweDtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKC00NWRlZyk7XHJcbiAgfVxyXG5cclxuICAmX193cmFwcGVyIHtcclxuICAgIG1hcmdpbi10b3A6IDMwMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcblxyXG4gIH1cclxufVxyXG5cclxuLm5leHQtYnRuIHtcclxuICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbn1cclxuLnNrYXRlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbn1cclxuIl19 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-nailed-nailed-module-es5.js.map