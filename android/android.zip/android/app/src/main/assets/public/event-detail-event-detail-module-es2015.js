(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["event-detail-event-detail-module"],{

/***/ "1zcI":
/*!*************************************************************************************!*\
  !*** ./src/app/tabs/events/event-detail/modal-ratings/modal-ratings.component.scss ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-item {\n  --padding-start: 5px;\n  --inner-padding-end: 0px;\n  display: flex;\n  align-items: flex-start;\n}\n\nion-input, ion-textarea {\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n}\n\nion-label.mb12 {\n  margin-bottom: 12px !important;\n}\n\nion-list {\n  background: var(--ion-color-dark);\n}\n\nion-avatar {\n  width: 40px;\n  height: 40px;\n}\n\n.comment-rating {\n  height: 36px;\n}\n\n.your-rating {\n  padding-top: 12px;\n  background: var(--ion-color-primary);\n}\n\n.your-rating ion-list {\n  background: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLXJhdGluZ3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBQTtFQUNBLHdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5REFBQTtFQUNBLHVEQUFBO0VBQ0EsMENBQUE7RUFDQSxnQ0FBQTtFQUNBLDhCQUFBO0VBQ0EsOEJBQUE7RUFDQSxpQ0FBQTtFQUNBLGdEQUFBO0FBQ0Y7O0FBR0E7RUFDRSw4QkFBQTtBQUFGOztBQUdBO0VBQ0UsaUNBQUE7QUFBRjs7QUFHQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBQUY7O0FBR0E7RUFDRSxZQUFBO0FBQUY7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLG9DQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxvQ0FBQTtBQUNKIiwiZmlsZSI6Im1vZGFsLXJhdGluZ3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiA1cHg7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCwgaW9uLXRleHRhcmVhIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9uOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxufVxyXG5cclxuaW9uLWxhYmVsLm1iMTIge1xyXG4gIG1hcmdpbi1ib3R0b206IDEycHghaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG59XHJcblxyXG5pb24tYXZhdGFyIHtcclxuICB3aWR0aDogNDBweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbn1cclxuXHJcbi5jb21tZW50LXJhdGluZyB7XHJcbiAgaGVpZ2h0OiAzNnB4O1xyXG59XHJcbi55b3VyLXJhdGluZyB7XHJcbiAgcGFkZGluZy10b3A6IDEycHg7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cclxuICBpb24tbGlzdCB7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "5/O0":
/*!*****************************************************************!*\
  !*** ./src/app/tabs/events/event-detail/event-detail.module.ts ***!
  \*****************************************************************/
/*! exports provided: EventDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventDetailPageModule", function() { return EventDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _event_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./event-detail-routing.module */ "lfB0");
/* harmony import */ var _event_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./event-detail.page */ "itb7");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/shared.module */ "PCNd");
/* harmony import */ var _modal_ratings_modal_ratings_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modal-ratings/modal-ratings.component */ "diV+");






let EventDetailPageModule = class EventDetailPageModule {
};
EventDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _event_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__["EventDetailPageRoutingModule"]
        ],
        declarations: [_event_detail_page__WEBPACK_IMPORTED_MODULE_3__["EventDetailPage"], _modal_ratings_modal_ratings_component__WEBPACK_IMPORTED_MODULE_5__["ModalRatingsComponent"]]
    })
], EventDetailPageModule);



/***/ }),

/***/ "80EH":
/*!*****************************************************************!*\
  !*** ./src/app/tabs/events/event-detail/event-detail.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-img {\n  height: 180px;\n}\n\nion-list {\n  background: var(--ion-color-primary);\n}\n\n.icon-slot {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 40px;\n  height: 40px;\n  background: rgba(var(--ion-color-secondary-rgb), 0.1);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.icon-slot ion-icon {\n  font-size: 24px;\n}\n\na {\n  color: var(--ion-color-light);\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcZXZlbnQtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7QUFDRjs7QUFFQTtFQUNFLG9DQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBRUEscURBQUE7RUFDQSw4Q0FBQTtBQUFGOztBQUVFO0VBQ0UsZUFBQTtBQUFKOztBQUdBO0VBQ0UsNkJBQUE7RUFDQSxxQkFBQTtBQUFGIiwiZmlsZSI6ImV2ZW50LWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW1nIHtcclxuICBoZWlnaHQ6IDE4MHB4O1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG4uaWNvbi1zbG90IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG5cclxuICBiYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktcmdiKSwgMC4xKTtcclxuICBib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG5cclxuICBpb24taWNvbiB7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgfVxyXG59XHJcbmEge1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "8Ipm":
/*!******************************************************!*\
  !*** ./src/app/shared/interfaces/team.interfaces.ts ***!
  \******************************************************/
/*! exports provided: EventImpl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventImpl", function() { return EventImpl; });
class EventImpl {
    constructor() {
        this.address_line_1 = '';
        this.address_line_2 = '';
        this.city = '';
        this.date = '';
        this.date_formatted = '';
        this.date_timestamp = '';
        this.description = '';
        this.id = '';
        this.image = '';
        this.name = '';
        this.postcode = '';
        this.time = '';
        this.website = '';
    }
}


/***/ }),

/***/ "cpFq":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/events/event-detail/modal-ratings/modal-ratings.component.html ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion-margin-start title-20\">\n      Ratings\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top\">\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\">\n        <ion-text color=\"light\" class=\"text-16\">Your rating</ion-text>\n      </ion-label>\n      <ionic-rating-component\n              #rating\n              activeIcon = \"star\"\n              defaultIcon = \"star-outline\"\n              [activeColor] = activeRatingColor\n              [defaultColor] = defaultRatingColor\n              readonly=\"false\"\n              rating=\"3\"\n              fontSize = \"16px\">\n      </ionic-rating-component>\n    </ion-item>\n\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\" class=\"mb12\">\n        <ion-text color=\"light\" class=\"text-16\">Add a comment</ion-text>\n        <ion-text color=\"tertiary\" class=\"text-16\">(optional)</ion-text>\n      </ion-label>\n      <ion-textarea rows=\"4\" placeholder=\"Type here\" ></ion-textarea>\n    </ion-item>\n    <ion-button\n            color=\"success\"\n            expand=\"block\"\n            class=\"ion-margin-top\"\n    >\n      <ion-text class=\"text-15-500\">Add Rating</ion-text>\n    </ion-button>\n  </div>\n  <div class=\"divisor mt20 mb20\"></div>\n  <div class=\"ion-margin-start ion-margin-end d-flex ion-justify-content-between ion-align-items-center\">\n    <ion-text color=\"secondary\" class=\"text-16\">Overall rating</ion-text>\n    <ion-text color=\"secondary\" class=\"title-28\">5.0</ion-text>\n  </div>\n\n  <div class=\"ion-margin-top your-rating\">\n    <div class=\"ion-margin-start ion-margin-end d-flex ion-justify-content-between ion-align-items-center\">\n      <ion-text color=\"light\" class=\"text-16\">Your Ratings</ion-text>\n    </div>\n\n    <ion-list class=\"ion-margin-top\" lines=\"none\">\n      <ion-item color=\"primary\" class=\"ion-margin-start ion-margin-end ion-margin-bottom\" lines=\"none\">\n        <ion-avatar slot=\"start\">\n          <img src=\"https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y\">\n        </ion-avatar>\n        <div class=\"rating\">\n          <div class=\"rating__row d-flex ion-justify-content-between ion-align-items-center\">\n            <div class=\"rating__author\">Mike Welthman</div>\n            <ionic-rating-component\n                    class=\"comment-rating\"\n                    #rating\n                    activeIcon = \"star\"\n                    defaultIcon = \"star-outline\"\n                    [activeColor] = activeRatingColor\n                    [defaultColor] = defaultRatingColor\n                    readonly=\"true\"\n                    rating=\"3\"\n                    fontSize = \"16px\">\n            </ionic-rating-component>\n          </div>\n          <div class=\"rating__row\">\n            <ion-text color=\"tertiary\" class=\"text-15\">\n              I liked it very much! Did a triple back side ollie kickflip 360 over a huge set of stairs (at least 60 of them) and landed perfectly… All thanks to this awesome park!\n            </ion-text>\n          </div>\n          <div class=\"rating__row\">\n            <ion-text color=\"medium\" class=\"text-13-300\">June 6, 2020</ion-text>\n          </div>\n\n        </div>\n      </ion-item>\n    </ion-list>\n\n  </div>\n\n\n  <div class=\"ion-margin-start ion-margin-end ion-margin-top d-flex ion-justify-content-between ion-align-items-center\">\n    <ion-text color=\"light\" class=\"text-16\">User Ratings</ion-text>\n    <ion-text color=\"tertiary\" class=\"text-15\">37 ratings</ion-text>\n  </div>\n\n  <ion-list class=\"ion-margin-top\" lines=\"none\">\n    <ion-item color=\"dark\" class=\"ion-margin-start ion-margin-end ion-margin-bottom\" *ngFor=\"let r of [1,2,3,4]\" lines=\"none\">\n      <ion-avatar slot=\"start\">\n        <img src=\"https://gravatar.com/avatar/dba6bae8c566f9d4041fb9cd9ada7741?d=identicon&f=y\">\n      </ion-avatar>\n      <div class=\"rating\">\n        <div class=\"rating__row d-flex ion-justify-content-between ion-align-items-center\">\n          <div class=\"rating__author\">Mike Welthman</div>\n          <ionic-rating-component\n                  class=\"comment-rating\"\n                  #rating\n                  activeIcon = \"star\"\n                  defaultIcon = \"star-outline\"\n                  [activeColor] = activeRatingColor\n                  [defaultColor] = defaultRatingColor\n                  readonly=\"true\"\n                  rating=\"3\"\n                  fontSize = \"16px\">\n          </ionic-rating-component>\n        </div>\n        <div class=\"rating__row\">\n          <ion-text color=\"tertiary\" class=\"text-15\">\n            I liked it very much! Did a triple back side ollie kickflip 360 over a huge set of stairs (at least 60 of them) and landed perfectly… All thanks to this awesome park!\n          </ion-text>\n        </div>\n        <div class=\"rating__row\">\n          <ion-text color=\"medium\" class=\"text-13-300\">June 6, 2020</ion-text>\n        </div>\n\n      </div>\n    </ion-item>\n  </ion-list>\n</ion-content>\n");

/***/ }),

/***/ "dLCB":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/events/event-detail/event-detail.page.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout\n        [isNeedRightPadding]=\"false\"\n        [isNeedLeftPadding]=\"false\"\n        [isNotNeedPaddingTopHeader]=\"true\"\n>\n  <ion-grid class=\"ion-padding-start ion-padding-end\">\n    <ion-row>\n      <ion-col class=\"p0\">\n        <ion-icon\n                class=\"icon-as-btn\"\n                color=\"secondary\"\n                name=\"arrow-back-outline\"\n                size=\"large\"\n                (click)=\"back()\"\n        ></ion-icon>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"mt12\">\n      <ion-col class=\"p0\">\n        <ion-img [src]=\"event.image\"></ion-img>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"mt12\">\n      <ion-col class=\"p0\">\n        <ion-text color=\"light\" class=\"title-20\">{{event.name}}</ion-text>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-list>\n\n    <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end mb16\">\n      <div class=\"icon-slot\" slot=\"start\">\n        <ion-icon src=\"assets/images/svg-icons/explore-24px.svg\"></ion-icon>\n      </div>\n      <div class=\"d-flex flex-column\">\n        <ion-label >\n          <ion-text class=\"text-16\" color=\"light\">{{event.date_formatted}}</ion-text>\n        </ion-label>\n        <ion-text class=\"text-12\" color=\"tertiary\">{{event.time}} </ion-text>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end mb16\">\n      <div class=\"icon-slot\" slot=\"start\">\n        <ion-icon src=\"assets/images/svg-icons/explore-24px.svg\"></ion-icon>\n      </div>\n      <div class=\"d-flex flex-column\">\n        <ion-label >\n          <ion-text class=\"text-16\" color=\"light\">Locak Skatepark</ion-text>\n        </ion-label>\n        <ion-text class=\"text-12\" color=\"tertiary\">{{event.address_line_1}}</ion-text>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\" class=\"ion-margin-end mb16\">\n      <div class=\"icon-slot\" slot=\"start\">\n        <ion-icon src=\"assets/images/svg-icons/confirmation_number-24px.svg\"></ion-icon>\n      </div>\n      <ion-label >\n        <ion-text class=\"text-16\" color=\"light\">Free entrance</ion-text>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n\n  <div class=\"divisor mt20 mb20\"></div>\n  <div class=\"d-flex flex-column ion-margin-start ion-margin-end\">\n    <ion-label position=\"stacked\"><ion-text color=\"light\" class=\"text-16\">About the Event</ion-text></ion-label>\n    <ion-text color=\"tertiary\" class=\"mt8 text-15\">\n      {{event.description}}\n    </ion-text>\n  </div>\n  <!--@todo ask-->\n  <ion-button\n          color=\"success\"\n          expand=\"block\"\n          class=\"ion-margin-top ion-padding-start ion-padding-end\"\n  >\n    <ion-text class=\"text-15-500\" (click)=\"openModalRatings()\">Open Modal Ratings</ion-text>\n  </ion-button>\n\n  <ion-button\n          (click)=\"openBrowser()\"\n          color=\"success\"\n          expand=\"block\"\n          class=\"ion-margin-top ion-padding-start ion-padding-end\"\n  >\n    <ion-text class=\"text-15-500\">Visit Website</ion-text>\n  </ion-button>\n\n</app-mail-layout>\n");

/***/ }),

/***/ "diV+":
/*!***********************************************************************************!*\
  !*** ./src/app/tabs/events/event-detail/modal-ratings/modal-ratings.component.ts ***!
  \***********************************************************************************/
/*! exports provided: ModalRatingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalRatingsComponent", function() { return ModalRatingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_ratings_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-ratings.component.html */ "cpFq");
/* harmony import */ var _modal_ratings_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-ratings.component.scss */ "1zcI");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let ModalRatingsComponent = class ModalRatingsComponent {
    constructor(_modalController) {
        this._modalController = _modalController;
        this.defaultRatingColor = getComputedStyle(document.documentElement).getPropertyValue('--ion-color-light');
        this.activeRatingColor = getComputedStyle(document.documentElement).getPropertyValue('--ion-color-secondary');
    }
    ngOnInit() { }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
};
ModalRatingsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ModalRatingsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-ratings',
        template: _raw_loader_modal_ratings_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_ratings_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalRatingsComponent);



/***/ }),

/***/ "itb7":
/*!***************************************************************!*\
  !*** ./src/app/tabs/events/event-detail/event-detail.page.ts ***!
  \***************************************************************/
/*! exports provided: EventDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventDetailPage", function() { return EventDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_event_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./event-detail.page.html */ "dLCB");
/* harmony import */ var _event_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./event-detail.page.scss */ "80EH");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_ratings_modal_ratings_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modal-ratings/modal-ratings.component */ "diV+");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_interfaces_team_interfaces__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../shared/interfaces/team.interfaces */ "8Ipm");
/* harmony import */ var _shared_store_selectors__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/store/selectors */ "OSWL");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../shared/enums/Storage.enum */ "03gG");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "m/P+");














let EventDetailPage = class EventDetailPage {
    constructor(_location, _modalController, _coreStore, _iab) {
        this._location = _location;
        this._modalController = _modalController;
        this._coreStore = _coreStore;
        this._iab = _iab;
        this.event = new _shared_interfaces_team_interfaces__WEBPACK_IMPORTED_MODULE_8__["EventImpl"]();
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_11__["Subject"]();
    }
    ngOnInit() {
        this._coreStore.getValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_12__["StorageEnum"].SELECTED_EVENT).then(event => this.setEvent(event));
        this._coreStore.select(_shared_store_selectors__WEBPACK_IMPORTED_MODULE_9__["selectEvent"])
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["takeUntil"])(this.componentDestroyed))
            .subscribe(event => this.setEvent(event));
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    back() {
        this._location.back();
    }
    setEvent(event) {
        if (event) {
            this.event = event;
        }
    }
    openModalRatings() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modal_ratings_modal_ratings_component__WEBPACK_IMPORTED_MODULE_6__["ModalRatingsComponent"],
                cssClass: 'modal-rating'
            });
            return yield modal.present();
        });
    }
    openBrowser() {
        this._iab.create(this.event.website);
    }
};
EventDetailPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__["CoreStore"] },
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_13__["InAppBrowser"] }
];
EventDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-event-detail',
        template: _raw_loader_event_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_event_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EventDetailPage);



/***/ }),

/***/ "lfB0":
/*!*************************************************************************!*\
  !*** ./src/app/tabs/events/event-detail/event-detail-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: EventDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventDetailPageRoutingModule", function() { return EventDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _event_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./event-detail.page */ "itb7");




const routes = [
    {
        path: '',
        component: _event_detail_page__WEBPACK_IMPORTED_MODULE_3__["EventDetailPage"]
    }
];
let EventDetailPageRoutingModule = class EventDetailPageRoutingModule {
};
EventDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EventDetailPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=event-detail-event-detail-module-es2015.js.map