(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["news-news-module"],{

/***/ "1Ikv":
/*!******************************************!*\
  !*** ./src/app/tabs/news/news.page.scss ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card {\n  box-shadow: none;\n  margin-inline: 0;\n}\n\nion-card-header {\n  padding-top: 8px;\n  padding-bottom: 0;\n  padding-inline: 0;\n}\n\nion-thumbnail {\n  width: 100%;\n  height: 160px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxuZXdzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUVGOztBQUNBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7QUFFRiIsImZpbGUiOiJuZXdzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkIHtcclxuICBib3gtc2hhZG93OiBub25lO1xyXG4gIG1hcmdpbi1pbmxpbmU6IDA7XHJcbn1cclxuaW9uLWNhcmQtaGVhZGVyIHtcclxuICBwYWRkaW5nLXRvcDogOHB4O1xyXG4gIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gIHBhZGRpbmctaW5saW5lOiAwXHJcbn1cclxuXHJcbmlvbi10aHVtYm5haWwge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTYwcHg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "F5LI":
/*!****************************************!*\
  !*** ./src/app/tabs/news/news.page.ts ***!
  \****************************************/
/*! exports provided: NewsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsPage", function() { return NewsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_news_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./news.page.html */ "l6rM");
/* harmony import */ var _news_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./news.page.scss */ "1Ikv");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../tabs.enum */ "162u");






let NewsPage = class NewsPage {
    constructor(_router) {
        this._router = _router;
        this.items = [
            {
                imgSrc: 'assets/images/teams/news.png',
                name: 'Check out this insane trick!',
                text: 'We just need your registered email address to send you password reset instructions',
            },
            {
                imgSrc: 'assets/images/teams/news.png',
                name: 'Ten tips to become a better skater',
                text: 'We just need your registered email address to send you…',
            },
        ];
    }
    ngOnInit() {
    }
    openNews(newsId) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _tabs_enum__WEBPACK_IMPORTED_MODULE_5__["TABS_MAIN_ROUTE"], _tabs_enum__WEBPACK_IMPORTED_MODULE_5__["tabsEnum2RouteMapping"].NEWS, newsId]);
        });
    }
};
NewsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
NewsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-news',
        template: _raw_loader_news_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_news_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], NewsPage);



/***/ }),

/***/ "GE7y":
/*!**************************************************!*\
  !*** ./src/app/tabs/news/news-routing.module.ts ***!
  \**************************************************/
/*! exports provided: NewsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsPageRoutingModule", function() { return NewsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _news_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./news.page */ "F5LI");




const routes = [
    {
        path: '',
        component: _news_page__WEBPACK_IMPORTED_MODULE_3__["NewsPage"]
    },
    {
        path: ':id',
        loadChildren: () => __webpack_require__.e(/*! import() | news-item-news-item-module */ "news-item-news-item-module").then(__webpack_require__.bind(null, /*! ./news-item/news-item.module */ "H91t")).then(m => m.NewsItemPageModule)
    }
];
let NewsPageRoutingModule = class NewsPageRoutingModule {
};
NewsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NewsPageRoutingModule);



/***/ }),

/***/ "NMs2":
/*!******************************************!*\
  !*** ./src/app/tabs/news/news.module.ts ***!
  \******************************************/
/*! exports provided: NewsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsPageModule", function() { return NewsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _news_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./news-routing.module */ "GE7y");
/* harmony import */ var _news_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./news.page */ "F5LI");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/shared.module */ "PCNd");





let NewsPageModule = class NewsPageModule {
};
NewsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _news_routing_module__WEBPACK_IMPORTED_MODULE_2__["NewsPageRoutingModule"]
        ],
        declarations: [_news_page__WEBPACK_IMPORTED_MODULE_3__["NewsPage"]]
    })
], NewsPageModule);



/***/ }),

/***/ "l6rM":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/news/news.page.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout class=\"mainLayoutHeight124\">\n\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center ion-margin-bottom\">\n    <ion-text color=\"light\" class=\"title-20\">News</ion-text>\n  </header>\n\n  <ion-virtual-scroll [items]=\"items\" approxItemHeight=\"320px\">\n    <ion-card *virtualItem=\"let item; let itemBounds = bounds;\" color=\"primaty\" (click)=\"openNews(1)\">\n      <div>\n        <ion-thumbnail>\n          <ion-img [src]=\"item.imgSrc\" [alt]=\"item.name\">\n          </ion-img>\n        </ion-thumbnail>\n      </div>\n      <ion-card-header>\n        <ion-card-subtitle><ion-text color=\"light\" class=\"text-16-500 text-no-transform\">{{ item.name }}</ion-text></ion-card-subtitle>\n        <ion-card-title class=\"text-16-500\"><ion-text color=\"tertiary\" class=\"text-15\">{{ item.text }}</ion-text></ion-card-title>\n      </ion-card-header>\n    </ion-card>\n  </ion-virtual-scroll>\n\n</app-mail-layout>\n");

/***/ })

}]);
//# sourceMappingURL=news-news-module-es2015.js.map