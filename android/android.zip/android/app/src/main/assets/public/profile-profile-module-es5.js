(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"], {
    /***/
    "+04C":
    /*!************************************************!*\
      !*** ./src/app/tabs/profile/profile.page.scss ***!
      \************************************************/

    /*! exports provided: default */

    /***/
    function C(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar.layout-toolbar {\n  position: relative;\n  padding-top: 18px;\n  padding-bottom: 18px;\n  --border-width: 0!important;\n  --ion-color-base: transparent!important;\n}\nion-toolbar.layout-toolbar--pb0 {\n  padding-bottom: 0;\n}\n.menu-icon {\n  width: 36px;\n  height: 36px;\n}\n.header-menu-button {\n  -webkit-margin-end: 12px;\n          margin-inline-end: 12px;\n}\n.profile-header__wrap {\n  margin-top: -80px;\n  display: flex;\n  align-items: flex-end;\n  height: 372px;\n  padding: var(--ion-padding);\n  background: url(\"/assets/images/profile.png\") center no-repeat;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFRTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLDJCQUFBO0VBQ0EsdUNBQUE7QUFESjtBQUdJO0VBQ0UsaUJBQUE7QUFETjtBQU1BO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFIRjtBQU1BO0VBQ0Usd0JBQUE7VUFBQSx1QkFBQTtBQUhGO0FBS0E7RUFDRSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7RUFDQSwyQkFBQTtFQUVBLDhEQUFBO0FBSEYiLCJmaWxlIjoicHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW9uLXRvb2xiYXIge1xyXG4gICYubGF5b3V0LXRvb2xiYXIge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgcGFkZGluZy10b3A6IDE4cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMThweDtcclxuICAgIC0tYm9yZGVyLXdpZHRoOiAwIWltcG9ydGFudDtcclxuICAgIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50IWltcG9ydGFudDtcclxuXHJcbiAgICAmLS1wYjAge1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogMDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi5tZW51LWljb24ge1xyXG4gIHdpZHRoOiAzNnB4O1xyXG4gIGhlaWdodDogMzZweDtcclxufVxyXG5cclxuLmhlYWRlci1tZW51LWJ1dHRvbiB7XHJcbiAgbWFyZ2luLWlubGluZS1lbmQ6IDEycHg7XHJcbn1cclxuLnByb2ZpbGUtaGVhZGVyX193cmFwIHtcclxuICBtYXJnaW4tdG9wOiAtODBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcclxuICBoZWlnaHQ6IDM3MnB4O1xyXG4gIHBhZGRpbmc6IHZhcigtLWlvbi1wYWRkaW5nKTtcclxuXHJcbiAgYmFja2dyb3VuZDogdXJsKFwiL2Fzc2V0cy9pbWFnZXMvcHJvZmlsZS5wbmdcIikgY2VudGVyIG5vLXJlcGVhdDtcclxuXHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "CwGv":
    /*!****************************************************************************************!*\
      !*** ./src/app/tabs/profile/modals/modal-edit-profile/modal-edit-profile.component.ts ***!
      \****************************************************************************************/

    /*! exports provided: ModalEditProfileComponent */

    /***/
    function CwGv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ModalEditProfileComponent", function () {
        return ModalEditProfileComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_modal_edit_profile_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./modal-edit-profile.component.html */
      "sF51");
      /* harmony import */


      var _modal_edit_profile_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./modal-edit-profile.component.scss */
      "lSv9");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var ModalEditProfileComponent = /*#__PURE__*/function () {
        function ModalEditProfileComponent(_modalController) {
          _classCallCheck(this, ModalEditProfileComponent);

          this._modalController = _modalController;
          this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            firstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('Mike', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]),
            lastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('Johanssen', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]),
            date: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('June 28, 1989', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]),
            location: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])
          });
        }

        _createClass(ModalEditProfileComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "closeModal",
          value: function closeModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._modalController.dismiss();

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return ModalEditProfileComponent;
      }();

      ModalEditProfileComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }];
      };

      ModalEditProfileComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-edit-profile',
        template: _raw_loader_modal_edit_profile_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_edit_profile_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ModalEditProfileComponent);
      /***/
    },

    /***/
    "GOBA":
    /*!********************************************************!*\
      !*** ./src/app/tabs/profile/profile-routing.module.ts ***!
      \********************************************************/

    /*! exports provided: ProfilePageRoutingModule */

    /***/
    function GOBA(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function () {
        return ProfilePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./profile.page */
      "hPWA");

      var routes = [{
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
      }];

      var ProfilePageRoutingModule = function ProfilePageRoutingModule() {
        _classCallCheck(this, ProfilePageRoutingModule);
      };

      ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ProfilePageRoutingModule);
      /***/
    },

    /***/
    "Z8mI":
    /*!**************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/profile/profile.page.html ***!
      \**************************************************************************************/

    /*! exports provided: default */

    /***/
    function Z8mI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"false\">\n  <ion-toolbar\n          color=\"dark\"\n          class=\"layout-toolbar\"\n  >\n    <ion-menu-button *ngIf=\"mainLayoutHelper.menuToggleEmitter$ | async\" slot=\"end\" color=\"light\" class=\"header-menu-button\" (click)=\"openMenu()\">\n      <ion-icon class=\"menu-icon\" slot=\"icon-only\" size=\"large\" name=\"menu-outline\"></ion-icon>\n    </ion-menu-button>\n  </ion-toolbar>\n\n  <div class=\"profile-header__wrap\">\n    <div class=\"d-flex flex-column\">\n      <ion-text color=\"light\" class=\"title-20\">Mike Johanssen</ion-text>\n      <ion-text color=\"tertiary\" class=\"text-16\">Active since 2019</ion-text>\n    </div>\n  </div>\n</ion-header>\n\n<ion-content color=\"primary\" [fullscreen]=\"true\" class=\"ion-padding\">\n  <div class=\"d-flex flex-column ion-margin-bottom\">\n    <ion-text color=\"light\" class=\"text-16\">Date of Birth</ion-text>\n    <ion-text color=\"tertiary\" class=\"text-16\">June 28, 1989</ion-text>\n  </div>\n\n  <div class=\"d-flex flex-column ion-margin-bottom\">\n    <ion-text color=\"light\" class=\"text-16\">Location</ion-text>\n    <ion-text color=\"tertiary\" class=\"text-16\">Alderman’s Walk 3183\n      West London, UK</ion-text>\n  </div>\n\n  <div class=\"divisor\"></div>\n\n  <div>\n    <ion-button\n            color=\"success\"\n            expand=\"block\"\n            class=\"ion-margin-top\"\n            (click)=\"editProfile()\"\n    >\n      <ion-text color=\"light\" class=\"text-15-500\">Edit Profile</ion-text>\n    </ion-button>\n\n    <ion-button color=\"dark\" fill=\"clear\" expand=\"block\" class=\"mt12\" (click)=\"logout()\">\n      <ion-text color=\"danger\" class=\"text-16\">Sign out</ion-text>\n    </ion-button>\n  </div>\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "f9Im":
    /*!************************************************!*\
      !*** ./src/app/tabs/profile/profile.module.ts ***!
      \************************************************/

    /*! exports provided: ProfilePageModule */

    /***/
    function f9Im(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
        return ProfilePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _profile_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./profile-routing.module */
      "GOBA");
      /* harmony import */


      var _profile_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./profile.page */
      "hPWA");
      /* harmony import */


      var _modals_modal_edit_profile_modal_edit_profile_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./modals/modal-edit-profile/modal-edit-profile.component */
      "CwGv");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../shared/shared.module */
      "PCNd");

      var ProfilePageModule = function ProfilePageModule() {
        _classCallCheck(this, ProfilePageModule);
      };

      ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"], _profile_routing_module__WEBPACK_IMPORTED_MODULE_3__["ProfilePageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"]],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_4__["ProfilePage"], _modals_modal_edit_profile_modal_edit_profile_component__WEBPACK_IMPORTED_MODULE_5__["ModalEditProfileComponent"]]
      })], ProfilePageModule);
      /***/
    },

    /***/
    "hPWA":
    /*!**********************************************!*\
      !*** ./src/app/tabs/profile/profile.page.ts ***!
      \**********************************************/

    /*! exports provided: ProfilePage */

    /***/
    function hPWA(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
        return ProfilePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./profile.page.html */
      "Z8mI");
      /* harmony import */


      var _profile_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./profile.page.scss */
      "+04C");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _shared_layouts_mail_layout_main_layout_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../shared/layouts/mail-layout/main-layout.helper */
      "MJS4");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _modals_modal_edit_profile_modal_edit_profile_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./modals/modal-edit-profile/modal-edit-profile.component */
      "CwGv");
      /* harmony import */


      var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../shared/store/core.store */
      "8e7N");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../pages/auth/auth-routes.enum */
      "mKaM");

      var ProfilePage = /*#__PURE__*/function () {
        function ProfilePage(mainLayoutHelper, _modalController, _coreStore, _router) {
          _classCallCheck(this, ProfilePage);

          this.mainLayoutHelper = mainLayoutHelper;
          this._modalController = _modalController;
          this._coreStore = _coreStore;
          this._router = _router;
        }

        _createClass(ProfilePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "openMenu",
          value: function openMenu() {
            this.mainLayoutHelper.menuToggleEmitter$.next(false);
          }
        }, {
          key: "editProfile",
          value: function editProfile() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var modal;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._modalController.create({
                        component: _modals_modal_edit_profile_modal_edit_profile_component__WEBPACK_IMPORTED_MODULE_6__["ModalEditProfileComponent"],
                        cssClass: 'modal-edit-profile'
                      });

                    case 2:
                      modal = _context2.sent;
                      _context2.next = 5;
                      return modal.present();

                    case 5:
                      return _context2.abrupt("return", _context2.sent);

                    case 6:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "logout",
          value: function logout() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this._coreStore.clearLogout();

                    case 2:
                      _context3.next = 4;
                      return this._router.navigate(['/', _pages_auth_auth_routes_enum__WEBPACK_IMPORTED_MODULE_9__["AuthRoutesEnum"].ROOT]);

                    case 4:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }]);

        return ProfilePage;
      }();

      ProfilePage.ctorParameters = function () {
        return [{
          type: _shared_layouts_mail_layout_main_layout_helper__WEBPACK_IMPORTED_MODULE_4__["MainLayoutHelper"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }, {
          type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_7__["CoreStore"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]
        }];
      };

      ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-profile',
        template: _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_profile_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ProfilePage);
      /***/
    },

    /***/
    "lSv9":
    /*!******************************************************************************************!*\
      !*** ./src/app/tabs/profile/modals/modal-edit-profile/modal-edit-profile.component.scss ***!
      \******************************************************************************************/

    /*! exports provided: default */

    /***/
    function lSv9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-input {\n  margin-top: 12px;\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n}\n\n.apply-btn {\n  width: 100%;\n  max-width: 320px;\n}\n\nion-item {\n  --inner-padding-end: 0;\n  margin-bottom: 20px;\n  margin-right: 24px;\n}\n\n.upload-photo {\n  position: relative;\n  margin: auto auto 28px;\n  width: 140px;\n  height: 140px;\n  background-image: url(\"/assets/images/profile.png\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: contain;\n}\n\n.upload-photo ion-icon {\n  position: relative;\n  top: -20px;\n  left: -20px;\n  font-size: 44px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLWVkaXQtcHJvZmlsZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EseURBQUE7RUFDQSx1REFBQTtFQUNBLDBDQUFBO0VBQ0EsZ0NBQUE7RUFDQSw4QkFBQTtFQUNBLDhCQUFBO0VBQ0EsaUNBQUE7RUFDQSxnREFBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFFRjs7QUFDQTtFQUNFLGtCQUFBO0VBRUEsc0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUVBLG1EQUFBO0VBQ0EsNEJBQUE7RUFDQSwyQkFBQTtFQUNBLHdCQUFBO0FBQUY7O0FBRUU7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBRUEsZUFBQTtBQURKIiwiZmlsZSI6Im1vZGFsLWVkaXQtcHJvZmlsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pbnB1dCB7XHJcbiAgbWFyZ2luLXRvcDogMTJweDtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9uOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG59XHJcblxyXG4uYXBwbHktYnRuIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXgtd2lkdGg6IDMyMHB4O1xyXG59XHJcbmlvbi1pdGVtIHtcclxuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyNHB4O1xyXG59XHJcblxyXG4udXBsb2FkLXBob3RvIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gIG1hcmdpbjogYXV0byBhdXRvIDI4cHg7XHJcbiAgd2lkdGg6IDE0MHB4O1xyXG4gIGhlaWdodDogMTQwcHg7XHJcblxyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi9hc3NldHMvaW1hZ2VzL3Byb2ZpbGUucG5nXCIpO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcclxuXHJcbiAgaW9uLWljb24ge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtMjBweDtcclxuICAgIGxlZnQ6IC0yMHB4O1xyXG5cclxuICAgIGZvbnQtc2l6ZTogNDRweDtcclxuICB9XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "sF51":
    /*!********************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/profile/modals/modal-edit-profile/modal-edit-profile.component.html ***!
      \********************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function sF51(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <form [formGroup]=\"form\" class=\"ion-margin-top\">\n    <div class=\"upload-photo\">\n      <ion-icon name=\"add-circle\" color=\"success\"></ion-icon>\n    </div>\n\n    <div class=\"divisor mb20 \"></div>\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">First Name</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"firstName\"></ion-input>\n    </ion-item>\n\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Last Name</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"lastName\"></ion-input>\n    </ion-item>\n\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Date of Birth</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"date\"></ion-input>\n    </ion-item>\n\n    <ion-item color=\"dark\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Location</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Start typing location\" formControlName=\"location\"></ion-input>\n    </ion-item>\n\n    <div class=\"ion-margin\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Gender</ion-text>\n      </ion-label>\n      <div class=\"d-flex ion-justify-content-between\">\n        <ion-button color=\"primary\" expand=\"block\" size=\"default\" fill=\"solid\" class=\"w100percent mr20\">\n          <ion-text color=\"tertiary\">Female</ion-text>\n        </ion-button>\n        <ion-button color=\"secondary\" expand=\"block\" size=\"default\" fill=\"outline\" class=\"w100percent\">\n          <ion-text color=\"secondary\">Male</ion-text>\n        </ion-button>\n      </div>\n    </div>\n  </form>\n</ion-content>\n<ion-footer>\n  <ion-toolbar color=\"dark\">\n    <ion-button (click)=\"closeModal()\" class=\"ion-margin-start ion-margin-end mb12 apply-btn\" fill=\"solid\" color=\"success\" expand=\"block\">\n      Save\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=profile-profile-module-es5.js.map