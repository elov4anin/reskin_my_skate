(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stores-stores-module"],{

/***/ "8x4p":
/*!**********************************************!*\
  !*** ./src/app/tabs/stores/stores.module.ts ***!
  \**********************************************/
/*! exports provided: StoresPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresPageModule", function() { return StoresPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _stores_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stores-routing.module */ "KgzX");
/* harmony import */ var _stores_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stores.page */ "snXs");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/shared.module */ "PCNd");





let StoresPageModule = class StoresPageModule {
};
StoresPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _stores_routing_module__WEBPACK_IMPORTED_MODULE_2__["StoresPageRoutingModule"]
        ],
        declarations: [_stores_page__WEBPACK_IMPORTED_MODULE_3__["StoresPage"]]
    })
], StoresPageModule);



/***/ }),

/***/ "HCe5":
/*!***************************************************!*\
  !*** ./src/app/shared/services/stores.service.ts ***!
  \***************************************************/
/*! exports provided: StoresService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresService", function() { return StoresService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _api_creator_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./api-creator.service */ "dNst");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



let StoresService = class StoresService {
    constructor(_api) {
        this._api = _api;
    }
    getStores(params) {
        return this._api.basePostRequest('integration/myskate/myskate-stores-limited.php', params);
    }
};
StoresService.ctorParameters = () => [
    { type: _api_creator_service__WEBPACK_IMPORTED_MODULE_1__["ApiCreatorService"] }
];
StoresService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: "root"
    })
], StoresService);



/***/ }),

/***/ "KgzX":
/*!******************************************************!*\
  !*** ./src/app/tabs/stores/stores-routing.module.ts ***!
  \******************************************************/
/*! exports provided: StoresPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresPageRoutingModule", function() { return StoresPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _stores_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stores.page */ "snXs");




const routes = [
    {
        path: '',
        component: _stores_page__WEBPACK_IMPORTED_MODULE_3__["StoresPage"]
    },
    {
        path: ':id',
        loadChildren: () => Promise.all(/*! import() | store-detail-store-detail-module */[__webpack_require__.e("common"), __webpack_require__.e("store-detail-store-detail-module")]).then(__webpack_require__.bind(null, /*! ./store-detail/store-detail.module */ "4Ft+")).then(m => m.StoreDetailPageModule)
    }
];
let StoresPageRoutingModule = class StoresPageRoutingModule {
};
StoresPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], StoresPageRoutingModule);



/***/ }),

/***/ "WVNc":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/stores/stores.page.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout>\n\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center\">\n    <ion-text color=\"light\" class=\"title-20\">Stores</ion-text>\n    <ion-button fill=\"solid\" (click)=\"sort()\" class=\"add-btn\">\n      <ion-icon src=\"assets/images/svg-icons/swap_vert-24px.svg\"></ion-icon>\n      <ion-text color=\"secondary\" class=\"text-16\">Sort</ion-text>\n    </ion-button>\n  </header>\n\n  <ion-list color=\"primary\">\n    <ion-item *ngFor=\"let s of stores\" color=\"primary\" lines=\"none\" (click)=\"openStore(s)\">\n      <ion-thumbnail slot=\"start\" class=\"pos-relative\">\n        <ion-badge color=\"success\" class=\"badge-into-thumbnail\">Featured</ion-badge>\n        <img src=\"../../../assets/images/thumbnall.png\">\n      </ion-thumbnail>\n      <div class=\"d-flex flex-column \">\n        <ion-text color=\"light\" class=\"mb12 text-16\">{{s.name}}</ion-text>\n        <ion-text color=\"medium\" class=\"text-15\">{{s.address_1}}</ion-text>\n      </div>\n    </ion-item>\n  </ion-list>\n\n  <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n    <ion-infinite-scroll-content\n            loadingSpinner=\"bubbles\"\n            loadingText=\"Loading more...\"\n    >\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n\n</app-mail-layout>\n");

/***/ }),

/***/ "eSxj":
/*!**********************************************!*\
  !*** ./src/app/tabs/stores/stores.page.scss ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-list {\n  background: var(--ion-color-primary);\n}\n\nion-item {\n  --padding-top: 12px;\n  --padding-bottom: 12px;\n  --padding-start: 0px;\n  --inner-padding-end: 5px;\n}\n\nion-thumbnail {\n  width: 140px;\n  height: 100px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzdG9yZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usb0NBQUE7QUFBRjs7QUFHQTtFQUNFLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxvQkFBQTtFQUNBLHdCQUFBO0FBQUY7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUNGIiwiZmlsZSI6InN0b3Jlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW9uLWxpc3Qge1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gIC0tcGFkZGluZy10b3A6IDEycHg7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbTogMTJweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAtLWlubmVyLXBhZGRpbmctZW5kOiA1cHg7XHJcbn1cclxuaW9uLXRodW1ibmFpbCAge1xyXG4gIHdpZHRoOiAxNDBweDtcclxuICBoZWlnaHQ6IDEwMHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "snXs":
/*!********************************************!*\
  !*** ./src/app/tabs/stores/stores.page.ts ***!
  \********************************************/
/*! exports provided: StoresPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoresPage", function() { return StoresPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_stores_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./stores.page.html */ "WVNc");
/* harmony import */ var _stores_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stores.page.scss */ "eSxj");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../tabs.enum */ "162u");
/* harmony import */ var _shared_services_stores_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/services/stores.service */ "HCe5");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../shared/enums/Storage.enum */ "03gG");











let StoresPage = class StoresPage {
    constructor(_storeService, _router, _coreStore) {
        this._storeService = _storeService;
        this._router = _router;
        this._coreStore = _coreStore;
        this.stores = [];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_8__["Subject"]();
    }
    ngOnInit() {
        this._storeService.getStores({ page: 0 })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["takeUntil"])(this.componentDestroyed))
            .subscribe(res => this.stores = res.stores);
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    sort() {
    }
    loadData($event) {
    }
    openStore(store) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_10__["StorageEnum"].SELECTED_STORE, store);
            yield this._router.navigate(['/', _tabs_enum__WEBPACK_IMPORTED_MODULE_5__["TABS_MAIN_ROUTE"], _tabs_enum__WEBPACK_IMPORTED_MODULE_5__["tabsEnum2RouteMapping"].STORES, store.id]);
        });
    }
};
StoresPage.ctorParameters = () => [
    { type: _shared_services_stores_service__WEBPACK_IMPORTED_MODULE_6__["StoresService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_9__["CoreStore"] }
];
StoresPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-stores',
        template: _raw_loader_stores_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_stores_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], StoresPage);



/***/ })

}]);
//# sourceMappingURL=stores-stores-module-es2015.js.map