(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["events-events-module"], {
    /***/
    "JHJp":
    /*!**********************************************!*\
      !*** ./src/app/tabs/events/events.page.scss ***!
      \**********************************************/

    /*! exports provided: default */

    /***/
    function JHJp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJldmVudHMucGFnZS5zY3NzIn0= */";
      /***/
    },

    /***/
    "MX77":
    /*!**********************************************!*\
      !*** ./src/app/tabs/events/events.module.ts ***!
      \**********************************************/

    /*! exports provided: EventsPageModule */

    /***/
    function MX77(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EventsPageModule", function () {
        return EventsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _events_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./events-routing.module */
      "k/4q");
      /* harmony import */


      var _events_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./events.page */
      "gkB1");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../shared/shared.module */
      "PCNd");

      var EventsPageModule = function EventsPageModule() {
        _classCallCheck(this, EventsPageModule);
      };

      EventsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"], _events_routing_module__WEBPACK_IMPORTED_MODULE_2__["EventsPageRoutingModule"]],
        declarations: [_events_page__WEBPACK_IMPORTED_MODULE_3__["EventsPage"]]
      })], EventsPageModule);
      /***/
    },

    /***/
    "gkB1":
    /*!********************************************!*\
      !*** ./src/app/tabs/events/events.page.ts ***!
      \********************************************/

    /*! exports provided: EventsPage */

    /***/
    function gkB1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EventsPage", function () {
        return EventsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_events_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./events.page.html */
      "mQ8w");
      /* harmony import */


      var _events_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./events.page.scss */
      "JHJp");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../shared/services/team.service */
      "mqDS");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");

      var EventsPage = /*#__PURE__*/function () {
        function EventsPage(_team) {
          _classCallCheck(this, EventsPage);

          this._team = _team;
          this.events = [];
          this.isDisableLoadMore = false;
          this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
          this.page = 0;
        }

        _createClass(EventsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.getEvents();
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            this.componentDestroyed.next();
            this.componentDestroyed.unsubscribe();
          }
        }, {
          key: "getEvents",
          value: function getEvents() {
            var _this = this;

            this._team.getEventList(this.page).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["takeUntil"])(this.componentDestroyed)).subscribe(function (res) {
              return _this.events = _this.events.concat(res.events);
            });
          }
        }, {
          key: "loadMore",
          value: function loadMore() {
            var _this2 = this;

            this.page++;

            this._team.getEventList(this.page).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["takeUntil"])(this.componentDestroyed)).subscribe(function (res) {
              _this2.events = _this2.events.concat(res.events);

              if (res.events.length < 10) {
                _this2.isDisableLoadMore = true;
              }
            });
          }
        }]);

        return EventsPage;
      }();

      EventsPage.ctorParameters = function () {
        return [{
          type: _shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__["TeamService"]
        }];
      };

      EventsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-events',
        template: _raw_loader_events_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_events_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], EventsPage);
      /***/
    },

    /***/
    "k/4q":
    /*!******************************************************!*\
      !*** ./src/app/tabs/events/events-routing.module.ts ***!
      \******************************************************/

    /*! exports provided: EventsPageRoutingModule */

    /***/
    function k4q(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EventsPageRoutingModule", function () {
        return EventsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _events_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./events.page */
      "gkB1");

      var routes = [{
        path: '',
        component: _events_page__WEBPACK_IMPORTED_MODULE_3__["EventsPage"]
      }, {
        path: ':id',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | event-detail-event-detail-module */
          [__webpack_require__.e("common"), __webpack_require__.e("event-detail-event-detail-module")]).then(__webpack_require__.bind(null,
          /*! ./event-detail/event-detail.module */
          "5/O0")).then(function (m) {
            return m.EventDetailPageModule;
          });
        }
      }];

      var EventsPageRoutingModule = function EventsPageRoutingModule() {
        _classCallCheck(this, EventsPageRoutingModule);
      };

      EventsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EventsPageRoutingModule);
      /***/
    },

    /***/
    "mQ8w":
    /*!************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/events/events.page.html ***!
      \************************************************************************************/

    /*! exports provided: default */

    /***/
    function mQ8w(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-mail-layout [footerSlot]=\"footer\" class=\"mainLayoutHeight124\">\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center\">\n    <ion-text color=\"light\" class=\"title-20\">Events</ion-text>\n\n  </header>\n\n  <ng-container *ngIf=\"events.length > 0; else emptyBlock\">\n    <app-event *ngFor=\"let item of events;\" [event]=\"events\"></app-event>\n  </ng-container>\n  <ng-template #emptyBlock>\n    <ion-text color=\"tertiary\" class=\"empty-title\">No events yet</ion-text>\n  </ng-template>\n\n <!-- <ion-virtual-scroll [items]=\"[1, 2, 3]\" approxItemHeight=\"220px\">\n    <ion-card *virtualItem=\"let item; let itemBounds = bounds;\" color=\"primary\" (click)=\"openEvent(item)\">\n      <div>\n        <ion-img [src]=\"item.image\" height=\"160\" [alt]=\"item.name\"></ion-img>\n      </div>\n      <ion-card-header color=\"dark\" class=\"d-flex ion-justify-content-between events-card-header\">\n\n        <div class=\"d-flex flex-column ion-justify-content-center mr8\">\n          <ion-card-title color=\"light\" class=\"text-16-500\">{{item.name}}</ion-card-title>\n          <ion-text color=\"tertiary\" class=\"text-12\">{{item.address_line_1}}{{item.city ? ', ' + item.city : ''}}</ion-text>\n        </div>\n\n        <app-calendar-day [date]=\"item.date\"></app-calendar-day>\n\n      </ion-card-header>\n    </ion-card>\n  </ion-virtual-scroll>-->\n  <ng-template #footer>\n    <ion-footer *ngIf=\"!isDisableLoadMore\">\n      <ion-toolbar color=\"primary\">\n        <ion-buttons class=\"ion-justify-content-center\">\n          <ion-button fill=\"clear\" (click)=\"loadMore()\" [disabled]=\"isDisableLoadMore\">\n            <ion-icon slot=\"start\" name=\"arrow-down\" color=\"secondary\"></ion-icon>\n            <ion-text color=\"secondary\" class=\"text-16\">Load more</ion-text>\n          </ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n\n    </ion-footer>\n  </ng-template>\n</app-mail-layout>\n\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=events-events-module-es5.js.map