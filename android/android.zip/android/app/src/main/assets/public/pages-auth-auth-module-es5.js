(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-auth-auth-module"], {
    /***/
    "BUwF":
    /*!***************************************************!*\
      !*** ./src/app/pages/auth/auth-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: AuthRoutingModule */

    /***/
    function BUwF(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthRoutingModule", function () {
        return AuthRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _auth_routes_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./auth-routes.enum */
      "mKaM");

      var routes = [{
        path: '',
        redirectTo: "/".concat(_auth_routes_enum__WEBPACK_IMPORTED_MODULE_3__["AuthRoutesEnum"].ROOT, "/") + _auth_routes_enum__WEBPACK_IMPORTED_MODULE_3__["AuthRoutesEnum"].LOGIN,
        pathMatch: 'full'
      }, {
        path: _auth_routes_enum__WEBPACK_IMPORTED_MODULE_3__["AuthRoutesEnum"].LOGIN,
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | login-login-module */
          [__webpack_require__.e("default~events-events-module~forgot-forgot-module~game-tab-game-tab-module~login-login-module~news-n~a54b75ee"), __webpack_require__.e("common"), __webpack_require__.e("login-login-module")]).then(__webpack_require__.bind(null,
          /*! ./login/login.module */
          "qdgq")).then(function (m) {
            return m.LoginPageModule;
          });
        }
      }, {
        path: _auth_routes_enum__WEBPACK_IMPORTED_MODULE_3__["AuthRoutesEnum"].REG,
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | reg-reg-module */
          [__webpack_require__.e("default~events-events-module~forgot-forgot-module~game-tab-game-tab-module~login-login-module~news-n~a54b75ee"), __webpack_require__.e("common"), __webpack_require__.e("reg-reg-module")]).then(__webpack_require__.bind(null,
          /*! ./reg/reg.module */
          "BRbS")).then(function (m) {
            return m.RegPageModule;
          });
        }
      }, {
        path: _auth_routes_enum__WEBPACK_IMPORTED_MODULE_3__["AuthRoutesEnum"].FORGOT_PASS,
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | forgot-forgot-module */
          [__webpack_require__.e("default~events-events-module~forgot-forgot-module~game-tab-game-tab-module~login-login-module~news-n~a54b75ee"), __webpack_require__.e("common"), __webpack_require__.e("forgot-forgot-module")]).then(__webpack_require__.bind(null,
          /*! ./forgot/forgot.module */
          "Ykc6")).then(function (m) {
            return m.ForgotPageModule;
          });
        }
      }];

      var AuthRoutingModule = function AuthRoutingModule() {
        _classCallCheck(this, AuthRoutingModule);
      };

      AuthRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AuthRoutingModule);
      /***/
    },

    /***/
    "lBUW":
    /*!*******************************************!*\
      !*** ./src/app/pages/auth/auth.module.ts ***!
      \*******************************************/

    /*! exports provided: AuthModule */

    /***/
    function lBUW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthModule", function () {
        return AuthModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _auth_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./auth-routing.module */
      "BUwF");

      var AuthModule = function AuthModule() {
        _classCallCheck(this, AuthModule);
      };

      AuthModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_auth_routing_module__WEBPACK_IMPORTED_MODULE_2__["AuthRoutingModule"]],
        declarations: []
      })], AuthModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-auth-auth-module-es5.js.map