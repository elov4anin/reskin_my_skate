(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-failed-failed-module"],{

/***/ "EHVd":
/*!**********************************************************!*\
  !*** ./src/app/pages/game/pages/failed/failed.page.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".failed {\n  height: 100%;\n  background-image: url(\"/assets/images/failed.png\");\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n}\n.failed__text {\n  position: absolute;\n  top: 130px;\n}\n.failed__wrapper {\n  margin-top: 300px;\n  width: 100%;\n  height: 100%;\n}\n.next-btn {\n  margin-top: auto;\n  margin-bottom: 40px;\n}\n.skate {\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGZhaWxlZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0Esa0RBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7QUFDRjtBQUNFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0FBQ0o7QUFFRTtFQUNFLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFBSjtBQUtBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtBQUZGO0FBSUE7RUFDRSxZQUFBO0FBREYiLCJmaWxlIjoiZmFpbGVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mYWlsZWQge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1hZ2VzL2ZhaWxlZC5wbmcnKTtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG5cclxuICAmX190ZXh0IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTMwcHg7XHJcbiAgfVxyXG5cclxuICAmX193cmFwcGVyIHtcclxuICAgIG1hcmdpbi10b3A6IDMwMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcblxyXG4gIH1cclxufVxyXG5cclxuLm5leHQtYnRuIHtcclxuICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbn1cclxuLnNrYXRlIHtcclxuICBtYXJnaW46IGF1dG87XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "dLaL":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/pages/failed/failed.page.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"primary\">\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"stopGame()\">\n      <ion-icon name=\"power-outline\" color=\"danger\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <div class=\"d-flex flex-column ion-align-items-center failed\">\n    <ion-text class=\"failed__text title-34\" color=\"tertiary\">Failed it!</ion-text>\n    <ion-text class=\"failed__text title-34\" color=\"tertiary\">Failed it!</ion-text>\n    <ion-text class=\"failed__text title-34\" color=\"tertiary\">Failed it!</ion-text>\n    <ion-text class=\"failed__text title-34\" color=\"tertiary\">Failed it!</ion-text>\n\n    <div class=\"d-flex flex-column ion-align-self-center ion-align-items-center ion-padding-start ion-padding-end failed__wrapper\">\n      <ion-avatar>\n        <img src=\"../../../../../assets/images/person.png\">\n      </ion-avatar>\n\n      <ion-text color=\"tertiary\" class=\"mt12 text-16\">Bobby Mount</ion-text>\n      <ion-text class=\"skate title-34\">\n        <ion-text color=\"secondary\">S.</ion-text>\n        <ion-text>K.</ion-text>\n        <ion-text>A.</ion-text>\n        <ion-text>T.</ion-text>\n        <ion-text>E</ion-text>\n      </ion-text>\n      <ion-button class=\"w100percent next-btn\" fill=\"solid\" color=\"success\" expand=\"block\" (click)=\"nextPlayer()\">\n        Next Player\n      </ion-button>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "skNk":
/*!**********************************************************!*\
  !*** ./src/app/pages/game/pages/failed/failed.module.ts ***!
  \**********************************************************/
/*! exports provided: FailedPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FailedPageModule", function() { return FailedPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _failed_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./failed-routing.module */ "svk1");
/* harmony import */ var _failed_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./failed.page */ "ssUx");







let FailedPageModule = class FailedPageModule {
};
FailedPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _failed_routing_module__WEBPACK_IMPORTED_MODULE_5__["FailedPageRoutingModule"]
        ],
        declarations: [_failed_page__WEBPACK_IMPORTED_MODULE_6__["FailedPage"]]
    })
], FailedPageModule);



/***/ }),

/***/ "ssUx":
/*!********************************************************!*\
  !*** ./src/app/pages/game/pages/failed/failed.page.ts ***!
  \********************************************************/
/*! exports provided: FailedPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FailedPage", function() { return FailedPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_failed_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./failed.page.html */ "dLaL");
/* harmony import */ var _failed_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./failed.page.scss */ "EHVd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../tabs/tabs.enum */ "162u");
/* harmony import */ var _game_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../game-routes */ "2DP2");







let FailedPage = class FailedPage {
    constructor(_router) {
        this._router = _router;
    }
    ngOnInit() {
    }
    stopGame() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__["tabsEnum2RouteMapping"].GAME]);
        });
    }
    nextPlayer() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._router.navigate(['/', _game_routes__WEBPACK_IMPORTED_MODULE_6__["GameRoutes"].ROOT, _game_routes__WEBPACK_IMPORTED_MODULE_6__["GameRoutes"].CURRENT]);
        });
    }
};
FailedPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
FailedPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-failed',
        template: _raw_loader_failed_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_failed_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], FailedPage);



/***/ }),

/***/ "svk1":
/*!******************************************************************!*\
  !*** ./src/app/pages/game/pages/failed/failed-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: FailedPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FailedPageRoutingModule", function() { return FailedPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _failed_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./failed.page */ "ssUx");




const routes = [
    {
        path: '',
        component: _failed_page__WEBPACK_IMPORTED_MODULE_3__["FailedPage"]
    }
];
let FailedPageRoutingModule = class FailedPageRoutingModule {
};
FailedPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FailedPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-failed-failed-module-es2015.js.map