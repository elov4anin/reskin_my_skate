(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-current-standings-current-standings-module"], {
    /***/
    "8qKN":
    /*!**********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/pages/current-standings/current-standings.page.html ***!
      \**********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function qKN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content color=\"primary\">\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"stopGame()\">\n      <ion-icon name=\"power-outline\" color=\"danger\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <div class=\"h100percent d-flex flex-column ion-align-items-center ion-margin-start ion-margin-end current\">\n    <ion-text color=\"light\" class=\"title-34  \">Current <br> Standings</ion-text>\n\n    <div class=\"current__wrapper\">\n      <div class=\"d-flex flex-column ion-align-items-center nailed\">\n        <ion-avatar>\n          <img src=\"../../../../../assets/images/person.png\">\n        </ion-avatar>\n\n        <ion-text color=\"tertiary\" class=\"mt12 text-16\">Bobby Mount</ion-text>\n        <ion-text class=\" skate title-34\">\n          <ion-text>S.</ion-text>\n          <ion-text>K.</ion-text>\n          <ion-text>A.</ion-text>\n          <ion-text>T.</ion-text>\n          <ion-text>E</ion-text>\n        </ion-text>\n      </div>\n\n      <div class=\"d-flex flex-column ion-align-items-center failed\">\n        <ion-avatar>\n          <img src=\"../../../../../assets/images/person.png\">\n        </ion-avatar>\n\n        <ion-text color=\"tertiary\" class=\"mt12 text-16\">Bobby Mount</ion-text>\n\n        <ion-text class=\"skate title-34\">\n          <ion-text color=\"secondary\">S.</ion-text>\n          <ion-text>K.</ion-text>\n          <ion-text>A.</ion-text>\n          <ion-text>T.</ion-text>\n          <ion-text>E</ion-text>\n        </ion-text>\n      </div>\n    </div>\n\n    <ion-button class=\"w100percent next-btn\" fill=\"solid\" color=\"success\" expand=\"block\" (click)=\"nexTrick()\">\n     Next Trick\n    </ion-button>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "9X0p":
    /*!********************************************************************************!*\
      !*** ./src/app/pages/game/pages/current-standings/current-standings.module.ts ***!
      \********************************************************************************/

    /*! exports provided: CurrentStandingsPageModule */

    /***/
    function X0p(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CurrentStandingsPageModule", function () {
        return CurrentStandingsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _current_standings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./current-standings-routing.module */
      "hf/9");
      /* harmony import */


      var _current_standings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./current-standings.page */
      "dgGH");

      var CurrentStandingsPageModule = function CurrentStandingsPageModule() {
        _classCallCheck(this, CurrentStandingsPageModule);
      };

      CurrentStandingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _current_standings_routing_module__WEBPACK_IMPORTED_MODULE_5__["CurrentStandingsPageRoutingModule"]],
        declarations: [_current_standings_page__WEBPACK_IMPORTED_MODULE_6__["CurrentStandingsPage"]]
      })], CurrentStandingsPageModule);
      /***/
    },

    /***/
    "dgGH":
    /*!******************************************************************************!*\
      !*** ./src/app/pages/game/pages/current-standings/current-standings.page.ts ***!
      \******************************************************************************/

    /*! exports provided: CurrentStandingsPage */

    /***/
    function dgGH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CurrentStandingsPage", function () {
        return CurrentStandingsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_current_standings_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./current-standings.page.html */
      "8qKN");
      /* harmony import */


      var _current_standings_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./current-standings.page.scss */
      "el22");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../../tabs/tabs.enum */
      "162u");
      /* harmony import */


      var _game_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../game-routes */
      "2DP2");

      var CurrentStandingsPage = /*#__PURE__*/function () {
        function CurrentStandingsPage(_router) {
          _classCallCheck(this, CurrentStandingsPage);

          this._router = _router;
        }

        _createClass(CurrentStandingsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "stopGame",
          value: function stopGame() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_5__["tabsEnum2RouteMapping"].GAME]);

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "nexTrick",
          value: function nexTrick() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._router.navigate(['/', _game_routes__WEBPACK_IMPORTED_MODULE_6__["GameRoutes"].ROOT, _game_routes__WEBPACK_IMPORTED_MODULE_6__["GameRoutes"].CONGRADULATIONS]);

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return CurrentStandingsPage;
      }();

      CurrentStandingsPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
        }];
      };

      CurrentStandingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-current-standings',
        template: _raw_loader_current_standings_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_current_standings_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CurrentStandingsPage);
      /***/
    },

    /***/
    "el22":
    /*!********************************************************************************!*\
      !*** ./src/app/pages/game/pages/current-standings/current-standings.page.scss ***!
      \********************************************************************************/

    /*! exports provided: default */

    /***/
    function el22(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".current {\n  padding-top: 220px;\n  text-align: center;\n}\n\n.current__wrapper {\n  position: relative;\n}\n\n.nailed {\n  position: absolute;\n  top: 50px;\n  left: 10px;\n}\n\n.failed {\n  position: absolute;\n  top: 70px;\n  right: 10px;\n}\n\n.next-btn {\n  margin-top: auto;\n  margin-bottom: 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGN1cnJlbnQtc3RhbmRpbmdzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBR0E7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0FBQUY7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0YiLCJmaWxlIjoiY3VycmVudC1zdGFuZGluZ3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1cnJlbnQge1xyXG4gIHBhZGRpbmctdG9wOiAyMjBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5jdXJyZW50X193cmFwcGVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5uYWlsZWQge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDUwcHg7XHJcbiAgbGVmdDogMTBweDtcclxufVxyXG5cclxuXHJcbi5mYWlsZWQge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDcwcHg7XHJcbiAgcmlnaHQ6IDEwcHg7XHJcbn1cclxuLm5leHQtYnRuIHtcclxuICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "hf/9":
    /*!****************************************************************************************!*\
      !*** ./src/app/pages/game/pages/current-standings/current-standings-routing.module.ts ***!
      \****************************************************************************************/

    /*! exports provided: CurrentStandingsPageRoutingModule */

    /***/
    function hf9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CurrentStandingsPageRoutingModule", function () {
        return CurrentStandingsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _current_standings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./current-standings.page */
      "dgGH");

      var routes = [{
        path: '',
        component: _current_standings_page__WEBPACK_IMPORTED_MODULE_3__["CurrentStandingsPage"]
      }];

      var CurrentStandingsPageRoutingModule = function CurrentStandingsPageRoutingModule() {
        _classCallCheck(this, CurrentStandingsPageRoutingModule);
      };

      CurrentStandingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CurrentStandingsPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-current-standings-current-standings-module-es5.js.map