(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["news-item-news-item-module"],{

/***/ "/Dkw":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/news/news-item/news-item.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-mail-layout\n        [isNeedRightPadding]=\"false\"\n        [isNeedLeftPadding]=\"false\"\n        [isNotNeedPaddingTopHeader]=\"true\"\n>\n  <ion-grid class=\"ion-padding-start ion-padding-end mb12\">\n    <ion-row>\n      <ion-col class=\"p0\">\n        <ion-icon\n                class=\"icon-as-btn\"\n                color=\"secondary\"\n                name=\"arrow-back-outline\"\n                size=\"large\"\n                (click)=\"back()\"\n        ></ion-icon>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col class=\"p0\">\n        <ion-text color=\"light\" class=\"title-28\">{{news.title}}</ion-text>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-thumbnail>\n    <ion-img [src]=\"news.image\"></ion-img>\n  </ion-thumbnail>\n  <div class=\"ion-padding-start ion-padding-end ion-margin-top\">\n    <ion-text color=\"tertiary\" class=\"text-15\">{{news.content}}</ion-text>\n  </div>\n</app-mail-layout>\n");

/***/ }),

/***/ "Di+K":
/*!*****************************************************************!*\
  !*** ./src/app/tabs/news/news-item/news-item-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: NewsItemPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsItemPageRoutingModule", function() { return NewsItemPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _news_item_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./news-item.page */ "hj+F");




const routes = [
    {
        path: '',
        component: _news_item_page__WEBPACK_IMPORTED_MODULE_3__["NewsItemPage"]
    }
];
let NewsItemPageRoutingModule = class NewsItemPageRoutingModule {
};
NewsItemPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NewsItemPageRoutingModule);



/***/ }),

/***/ "H91t":
/*!*********************************************************!*\
  !*** ./src/app/tabs/news/news-item/news-item.module.ts ***!
  \*********************************************************/
/*! exports provided: NewsItemPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsItemPageModule", function() { return NewsItemPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _news_item_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./news-item-routing.module */ "Di+K");
/* harmony import */ var _news_item_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./news-item.page */ "hj+F");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/shared.module */ "PCNd");





let NewsItemPageModule = class NewsItemPageModule {
};
NewsItemPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _news_item_routing_module__WEBPACK_IMPORTED_MODULE_2__["NewsItemPageRoutingModule"]
        ],
        declarations: [_news_item_page__WEBPACK_IMPORTED_MODULE_3__["NewsItemPage"]]
    })
], NewsItemPageModule);



/***/ }),

/***/ "Swb0":
/*!*********************************************************!*\
  !*** ./src/app/tabs/news/news-item/news-item.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-thumbnail {\n  width: 100%;\n  height: 240px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbmV3cy1pdGVtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBQ0YiLCJmaWxlIjoibmV3cy1pdGVtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10aHVtYm5haWwge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMjQwcHg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "hj+F":
/*!*******************************************************!*\
  !*** ./src/app/tabs/news/news-item/news-item.page.ts ***!
  \*******************************************************/
/*! exports provided: NewsItemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsItemPage", function() { return NewsItemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_news_item_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./news-item.page.html */ "/Dkw");
/* harmony import */ var _news_item_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./news-item.page.scss */ "Swb0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/store/core.store */ "8e7N");






let NewsItemPage = class NewsItemPage {
    constructor(_location, _coreStore) {
        this._location = _location;
        this._coreStore = _coreStore;
    }
    ngOnInit() {
        this.news = this._coreStore.state.selectedNews;
    }
    back() {
        this._location.back();
    }
};
NewsItemPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_5__["CoreStore"] }
];
NewsItemPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-news-item',
        template: _raw_loader_news_item_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_news_item_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], NewsItemPage);



/***/ })

}]);
//# sourceMappingURL=news-item-news-item-module-es2015.js.map