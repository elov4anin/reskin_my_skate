(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reg-reg-module"], {
    /***/
    "8QSi":
    /*!**********************************************!*\
      !*** ./src/app/pages/auth/reg/reg.page.scss ***!
      \**********************************************/

    /*! exports provided: default */

    /***/
    function QSi(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".header {\n  margin-top: 38px;\n}\n\nion-input {\n  margin-top: 12px;\n  --background: var(--ion-color-medium-contrast) !important;\n  --placeholder-color: var(--ion-color-medium) !important;\n  --color: var(--ion-color-light) !important;\n  --padding-start: 16px !important;\n  --padding-end: 16px !important;\n  --padding-top: 10px !important;\n  --padding-botton: 10px !important;\n  --border-radius: var(--theme-base-border-radius);\n  border-radius: var(--theme-base-border-radius);\n}\n\n.apply-btn {\n  width: 100%;\n  max-width: 320px;\n  margin-top: 40px;\n}\n\nion-item {\n  --inner-padding-end: 0;\n  --inner-padding-bottom: var(--ion-margin);\n  margin-right: 5px;\n  --padding-start: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmVnLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLHlEQUFBO0VBQ0EsdURBQUE7RUFDQSwwQ0FBQTtFQUNBLGdDQUFBO0VBQ0EsOEJBQUE7RUFDQSw4QkFBQTtFQUNBLGlDQUFBO0VBQ0EsZ0RBQUE7RUFDQSw4Q0FBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLHNCQUFBO0VBQ0EseUNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRUYiLCJmaWxlIjoicmVnLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xyXG4gIG1hcmdpbi10b3A6IDM4cHg7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgbWFyZ2luLXRvcDogMTJweDtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpICFpbXBvcnRhbnQ7XHJcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSkgIWltcG9ydGFudDtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9uOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiB2YXIoLS10aGVtZS1iYXNlLWJvcmRlci1yYWRpdXMpO1xyXG4gIGJvcmRlci1yYWRpdXM6IHZhcigtLXRoZW1lLWJhc2UtYm9yZGVyLXJhZGl1cyk7XHJcbn1cclxuXHJcbi5hcHBseS1idG4ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1heC13aWR0aDogMzIwcHg7XHJcbiAgbWFyZ2luLXRvcDogNDBweDtcclxufVxyXG5pb24taXRlbSB7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcclxuICAtLWlubmVyLXBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tbWFyZ2luKTtcclxuICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "BRbS":
    /*!**********************************************!*\
      !*** ./src/app/pages/auth/reg/reg.module.ts ***!
      \**********************************************/

    /*! exports provided: RegPageModule */

    /***/
    function BRbS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegPageModule", function () {
        return RegPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _reg_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./reg-routing.module */
      "VN82");
      /* harmony import */


      var _reg_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./reg.page */
      "OGha");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../shared/shared.module */
      "PCNd");

      var RegPageModule = function RegPageModule() {
        _classCallCheck(this, RegPageModule);
      };

      RegPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"], _reg_routing_module__WEBPACK_IMPORTED_MODULE_3__["RegPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"]],
        declarations: [_reg_page__WEBPACK_IMPORTED_MODULE_4__["RegPage"]]
      })], RegPageModule);
      /***/
    },

    /***/
    "GeCW":
    /*!************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/auth/reg/reg.page.html ***!
      \************************************************************************************/

    /*! exports provided: default */

    /***/
    function GeCW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-mail-layout [isNeeBackBtn]=\"false\"[isNeedHeightWithTabsAndHeader]=\"true\">\n  <header class=\"d-flex ion-justify-content-between ion-align-items-center ion-margin-bottom header\">\n    <ion-text color=\"light\" class=\"title-20\">Register</ion-text>\n  </header>\n\n  <form [formGroup]=\"form\" class=\"ion-margin-top\">\n    <ion-item color=\"primary\" lines=\"none\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">First Name</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"firstName\"\n                 [minlength]=\"2\" [maxlength]=\"25\"\n                 [ngClass]=\"{'invalid-input': form.get('firstName').touched && form.get('firstName').invalid}\"\n      ></ion-input>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.firstName\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('firstName').hasError(validation.type) && (form.get('firstName').dirty || form.get('firstName').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Last Name</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"lastName\"\n                 [minlength]=\"2\" [maxlength]=\"25\"\n                 [ngClass]=\"{'invalid-input': form.get('lastName').touched && form.get('lastName').invalid}\"\n      ></ion-input>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.lastName\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('lastName').hasError(validation.type) && (form.get('lastName').dirty || form.get('lastName').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Email</ion-text>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"email\" autocomplete=\"off\"  type=\"email\"\n                 [minlength]=\"2\" [maxlength]=\"25\"\n                 [ngClass]=\"{'invalid-input': form.get('email').touched && form.get('email').invalid}\"\n      ></ion-input>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.email\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('email').hasError(validation.type) && (form.get('email').dirty || form.get('email').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\">\n      <ion-label position=\"stacked\">\n        <div class=\"d-flex ion-justify-content-between\">\n          <ion-text class=\"text-16\" color=\"light\">Password</ion-text>\n        </div>\n      </ion-label>\n      <ion-input placeholder=\"Type here\" formControlName=\"pwd\" type=\"password\" autocomplete=\"off\"\n                 [minlength]=\"8\" [maxlength]=\"40\"\n                 [ngClass]=\"{'invalid-input': form.get('pwd').touched && form.get('pwd').invalid}\"\n      ></ion-input>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.pwd\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('pwd').hasError(validation.type) && (form.get('pwd').dirty || form.get('pwd').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\"  class=\"large-pb\">\n      <ion-label position=\"stacked\">\n        <div class=\"d-flex ion-justify-content-between\">\n          <ion-text class=\"text-16\" color=\"light\">Confirm password</ion-text>\n        </div>\n      </ion-label>\n      <ion-input placeholder=\"Confirm Password\" formControlName=\"confirmPassword\" type=\"password\" autocomplete=\"off\"\n                 [minlength]=\"8\" [maxlength]=\"40\"\n                 [ngClass]=\"{'invalid-input': form.get('confirmPassword').touched && form.get('confirmPassword').invalid}\"\n      ></ion-input>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.pwd\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('confirmPassword').hasError(validation.type) && (form.get('confirmPassword').dirty || form.get('confirmPassword').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <ion-item color=\"primary\" lines=\"none\">\n      <ion-label position=\"stacked\">\n        <div class=\"d-flex ion-justify-content-between\">\n          <ion-text class=\"text-16\" color=\"light\">DOB</ion-text>\n        </div>\n      </ion-label>\n      <ion-datetime displayFormat=\"DD/MM/YYYY\" placeholder=\"Select Date\" formControlName=\"dob\" class=\"mt12\"\n                    [max]=\"maxYear\" mode=\"ios\"\n                    [ngClass]=\"{'invalid-input': form.get('dob').touched && form.get('dob').invalid}\"\n      ></ion-datetime>\n      <div class=\"validation-errors\">\n        <ng-container *ngFor=\"let validation of validationMessages.dob\">\n          <div class=\"error-message\"\n               *ngIf=\"form.get('dob').hasError(validation.type) && (form.get('dob').dirty || form.get('dob').touched)\"\n          >\n            {{ validation.message }}\n          </div>\n        </ng-container>\n      </div>\n    </ion-item>\n\n    <div class=\"ion-margin-top\">\n      <ion-label position=\"stacked\">\n        <ion-text class=\"text-16\">Gender</ion-text>\n      </ion-label>\n      <div class=\"d-flex ion-justify-content-between mt12\">\n        <ion-button color=\"darktwo\" expand=\"block\" size=\"default\" fill=\"solid\" class=\"w100percent mr20\">\n          <ion-text color=\"tertiary\">Female</ion-text>\n        </ion-button>\n        <ion-button color=\"secondary\" expand=\"block\" size=\"default\" fill=\"outline\" class=\"w100percent\">\n          <ion-text color=\"secondary\">Male</ion-text>\n        </ion-button>\n      </div>\n    </div>\n\n    <ion-button [disabled]=\"form.invalid || isReqSending\" (click)=\"register()\" class=\"mb12 apply-btn\" fill=\"solid\" color=\"success\" expand=\"block\">\n      <ng-container *ngIf=\"isReqSending; else textBlock\">\n        <ion-spinner name=\"lines-small\"></ion-spinner>Sending...\n      </ng-container>\n      <ng-template #textBlock>\n        Sign up\n      </ng-template>\n    </ion-button>\n  </form>\n  <ion-footer class=\"ion-margin-top\">\n    <ion-text class=\"text-15 d-block ion-text-center\" color=\"light\">\n      Already have an account?\n      <ion-text (click)=\"openLogin()\" color=\"secondary\"> Log in</ion-text>\n    </ion-text>\n  </ion-footer>\n</app-mail-layout>\n";
      /***/
    },

    /***/
    "OGha":
    /*!********************************************!*\
      !*** ./src/app/pages/auth/reg/reg.page.ts ***!
      \********************************************/

    /*! exports provided: RegPage */

    /***/
    function OGha(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegPage", function () {
        return RegPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_reg_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./reg.page.html */
      "GeCW");
      /* harmony import */


      var _reg_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./reg.page.scss */
      "8QSi");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../auth-routes.enum */
      "mKaM");
      /* harmony import */


      var _auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../auth.service */
      "zbnG");
      /* harmony import */


      var _shared_configs_response_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../../shared/configs/response.constants */
      "N7aL");
      /* harmony import */


      var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../../shared/enums/Storage.enum */
      "03gG");
      /* harmony import */


      var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../../shared/store/core.store */
      "8e7N");
      /* harmony import */


      var _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../../../shared/helpers/toast-notification.service */
      "b3vI");
      /* harmony import */


      var _shared_classes_validation_messages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ../../../shared/classes/validation-messages */
      "AEGu");
      /* harmony import */


      var dayjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! dayjs */
      "Wgwc");
      /* harmony import */


      var dayjs__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_13__);
      /* harmony import */


      var _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ../../../shared/configs/main.config */
      "phI0");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _shared_classes_validators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! ../../../shared/classes/validators */
      "Taae");

      var RegPage = /*#__PURE__*/function () {
        function RegPage(_router, _authService, _coreStore, _toast) {
          _classCallCheck(this, RegPage);

          this._router = _router;
          this._authService = _authService;
          this._coreStore = _coreStore;
          this._toast = _toast;
          this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            firstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(2), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(25)]),
            lastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(2), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(25)]),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].email]),
            pwd: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/)]),
            confirmPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]({
              value: '',
              disabled: true
            }, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(40), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/), Object(_shared_classes_validators__WEBPACK_IMPORTED_MODULE_17__["matchValuesValidator"])('pwd')]),
            dob: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])
          });
          this.validationMessages = _shared_classes_validation_messages__WEBPACK_IMPORTED_MODULE_12__["VALIDATION_MESSAGES"];
          this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_16__["Subject"]();
          this.isReqSending = false;
        }

        _createClass(RegPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.maxYear = dayjs__WEBPACK_IMPORTED_MODULE_13__().year() - _shared_configs_main_config__WEBPACK_IMPORTED_MODULE_14__["MIN_AGE"];
            this.form.get('pwd').valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_15__["takeUntil"])(this.componentDestroyed)).subscribe(function () {
              if (_this.form.get('pwd').valid && _this.form.get('confirmPassword').disabled) {
                _this.form.get('confirmPassword').enable();
              }

              if (_this.form.get('pwd').invalid && _this.form.get('confirmPassword').enabled) {
                _this.form.get('confirmPassword').disable();
              }
            });
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            this.componentDestroyed.next();
            this.componentDestroyed.unsubscribe();
          }
        }, {
          key: "register",
          value: function register() {
            var _this2 = this;

            this.isReqSending = true;

            if (this.form.value.dob) {
              var dob = dayjs__WEBPACK_IMPORTED_MODULE_13__(this.form.value.dob).format(_shared_configs_main_config__WEBPACK_IMPORTED_MODULE_14__["DATE_FORMAT"]);
              this.form.value.dob = dob;
            }

            delete this.form.value.confirmPassword;

            this._authService.register(this.form.value).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_15__["takeUntil"])(this.componentDestroyed)).subscribe(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        this.isReqSending = false;

                        if (!(res.response_code === _shared_configs_response_constants__WEBPACK_IMPORTED_MODULE_8__["RESPONSE_CODES"].SUCCESS)) {
                          _context.next = 10;
                          break;
                        }

                        _context.next = 4;
                        return this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_9__["StorageEnum"].LOGGEDIN, true);

                      case 4:
                        _context.next = 6;
                        return this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_9__["StorageEnum"].PROFILE, res.user);

                      case 6:
                        _context.next = 8;
                        return this._router.navigate(['/']);

                      case 8:
                        _context.next = 12;
                        break;

                      case 10:
                        _context.next = 12;
                        return this._toast.error(res.response_msg);

                      case 12:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            });
          }
        }, {
          key: "openLogin",
          value: function openLogin() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._router.navigate(['/', _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].ROOT, _auth_routes_enum__WEBPACK_IMPORTED_MODULE_6__["AuthRoutesEnum"].LOGIN]);

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "openDataPicker",
          value: function openDataPicker() {}
        }]);

        return RegPage;
      }();

      RegPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
        }, {
          type: _auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]
        }, {
          type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_10__["CoreStore"]
        }, {
          type: _shared_helpers_toast_notification_service__WEBPACK_IMPORTED_MODULE_11__["ToastNotificationService"]
        }];
      };

      RegPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-reg',
        template: _raw_loader_reg_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_reg_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], RegPage);
      /***/
    },

    /***/
    "Taae":
    /*!**********************************************!*\
      !*** ./src/app/shared/classes/validators.ts ***!
      \**********************************************/

    /*! exports provided: matchValuesValidator */

    /***/
    function Taae(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "matchValuesValidator", function () {
        return matchValuesValidator;
      });

      function matchValuesValidator(matchTo // name of the control to match to
      ) {
        return function (control) {
          return !!control.parent && !!control.parent.value && control.value === control.parent.controls[matchTo].value ? null : {
            isMatching: true
          };
        };
      }
      /***/

    },

    /***/
    "VN82":
    /*!******************************************************!*\
      !*** ./src/app/pages/auth/reg/reg-routing.module.ts ***!
      \******************************************************/

    /*! exports provided: RegPageRoutingModule */

    /***/
    function VN82(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegPageRoutingModule", function () {
        return RegPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _reg_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./reg.page */
      "OGha");

      var routes = [{
        path: '',
        component: _reg_page__WEBPACK_IMPORTED_MODULE_3__["RegPage"]
      }];

      var RegPageRoutingModule = function RegPageRoutingModule() {
        _classCallCheck(this, RegPageRoutingModule);
      };

      RegPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], RegPageRoutingModule);
      /***/
    },

    /***/
    "Wgwc":
    /*!*****************************************!*\
      !*** ./node_modules/dayjs/dayjs.min.js ***!
      \*****************************************/

    /*! no static exports found */

    /***/
    function Wgwc(module, exports, __webpack_require__) {
      !function (t, e) {
        true ? module.exports = e() : undefined;
      }(this, function () {
        "use strict";

        var t = "millisecond",
            e = "second",
            n = "minute",
            r = "hour",
            i = "day",
            s = "week",
            u = "month",
            a = "quarter",
            o = "year",
            f = "date",
            h = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[^0-9]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
            c = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
            d = {
          name: "en",
          weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
          months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_")
        },
            $ = function $(t, e, n) {
          var r = String(t);
          return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
        },
            l = {
          s: $,
          z: function z(t) {
            var e = -t.utcOffset(),
                n = Math.abs(e),
                r = Math.floor(n / 60),
                i = n % 60;
            return (e <= 0 ? "+" : "-") + $(r, 2, "0") + ":" + $(i, 2, "0");
          },
          m: function t(e, n) {
            if (e.date() < n.date()) return -t(n, e);
            var r = 12 * (n.year() - e.year()) + (n.month() - e.month()),
                i = e.clone().add(r, u),
                s = n - i < 0,
                a = e.clone().add(r + (s ? -1 : 1), u);
            return +(-(r + (n - i) / (s ? i - a : a - i)) || 0);
          },
          a: function a(t) {
            return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
          },
          p: function p(h) {
            return {
              M: u,
              y: o,
              w: s,
              d: i,
              D: f,
              h: r,
              m: n,
              s: e,
              ms: t,
              Q: a
            }[h] || String(h || "").toLowerCase().replace(/s$/, "");
          },
          u: function u(t) {
            return void 0 === t;
          }
        },
            y = "en",
            M = {};

        M[y] = d;

        var m = function m(t) {
          return t instanceof S;
        },
            D = function D(t, e, n) {
          var r;
          if (!t) return y;
          if ("string" == typeof t) M[t] && (r = t), e && (M[t] = e, r = t);else {
            var i = t.name;
            M[i] = t, r = i;
          }
          return !n && r && (y = r), r || !n && y;
        },
            v = function v(t, e) {
          if (m(t)) return t.clone();
          var n = "object" == typeof e ? e : {};
          return n.date = t, n.args = arguments, new S(n);
        },
            g = l;

        g.l = D, g.i = m, g.w = function (t, e) {
          return v(t, {
            locale: e.$L,
            utc: e.$u,
            x: e.$x,
            $offset: e.$offset
          });
        };

        var S = function () {
          function d(t) {
            this.$L = D(t.locale, null, !0), this.parse(t);
          }

          var $ = d.prototype;
          return $.parse = function (t) {
            this.$d = function (t) {
              var e = t.date,
                  n = t.utc;
              if (null === e) return new Date(NaN);
              if (g.u(e)) return new Date();
              if (e instanceof Date) return new Date(e);

              if ("string" == typeof e && !/Z$/i.test(e)) {
                var r = e.match(h);

                if (r) {
                  var i = r[2] - 1 || 0,
                      s = (r[7] || "0").substring(0, 3);
                  return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s);
                }
              }

              return new Date(e);
            }(t), this.$x = t.x || {}, this.init();
          }, $.init = function () {
            var t = this.$d;
            this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
          }, $.$utils = function () {
            return g;
          }, $.isValid = function () {
            return !("Invalid Date" === this.$d.toString());
          }, $.isSame = function (t, e) {
            var n = v(t);
            return this.startOf(e) <= n && n <= this.endOf(e);
          }, $.isAfter = function (t, e) {
            return v(t) < this.startOf(e);
          }, $.isBefore = function (t, e) {
            return this.endOf(e) < v(t);
          }, $.$g = function (t, e, n) {
            return g.u(t) ? this[e] : this.set(n, t);
          }, $.unix = function () {
            return Math.floor(this.valueOf() / 1e3);
          }, $.valueOf = function () {
            return this.$d.getTime();
          }, $.startOf = function (t, a) {
            var h = this,
                c = !!g.u(a) || a,
                d = g.p(t),
                $ = function $(t, e) {
              var n = g.w(h.$u ? Date.UTC(h.$y, e, t) : new Date(h.$y, e, t), h);
              return c ? n : n.endOf(i);
            },
                l = function l(t, e) {
              return g.w(h.toDate()[t].apply(h.toDate("s"), (c ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e)), h);
            },
                y = this.$W,
                M = this.$M,
                m = this.$D,
                D = "set" + (this.$u ? "UTC" : "");

            switch (d) {
              case o:
                return c ? $(1, 0) : $(31, 11);

              case u:
                return c ? $(1, M) : $(0, M + 1);

              case s:
                var v = this.$locale().weekStart || 0,
                    S = (y < v ? y + 7 : y) - v;
                return $(c ? m - S : m + (6 - S), M);

              case i:
              case f:
                return l(D + "Hours", 0);

              case r:
                return l(D + "Minutes", 1);

              case n:
                return l(D + "Seconds", 2);

              case e:
                return l(D + "Milliseconds", 3);

              default:
                return this.clone();
            }
          }, $.endOf = function (t) {
            return this.startOf(t, !1);
          }, $.$set = function (s, a) {
            var h,
                c = g.p(s),
                d = "set" + (this.$u ? "UTC" : ""),
                $ = (h = {}, h[i] = d + "Date", h[f] = d + "Date", h[u] = d + "Month", h[o] = d + "FullYear", h[r] = d + "Hours", h[n] = d + "Minutes", h[e] = d + "Seconds", h[t] = d + "Milliseconds", h)[c],
                l = c === i ? this.$D + (a - this.$W) : a;

            if (c === u || c === o) {
              var y = this.clone().set(f, 1);
              y.$d[$](l), y.init(), this.$d = y.set(f, Math.min(this.$D, y.daysInMonth())).$d;
            } else $ && this.$d[$](l);

            return this.init(), this;
          }, $.set = function (t, e) {
            return this.clone().$set(t, e);
          }, $.get = function (t) {
            return this[g.p(t)]();
          }, $.add = function (t, a) {
            var f,
                h = this;
            t = Number(t);

            var c = g.p(a),
                d = function d(e) {
              var n = v(h);
              return g.w(n.date(n.date() + Math.round(e * t)), h);
            };

            if (c === u) return this.set(u, this.$M + t);
            if (c === o) return this.set(o, this.$y + t);
            if (c === i) return d(1);
            if (c === s) return d(7);
            var $ = (f = {}, f[n] = 6e4, f[r] = 36e5, f[e] = 1e3, f)[c] || 1,
                l = this.$d.getTime() + t * $;
            return g.w(l, this);
          }, $.subtract = function (t, e) {
            return this.add(-1 * t, e);
          }, $.format = function (t) {
            var e = this;
            if (!this.isValid()) return "Invalid Date";

            var n = t || "YYYY-MM-DDTHH:mm:ssZ",
                r = g.z(this),
                i = this.$locale(),
                s = this.$H,
                u = this.$m,
                a = this.$M,
                o = i.weekdays,
                f = i.months,
                h = function h(t, r, i, s) {
              return t && (t[r] || t(e, n)) || i[r].substr(0, s);
            },
                d = function d(t) {
              return g.s(s % 12 || 12, t, "0");
            },
                $ = i.meridiem || function (t, e, n) {
              var r = t < 12 ? "AM" : "PM";
              return n ? r.toLowerCase() : r;
            },
                l = {
              YY: String(this.$y).slice(-2),
              YYYY: this.$y,
              M: a + 1,
              MM: g.s(a + 1, 2, "0"),
              MMM: h(i.monthsShort, a, f, 3),
              MMMM: h(f, a),
              D: this.$D,
              DD: g.s(this.$D, 2, "0"),
              d: String(this.$W),
              dd: h(i.weekdaysMin, this.$W, o, 2),
              ddd: h(i.weekdaysShort, this.$W, o, 3),
              dddd: o[this.$W],
              H: String(s),
              HH: g.s(s, 2, "0"),
              h: d(1),
              hh: d(2),
              a: $(s, u, !0),
              A: $(s, u, !1),
              m: String(u),
              mm: g.s(u, 2, "0"),
              s: String(this.$s),
              ss: g.s(this.$s, 2, "0"),
              SSS: g.s(this.$ms, 3, "0"),
              Z: r
            };

            return n.replace(c, function (t, e) {
              return e || l[t] || r.replace(":", "");
            });
          }, $.utcOffset = function () {
            return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
          }, $.diff = function (t, f, h) {
            var c,
                d = g.p(f),
                $ = v(t),
                l = 6e4 * ($.utcOffset() - this.utcOffset()),
                y = this - $,
                M = g.m(this, $);
            return M = (c = {}, c[o] = M / 12, c[u] = M, c[a] = M / 3, c[s] = (y - l) / 6048e5, c[i] = (y - l) / 864e5, c[r] = y / 36e5, c[n] = y / 6e4, c[e] = y / 1e3, c)[d] || y, h ? M : g.a(M);
          }, $.daysInMonth = function () {
            return this.endOf(u).$D;
          }, $.$locale = function () {
            return M[this.$L];
          }, $.locale = function (t, e) {
            if (!t) return this.$L;
            var n = this.clone(),
                r = D(t, e, !0);
            return r && (n.$L = r), n;
          }, $.clone = function () {
            return g.w(this.$d, this);
          }, $.toDate = function () {
            return new Date(this.valueOf());
          }, $.toJSON = function () {
            return this.isValid() ? this.toISOString() : null;
          }, $.toISOString = function () {
            return this.$d.toISOString();
          }, $.toString = function () {
            return this.$d.toUTCString();
          }, d;
        }(),
            p = S.prototype;

        return v.prototype = p, [["$ms", t], ["$s", e], ["$m", n], ["$H", r], ["$W", i], ["$M", u], ["$y", o], ["$D", f]].forEach(function (t) {
          p[t[1]] = function (e) {
            return this.$g(e, t[0], t[1]);
          };
        }), v.extend = function (t, e) {
          return t.$i || (t(e, S, v), t.$i = !0), v;
        }, v.locale = D, v.isDayjs = m, v.unix = function (t) {
          return v(1e3 * t);
        }, v.en = M[y], v.Ls = M, v.p = {}, v;
      });
      /***/
    }
  }]);
})();
//# sourceMappingURL=reg-reg-module-es5.js.map