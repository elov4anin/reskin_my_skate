(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-search-skateparks-search-skateparks-module"],{

/***/ "3FNA":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/search-skateparks/search-skateparks.page.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar color=\"dark\">\n        <ion-button slot=\"start\" color=\"dark\" (click)=\"back()\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n        </ion-button>\n        <ion-searchbar\n                class=\"search-field-page\"\n                inputmode=\"search\"\n                mode=\"ios\"\n                color=\"dark\"\n                placeholder=\"Looking for a skatepark?\"\n                clearIcon=\"close-outline\"\n                debounce=\"600\"\n                searchIcon=\"undefined\"\n                [(ngModel)]=\"currentFilter.location\"\n                (ionChange)=\"search($event)\"\n        ></ion-searchbar>\n        <ion-button slot=\"end\" [color]=\"isFilterActive? 'warning': 'light'\" fill=\"clear\" class=\"filter-btn\"\n                    (click)=\"openFilter()\" size=\"small\">\n            <ion-icon slot=\"icon-only\" name=\"filter\" size=\"small\"></ion-icon>\n        </ion-button>\n    </ion-toolbar>\n</ion-header>\n<div class=\"segments-wrapper\">\n    <ion-segment (ionChange)=\"segmentChanged()\" mode=\"md\" [(ngModel)]=\"selectedSegment\" color=\"secondary\">\n        <ion-segment-button *ngFor=\"let s of segments\" [value]=\"s\">\n            <ion-label>\n                <ion-text class=\"text-16-500 text-no-transform\">{{segmentsEnum2LabelMapping[s]}}</ion-text>\n            </ion-label>\n        </ion-segment-button>\n    </ion-segment>\n</div>\n\n<ion-content color=\"primary\">\n\n    <ng-container *ngIf=\"selectedSegment === segmentsEnum.LIST\">\n        <ion-list color=\"primary\">\n            <ion-item *ngFor=\"let s of foundSkateparks\" color=\"primary\" lines=\"none\" (click)=\"openSkatepark(s)\">\n                <ion-thumbnail slot=\"start\" class=\"pos-relative\">\n                    <ion-badge color=\"success\" class=\"badge-into-thumbnail\">New</ion-badge>\n                    <img [src]=\"s.has_images === '1' ? s.images[0] : '../../../assets/images/no-image-thumbnall.png'\">\n                </ion-thumbnail>\n                <div class=\"d-flex flex-column\">\n                    <ion-text color=\"light\" class=\"text-16\">{{s.name}}</ion-text>\n                    <ion-text color=\"medium\" class=\"text-15\">{{s.address}}, {{s.city}}</ion-text>\n                    <ion-text color=\"medium\" class=\"text-13-300\">Last update on May 5, 2020</ion-text>\n                </div>\n\n                <ion-fab-button slot=\"end\" color=\"primary\" size=\"small\">\n                    <ion-text color=\"secondary\" class=\"text-16\">{{s.rating}}</ion-text>\n                </ion-fab-button>\n            </ion-item>\n        </ion-list>\n\n        <!-- <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n             <ion-infinite-scroll-content\n                     loadingSpinner=\"bubbles\"\n                     loadingText=\"Loading more...\"\n             >\n             </ion-infinite-scroll-content>\n         </ion-infinite-scroll>-->\n    </ng-container>\n    <ng-container *ngIf=\"selectedSegment === segmentsEnum.MAP\">\n        <app-google-map [coordinates]=\"currentFilter.coordinates\"\n                        [skateparks]=\"foundSkateparks\"\n                        [searchValue]=\"currentFilter.location\"\n        ></app-google-map>\n    </ng-container>\n</ion-content>\n");

/***/ }),

/***/ "4EJ7":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/search-skateparks/google-map/google-map.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"map-wrapper\">\n  <div id=\"map_center\">\n  </div>\n  <div #map id=\"map\"></div>\n</div>\n");

/***/ }),

/***/ "7NIq":
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/search-skateparks/modal-filter-skateparks/modal-filter-skateparks.component.scss ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-button {\n  width: 154px;\n  height: 44px;\n}\n\nion-list {\n  background: var(--ion-color-dark);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbW9kYWwtZmlsdGVyLXNrYXRlcGFya3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsaUNBQUE7QUFDRiIsImZpbGUiOiJtb2RhbC1maWx0ZXItc2thdGVwYXJrcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1idXR0b24ge1xyXG4gIHdpZHRoOiAxNTRweDtcclxuICBoZWlnaHQ6IDQ0cHg7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "C/+F":
/*!*********************************************************************!*\
  !*** ./src/app/pages/search-skateparks/search-skateparks.page.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --min-height: 60px;\n}\n\nion-searchbar {\n  --placeholder-font-weight: 500;\n  --placeholder-color: var(--ion-color-medium);\n  --placeholder-opacity: 0.9;\n  -webkit-padding-end: 0;\n          padding-inline-end: 0;\n}\n\n.filter-btn {\n  height: 46px;\n}\n\nion-segment-button {\n  color: var(--ion-color-light);\n}\n\nion-list {\n  background: var(--ion-color-primary);\n}\n\nion-item {\n  --padding-top: 12px;\n  --padding-bottom: 12px;\n}\n\nion-fab-button {\n  --border-color: var(--theme-divisor-color);\n  --border-style: solid;\n  --border-width: 1px;\n}\n\n.segments-wrapper {\n  background: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzZWFyY2gtc2thdGVwYXJrcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsOEJBQUE7RUFDQSw0Q0FBQTtFQUNBLDBCQUFBO0VBQ0Esc0JBQUE7VUFBQSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtBQUNGOztBQUVBO0VBQ0MsNkJBQUE7QUFDRDs7QUFFQTtFQUNFLG9DQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLHNCQUFBO0FBQ0Y7O0FBRUE7RUFDRSwwQ0FBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLG9DQUFBO0FBQ0YiLCJmaWxlIjoic2VhcmNoLXNrYXRlcGFya3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tbWluLWhlaWdodDogNjBweDtcclxufVxyXG5cclxuaW9uLXNlYXJjaGJhciB7XHJcbiAgLS1wbGFjZWhvbGRlci1mb250LXdlaWdodDogNTAwO1xyXG4gIC0tcGxhY2Vob2xkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gIC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMC45O1xyXG4gIHBhZGRpbmctaW5saW5lLWVuZDogMDtcclxufVxyXG5cclxuLmZpbHRlci1idG4ge1xyXG4gIGhlaWdodDogNDZweDtcclxufVxyXG5cclxuaW9uLXNlZ21lbnQtYnV0dG9uIHtcclxuIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLS1wYWRkaW5nLXRvcDogMTJweDtcclxuICAtLXBhZGRpbmctYm90dG9tOiAxMnB4O1xyXG59XHJcblxyXG5pb24tZmFiLWJ1dHRvbiB7XHJcbiAgLS1ib3JkZXItY29sb3I6IHZhcigtLXRoZW1lLWRpdmlzb3ItY29sb3IpO1xyXG4gIC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAtLWJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcblxyXG4uc2VnbWVudHMtd3JhcHBlciB7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "EaGi":
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/search-skateparks/modal-filter-skateparks/filter-skateparks.helper.ts ***!
  \*********************************************************************************************/
/*! exports provided: FilterSkateparksHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterSkateparksHelper", function() { return FilterSkateparksHelper; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");



let FilterSkateparksHelper = class FilterSkateparksHelper {
    constructor() {
        this.defaultFilterState = {
            type: null,
            features: [],
            location: '',
            material: null,
            page: 0,
        };
        this.filterChange$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["ReplaySubject"](1);
    }
    checkFilterActive(filter) {
        return !!(filter.material || filter.features.length > 0 || filter.type);
    }
};
FilterSkateparksHelper.ctorParameters = () => [];
FilterSkateparksHelper = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root"
    })
], FilterSkateparksHelper);



/***/ }),

/***/ "R1Uj":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/search-skateparks/search-skateparks-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: SearchSkateparksPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchSkateparksPageRoutingModule", function() { return SearchSkateparksPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _search_skateparks_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search-skateparks.page */ "oYFc");




const routes = [
    {
        path: '',
        component: _search_skateparks_page__WEBPACK_IMPORTED_MODULE_3__["SearchSkateparksPage"]
    }
];
let SearchSkateparksPageRoutingModule = class SearchSkateparksPageRoutingModule {
};
SearchSkateparksPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SearchSkateparksPageRoutingModule);



/***/ }),

/***/ "W443":
/*!****************************************************************************!*\
  !*** ./src/app/pages/search-skateparks/google-map/google-map.component.ts ***!
  \****************************************************************************/
/*! exports provided: GoogleMapComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoogleMapComponent", function() { return GoogleMapComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_google_map_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./google-map.component.html */ "4EJ7");
/* harmony import */ var _google_map_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./google-map.component.scss */ "sUyb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/core */ "gcOT");





const { Geolocation } = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Plugins"];
let GoogleMapComponent = class GoogleMapComponent {
    constructor() {
        this.skateparks = [];
        this.options = {
            useLocale: true,
            maxResults: 5
        };
        this.mapStyles = [
            { "elementType": "geometry", "stylers": [{ "color": "#242f3e" }] },
            { "elementType": "labels.text.fill", "stylers": [{ "color": "#746855" }] },
            { "elementType": "labels.text.stroke", "stylers": [{ "color": "#242f3e" }] },
            { "featureType": "administrative.locality", "elementType": "labels.text.fill", "stylers": [{ "color": "#00ffc2" }] },
            { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [{ "color": "#ced762" }] },
            { "featureType": "poi.park", "elementType": "geometry", "stylers": [{ "color": "#234135" }] },
            { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [{ "color": "#6b9a76" }] },
            { "featureType": "road", "elementType": "geometry", "stylers": [{ "color": "#38414e" }] },
            { "featureType": "road", "elementType": "geometry.stroke", "stylers": [{ "color": "#212a37" }] },
            { "featureType": "road", "elementType": "labels.text.fill", "stylers": [{ "color": "#9ca5b3" }] },
            { "featureType": "road.highway", "elementType": "geometry", "stylers": [{ "color": "#00699b" }] },
            { "featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{ "color": "#0f1f0e" }] },
            { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{ "color": "#80ceec" }] },
            { "featureType": "transit", "elementType": "geometry", "stylers": [{ "color": "#2f3948" }] },
            { "featureType": "transit.station", "elementType": "labels.text.fill", "stylers": [{ "color": "#c5c84d" }] },
            { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#17263c" }] },
            { "featureType": "water", "elementType": "labels.text.fill", "stylers": [{ "color": "#515c6d" }] },
            { "featureType": "water", "elementType": "labels.text.stroke", "stylers": [{ "color": "#17263c" }] }
        ];
        this.RADIUS_SIZE = 8047; // 5 miles;
    }
    ngOnInit() {
        this.stylesMapType = new google.maps.StyledMapType(this.mapStyles, { name: 'Custom' });
        this.loadMap();
    }
    loadMap() {
        const that = this;
        Geolocation.getCurrentPosition().then((resp) => {
            this.latitude = resp.coords.latitude;
            this.longitude = resp.coords.longitude;
            let latLng = new google.maps.LatLng(this.coordinates.lat, this.coordinates.lng);
            let mapOptions = {
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                center: latLng,
                zoom: 11,
                fullscreenControl: false,
                keyboardShortcuts: false,
                backgroundColor: '#202020',
                mapTypeControlOptions: {
                    mapTypeIds: ['roadmap', 'custom'],
                    style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR
                },
                streetViewControl: false
            };
            // this.getAddressFromCoords(resp.coords.latitude, resp.coords.longitude);
            this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
            this.map.mapTypes.set('custom', this.stylesMapType);
            this.map.setMapTypeId('custom');
            google.maps.event.addListenerOnce(this.map, 'idle', function () {
                // add radius to map
                const radiusSearch = new google.maps.Circle({
                    strokeColor: '#00BDFF',
                    strokeOpacity: 0.8,
                    strokeWeight: 2,
                    fillColor: '#00BDFF',
                    fillOpacity: 0.2,
                    map: that.map,
                    center: that.coordinates,
                    radius: that.RADIUS_SIZE
                });
                // load the markers
                that.loadMarkers(that.skateparks, that.coordinates, that.searchValue, radiusSearch);
            });
            const strictBounds = new google.maps.LatLngBounds(new google.maps.LatLng(48.503867, -11.569082), new google.maps.LatLng(61.176357, 2.746907));
            this.map.addListener('dragend', () => {
                if (strictBounds.contains(this.map.getCenter()))
                    return;
                const c = this.map.getCenter();
                let xlng = c.lng();
                let ylat = c.lat();
                const maxXlng = strictBounds.getNorthEast().lng();
                const maxYlat = strictBounds.getNorthEast().lat();
                const minXlng = strictBounds.getSouthWest().lng();
                const minYlat = strictBounds.getSouthWest().lat();
                if (xlng < minXlng) {
                    xlng = minXlng;
                }
                if (xlng > maxXlng) {
                    xlng = maxXlng;
                }
                if (ylat < minYlat) {
                    ylat = minYlat;
                }
                if (ylat > maxYlat) {
                    ylat = maxYlat;
                }
                this.map.setCenter(new google.maps.LatLng(ylat, xlng));
            });
        }).catch((error) => {
            console.log('Error getting location', error);
        });
    }
    loadMarkers(SkateParks, startlatlng, searchRequest, radiusBounds) {
        // set marker for search location 
        const symbol = {
            fillColor: 'rgb(0, 117, 160)',
            fillOpacity: 1,
            path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
            scale: 5,
            strokeColor: 'rgb(0, 117, 160)',
            strokeWeight: 1
        };
        // add marker for search location
        const startmarker = new google.maps.Marker({
            map: this.map,
            animation: google.maps.Animation.DROP,
            position: startlatlng,
            title: searchRequest,
            icon: symbol
        });
        /** http://maps.google.com/mapfiles/ms/icons/blue-dot.png */
        // change color of marker
        const startmarker_infowindow = " " + searchRequest + " ";
        //addInfoWindow(startmarker, startlatlng);
        //console.log('skateparks as our markers', SkateParks);
        const records = SkateParks;
        for (let i = 0; i < records.length; i++) {
            const record = records[i];
            const center = new google.maps.LatLng(startlatlng.lat, startlatlng.lng);
            const markerPos = new google.maps.LatLng(record.latitude, record.longitude);
            const distance_search_marker = google.maps.geometry.spherical.computeDistanceBetween(center, markerPos);
            if (distance_search_marker <= this.RADIUS_SIZE) {
                const marker = new google.maps.Marker({
                    map: this.map,
                    animation: google.maps.Animation.DROP,
                    position: markerPos
                });
                this.addInfoWindow(marker, record);
            }
        }
    }
    addInfoWindow(marker, record) {
        //console.log('record', record);
        let starrating = record.rating;
        let starcontent = '';
        if (starrating > 0) {
            switch (true) {
                case (starrating > 0 && starrating < 1):
                    starcontent = '<i class="ion-ios-star-half"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating == 1):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating > 1 && starrating < 2):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star-half"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating == 2):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating > 2 && starrating < 3):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star-half"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating == 3):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star-outline"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating > 3 && starrating < 4):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star-half"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating == 4):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star-outline"></i>';
                    break;
                case (starrating > 4 && starrating < 5):
                    starcontent = '<i class="ion-ios-star-half"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star-half"></i>';
                    break;
                case (starrating == 5):
                    starcontent = '<i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i><i class="ion-ios-star"></i>';
                    break;
            }
        }
        else {
            starcontent = 'no rating';
        }
        const jsoncontent = record.id;
        // console.log('jsoncontent', jsoncontent);
        const messageContent = '<div><h4 class="uppercase-text centeralign titlefont positive">' + record.name + '<h4><h6 class="thin-text">' + starcontent + '</h6><a class="button-small button button-dark button-block" (click)="goToSkatePark(' + jsoncontent + ')">View Details</a></div>';
        const infoWindow = new google.maps.InfoWindow({
            content: messageContent
        });
        // var compiled = $compile(messageContent)($rootScope);
        //
        // var infoWindow = new google.maps.InfoWindow({
        //     content: compiled[0]
        // });
        google.maps.event.addListener(marker, 'click', function () {
            infoWindow.open(this.map, marker);
        });
    }
};
GoogleMapComponent.ctorParameters = () => [];
GoogleMapComponent.propDecorators = {
    coordinates: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    skateparks: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    searchValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    mapElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['map', { static: false },] }]
};
GoogleMapComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-google-map',
        template: _raw_loader_google_map_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_google_map_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], GoogleMapComponent);



/***/ }),

/***/ "Xidd":
/*!*********************************************************************!*\
  !*** ./src/app/pages/search-skateparks/search-skateparks.module.ts ***!
  \*********************************************************************/
/*! exports provided: SearchSkateparksPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchSkateparksPageModule", function() { return SearchSkateparksPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _search_skateparks_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./search-skateparks-routing.module */ "R1Uj");
/* harmony import */ var _search_skateparks_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search-skateparks.page */ "oYFc");
/* harmony import */ var _google_map_google_map_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./google-map/google-map.component */ "W443");
/* harmony import */ var _modal_filter_skateparks_modal_filter_skateparks_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modal-filter-skateparks/modal-filter-skateparks.component */ "tep4");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/shared.module */ "PCNd");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");








let SearchSkateparksPageModule = class SearchSkateparksPageModule {
};
SearchSkateparksPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"],
            _search_skateparks_routing_module__WEBPACK_IMPORTED_MODULE_2__["SearchSkateparksPageRoutingModule"]
        ],
        declarations: [
            _search_skateparks_page__WEBPACK_IMPORTED_MODULE_3__["SearchSkateparksPage"],
            _google_map_google_map_component__WEBPACK_IMPORTED_MODULE_4__["GoogleMapComponent"],
            _modal_filter_skateparks_modal_filter_skateparks_component__WEBPACK_IMPORTED_MODULE_5__["ModalFilterSkateparksComponent"],
        ]
    })
], SearchSkateparksPageModule);



/***/ }),

/***/ "eYb3":
/*!**********************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/search-skateparks/modal-filter-skateparks/modal-filter-skateparks.component.html ***!
  \**********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n        <ion-text slot=\"start\" class=\"ion ion-margin-start title-20\">\n            Filter\n        </ion-text>\n\n        <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n            Close\n        </ion-text>\n\n    </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\" class=\"ion-padding-start ion-padding-end\">\n    <from [formGroup]=\"form\">\n        <div class=\"ion-margin-top row\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Type</ion-text>\n            </ion-label>\n            <app-custom-toggle-control [buttons]=\"types\" formControlName=\"type\"></app-custom-toggle-control>\n        </div>\n\n        <div class=\"ion-margin-top row\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Surface</ion-text>\n            </ion-label>\n            <app-custom-toggle-control [buttons]=\"surfaces\" formControlName=\"material\"></app-custom-toggle-control>\n        </div>\n\n        <div class=\"ion-margin-top row\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Skatelite</ion-text>\n            </ion-label>\n            <app-custom-toggle-control [buttons]=\"skatelite\" formControlName=\"skatelite\"></app-custom-toggle-control>\n        </div>\n\n        <div class=\"ion-margin-top row\">\n            <ion-label position=\"stacked\">\n                <ion-text class=\"text-16\">Features</ion-text>\n            </ion-label>\n            <div class=\"mt12\">\n                <app-checkbox-list\n                        [checkboxes]=\"checkboxes\"\n                        formControlName=\"features\"\n                ></app-checkbox-list>\n            </div>\n        </div>\n    </from>\n</ion-content>\n<ion-footer>\n    <ion-toolbar color=\"dark\">\n        <ion-button slot=\"start\" class=\"ml20\" fill=\"solid\" color=\"primary\" expand=\"block\" (click)=\"resetFilter()\">\n            Clear\n        </ion-button>\n        <ion-button slot=\"end\" class=\"mr20\"\n                fill=\"solid\" color=\"success\" expand=\"block\"\n                (click)=\"applyFilter()\"\n        >\n            Apply filters\n        </ion-button>\n    </ion-toolbar>\n</ion-footer>\n");

/***/ }),

/***/ "o0pW":
/*!**********************************************************!*\
  !*** ./src/app/pages/search-skateparks/segments.enum.ts ***!
  \**********************************************************/
/*! exports provided: SegmentsEnum, segmentsEnum2LabelMapping */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SegmentsEnum", function() { return SegmentsEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "segmentsEnum2LabelMapping", function() { return segmentsEnum2LabelMapping; });
var SegmentsEnum;
(function (SegmentsEnum) {
    SegmentsEnum["LIST"] = "LIST";
    SegmentsEnum["MAP"] = "MAP";
})(SegmentsEnum || (SegmentsEnum = {}));
const segmentsEnum2LabelMapping = {
    LIST: 'List view',
    MAP: 'Map view',
};


/***/ }),

/***/ "oYFc":
/*!*******************************************************************!*\
  !*** ./src/app/pages/search-skateparks/search-skateparks.page.ts ***!
  \*******************************************************************/
/*! exports provided: SearchSkateparksPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchSkateparksPage", function() { return SearchSkateparksPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_search_skateparks_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./search-skateparks.page.html */ "3FNA");
/* harmony import */ var _search_skateparks_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./search-skateparks.page.scss */ "C/+F");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _shared_helpers_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/helpers/utils */ "Ua8l");
/* harmony import */ var _segments_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./segments.enum */ "o0pW");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_filter_skateparks_modal_filter_skateparks_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./modal-filter-skateparks/modal-filter-skateparks.component */ "tep4");
/* harmony import */ var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../tabs/tabs.enum */ "162u");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../shared/services/skateparks.service */ "ttFK");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _shared_modals_modal_location_list_modal_location_list_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../shared/modals/modal-location-list/modal-location-list.component */ "Quud");
/* harmony import */ var _shared_services_google_map_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../shared/services/google--map.service */ "+6Mz");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../shared/store/core.store */ "8e7N");
/* harmony import */ var _shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../shared/enums/Storage.enum */ "03gG");
/* harmony import */ var _modal_filter_skateparks_filter_skateparks_helper__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./modal-filter-skateparks/filter-skateparks.helper */ "EaGi");



















let SearchSkateparksPage = class SearchSkateparksPage {
    constructor(_location, _modalController, _router, _route, _skateparksService, _googleMapService, _coreStore, _loadingController, _filterHelper) {
        this._location = _location;
        this._modalController = _modalController;
        this._router = _router;
        this._route = _route;
        this._skateparksService = _skateparksService;
        this._googleMapService = _googleMapService;
        this._coreStore = _coreStore;
        this._loadingController = _loadingController;
        this._filterHelper = _filterHelper;
        this.segmentsEnum = _segments_enum__WEBPACK_IMPORTED_MODULE_6__["SegmentsEnum"];
        this.segments = Object(_shared_helpers_utils__WEBPACK_IMPORTED_MODULE_5__["getEnumAsArray"])(_segments_enum__WEBPACK_IMPORTED_MODULE_6__["SegmentsEnum"]);
        this.segmentsEnum2LabelMapping = _segments_enum__WEBPACK_IMPORTED_MODULE_6__["segmentsEnum2LabelMapping"];
        this.componentDestroyed = new rxjs__WEBPACK_IMPORTED_MODULE_13__["Subject"]();
        this.selectedSegment = _segments_enum__WEBPACK_IMPORTED_MODULE_6__["SegmentsEnum"].LIST;
        this.foundSkateparks = [];
        this.isReloading = false;
        this.isFilterActive = false;
        this.isInit = false;
    }
    ngOnInit() {
        this.isInit = true;
        this.currentFilter = Object.assign({}, this._filterHelper.defaultFilterState);
        this._route.queryParams.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["takeUntil"])(this.componentDestroyed)).subscribe((params) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (params && params.search) {
                if (this.foundSkateparks.length === 0) {
                    const coordinates = yield this._googleMapService.getCoordinates(params.search);
                    this.setFilter(params.search, coordinates);
                    this._filterHelper.filterChange$.next(this.currentFilter);
                }
            }
        }));
        this._filterHelper.filterChange$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["takeUntil"])(this.componentDestroyed), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["switchMap"])((filter) => {
            if (filter) {
                this.currentFilter = filter;
                this.isFilterActive = this._filterHelper.checkFilterActive(filter);
                this.presentLoading().then();
                return this._skateparksService.getParksByLocation(filter);
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_13__["of"])(null);
        })).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.foundSkateparks = res.parks;
            this.isInit = false;
            const isLoading = yield this._loadingController.getTop();
            if (isLoading) {
                yield this._loadingController.dismiss();
            }
        }));
    }
    ngOnDestroy() {
        this.componentDestroyed.next();
        this.componentDestroyed.unsubscribe();
    }
    search(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.isInit) {
                return;
            }
            const isLoading = yield this._loadingController.getTop();
            if (isLoading) {
                return;
            }
            if (!evt.target.value) {
                return false;
            }
            if (evt.target.value.length < 2) {
                return false;
            }
            const modal = yield this._modalController.create({
                component: _shared_modals_modal_location_list_modal_location_list_component__WEBPACK_IMPORTED_MODULE_14__["ModalLocationListComponent"],
                cssClass: 'modal-location-skateparks',
                componentProps: {
                    search: evt.target.value
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data) {
                if (this.selectedSegment === _segments_enum__WEBPACK_IMPORTED_MODULE_6__["SegmentsEnum"].MAP) {
                    this.selectedSegment = _segments_enum__WEBPACK_IMPORTED_MODULE_6__["SegmentsEnum"].LIST;
                }
                this.setFilter(data.selectedLocation, data.coordinates);
                this._filterHelper.filterChange$.next(this.currentFilter);
            }
        });
    }
    back() {
        this._location.back();
    }
    openFilter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this._modalController.create({
                component: _modal_filter_skateparks_modal_filter_skateparks_component__WEBPACK_IMPORTED_MODULE_8__["ModalFilterSkateparksComponent"],
                cssClass: 'modal-filter-skateparks',
                componentProps: {
                    filterState: this.currentFilter
                }
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data && data.filter) {
                this._filterHelper.filterChange$.next(data.filter);
            }
        });
    }
    segmentChanged() {
    }
    openSkatepark(skatepark) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._coreStore.setValue(_shared_enums_Storage_enum__WEBPACK_IMPORTED_MODULE_17__["StorageEnum"].SELECTED_SKATEPARK, skatepark);
            yield this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_9__["tabsEnum2RouteMapping"].SKATEPARKS, skatepark.id]);
        });
    }
    presentLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this._loadingController.create({
                cssClass: 'loading',
                message: 'Please wait...',
                duration: 2000
            });
            yield loading.present();
        });
    }
    setFilter(location, coordinates) {
        this.currentFilter = Object.assign(Object.assign({}, this.currentFilter), { location,
            coordinates });
    }
};
SearchSkateparksPage.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"] },
    { type: _shared_services_skateparks_service__WEBPACK_IMPORTED_MODULE_12__["SkateparksService"] },
    { type: _shared_services_google_map_service__WEBPACK_IMPORTED_MODULE_15__["GoogleMapService"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_16__["CoreStore"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"] },
    { type: _modal_filter_skateparks_filter_skateparks_helper__WEBPACK_IMPORTED_MODULE_18__["FilterSkateparksHelper"] }
];
SearchSkateparksPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-search-skateparks',
        template: _raw_loader_search_skateparks_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_search_skateparks_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SearchSkateparksPage);



/***/ }),

/***/ "sUyb":
/*!******************************************************************************!*\
  !*** ./src/app/pages/search-skateparks/google-map/google-map.component.scss ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#map_canvas {\n  width: 90%;\n  height: 80%;\n  border: 1px solid red;\n}\n\n#address {\n  padding: 10px;\n  font-size: 18px;\n  font-weight: bold;\n}\n\n#map {\n  width: 100%;\n  height: calc(100vh - 108px);\n}\n\n.map-wrapper {\n  position: relative;\n}\n\n.map-wrapper #map_center {\n  position: absolute;\n  z-index: 99;\n  height: 40px;\n  width: 40px;\n  top: 50%;\n  left: 50%;\n  margin-left: -21px;\n  margin-top: -41px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcZ29vZ2xlLW1hcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFFQSwyQkFBQTtBQUFGOztBQUdBO0VBQ0Usa0JBQUE7QUFBRjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBQUoiLCJmaWxlIjoiZ29vZ2xlLW1hcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNtYXBfY2FudmFzIHtcclxuICB3aWR0aDogOTAlO1xyXG4gIGhlaWdodDogODAlO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJlZDtcclxufVxyXG5cclxuI2FkZHJlc3Mge1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4jbWFwIHtcclxuICB3aWR0aDogMTAwJTtcclxuICAvL2hlaWdodDogY2FsYygxMDB2aCAtIDE2MHB4KTsgLy8gd2l0aCB0YWJzXHJcbiAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gMTA4cHgpO1xyXG59XHJcblxyXG4ubWFwLXdyYXBwZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgI21hcF9jZW50ZXIge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogOTk7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0yMXB4O1xyXG4gICAgbWFyZ2luLXRvcDogLTQxcHg7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "tep4":
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/search-skateparks/modal-filter-skateparks/modal-filter-skateparks.component.ts ***!
  \******************************************************************************************************/
/*! exports provided: ModalFilterSkateparksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalFilterSkateparksComponent", function() { return ModalFilterSkateparksComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_filter_skateparks_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-filter-skateparks.component.html */ "eYb3");
/* harmony import */ var _modal_filter_skateparks_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-filter-skateparks.component.scss */ "7NIq");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _shared_store_core_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../shared/store/core.store */ "8e7N");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _dictionaries__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./dictionaries */ "s9Q0");
/* harmony import */ var _surfaces__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./surfaces */ "Di3u");
/* harmony import */ var _filter_skateparks_helper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./filter-skateparks.helper */ "EaGi");










let ModalFilterSkateparksComponent = class ModalFilterSkateparksComponent {
    constructor(_modalController, _coreStore, _fb, _filterHelper) {
        this._modalController = _modalController;
        this._coreStore = _coreStore;
        this._fb = _fb;
        this._filterHelper = _filterHelper;
        this.types = _dictionaries__WEBPACK_IMPORTED_MODULE_7__["TYPES"];
        this.surfaces = _surfaces__WEBPACK_IMPORTED_MODULE_8__["SURFACES"];
        this.skatelite = _surfaces__WEBPACK_IMPORTED_MODULE_8__["SKATELITE"];
        this.checkboxes = [];
    }
    ngOnInit() {
        if (this.filterState) {
            this.creatForm(this.filterState);
        }
        this.checkboxes = this._coreStore.state.skateparkFeatures;
    }
    creatForm(filterState) {
        this.form = this._fb.group({
            type: filterState.type ? filterState.type : '',
            material: filterState.material ? filterState.material : '',
            features: [filterState.features.length > 0 ? filterState.features : []],
            skatelite: filterState.features.includes('skatelite') ? 'skatelite' : ''
        });
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this._modalController.dismiss();
        });
    }
    applyFilter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const currentFormValue = this.form.value;
            if (currentFormValue.skatelite) {
                currentFormValue.features.push(currentFormValue.skatelite);
            }
            delete currentFormValue.skatelite;
            yield this._modalController.dismiss({
                filter: Object.assign(Object.assign({}, currentFormValue), { location: this.filterState.location, coordinates: this.filterState.coordinates })
            });
        });
    }
    resetFilter() {
        this.form.reset();
        //@todo check features filter
        // this.form.get('features').setValue([]);
    }
};
ModalFilterSkateparksComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _shared_store_core_store__WEBPACK_IMPORTED_MODULE_5__["CoreStore"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"] },
    { type: _filter_skateparks_helper__WEBPACK_IMPORTED_MODULE_9__["FilterSkateparksHelper"] }
];
ModalFilterSkateparksComponent.propDecorators = {
    filterState: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
ModalFilterSkateparksComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-filter-skateparks',
        template: _raw_loader_modal_filter_skateparks_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_filter_skateparks_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalFilterSkateparksComponent);



/***/ })

}]);
//# sourceMappingURL=pages-search-skateparks-search-skateparks-module-es2015.js.map