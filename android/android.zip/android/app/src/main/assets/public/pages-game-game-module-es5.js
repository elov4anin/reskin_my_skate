(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-game-game-module"], {
    /***/
    "Bt0R":
    /*!**************************************************************************************!*\
      !*** ./src/app/pages/game/modals/modal-leaderboard/modal-leaderboard.component.scss ***!
      \**************************************************************************************/

    /*! exports provided: default */

    /***/
    function Bt0R(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-avatar {\n  width: 20px;\n  height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXG1vZGFsLWxlYWRlcmJvYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFDRiIsImZpbGUiOiJtb2RhbC1sZWFkZXJib2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1hdmF0YXIge1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIGhlaWdodDogMjBweDtcclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "QbLx":
    /*!***************************************************!*\
      !*** ./src/app/pages/game/game-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: GameRoutingModule */

    /***/
    function QbLx(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GameRoutingModule", function () {
        return GameRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _game_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./game-routes */
      "2DP2");

      var routes = [{
        path: '',
        redirectTo: "/".concat(_game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].ROOT, "/") + _game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].TRICK,
        pathMatch: 'full'
      }, {
        path: _game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].TRICK,
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-trick-trick-module */
          "pages-trick-trick-module").then(__webpack_require__.bind(null,
          /*! ./pages/trick/trick.module */
          "we8H")).then(function (m) {
            return m.TrickPageModule;
          });
        }
      }, {
        path: _game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].NAILED,
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-nailed-nailed-module */
          "pages-nailed-nailed-module").then(__webpack_require__.bind(null,
          /*! ./pages/nailed/nailed.module */
          "DIJX")).then(function (m) {
            return m.NailedPageModule;
          });
        }
      }, {
        path: _game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].FAILED,
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-failed-failed-module */
          "pages-failed-failed-module").then(__webpack_require__.bind(null,
          /*! ./pages/failed/failed.module */
          "skNk")).then(function (m) {
            return m.FailedPageModule;
          });
        }
      }, {
        path: _game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].CURRENT,
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-current-standings-current-standings-module */
          "pages-current-standings-current-standings-module").then(__webpack_require__.bind(null,
          /*! ./pages/current-standings/current-standings.module */
          "9X0p")).then(function (m) {
            return m.CurrentStandingsPageModule;
          });
        }
      }, {
        path: _game_routes__WEBPACK_IMPORTED_MODULE_3__["GameRoutes"].CONGRADULATIONS,
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-congradulations-congradulations-module */
          "pages-congradulations-congradulations-module").then(__webpack_require__.bind(null,
          /*! ./pages/congradulations/congradulations.module */
          "xijz")).then(function (m) {
            return m.CongradulationsPageModule;
          });
        }
      }];

      var GameRoutingModule = function GameRoutingModule() {
        _classCallCheck(this, GameRoutingModule);
      };

      GameRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], GameRoutingModule);
      /***/
    },

    /***/
    "kgeY":
    /*!*******************************************!*\
      !*** ./src/app/pages/game/game.module.ts ***!
      \*******************************************/

    /*! exports provided: GameModule */

    /***/
    function kgeY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GameModule", function () {
        return GameModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _game_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./game-routing.module */
      "QbLx");
      /* harmony import */


      var _modals_modal_leaderboard_modal_leaderboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./modals/modal-leaderboard/modal-leaderboard.component */
      "yVue");

      var GameModule = function GameModule() {
        _classCallCheck(this, GameModule);
      };

      GameModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _game_routing_module__WEBPACK_IMPORTED_MODULE_5__["GameRoutingModule"]],
        declarations: [_modals_modal_leaderboard_modal_leaderboard_component__WEBPACK_IMPORTED_MODULE_6__["ModalLeaderboardComponent"]]
      })], GameModule);
      /***/
    },

    /***/
    "pCjB":
    /*!****************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/modals/modal-leaderboard/modal-leaderboard.component.html ***!
      \****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function pCjB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion-margin-start title-20\">\n      Leaderboard\n    </ion-text>\n\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <div class=\"divisor mt20\"></div>\n<ion-list class=\"ion-list-dark\">\n  <ion-list-header color=\"dark\">\n    <div  class=\"d-flex ion-justify-content-between w100percent\">\n      <ion-text color=\"light\" class=\"text-16\">Player</ion-text>\n      <ion-text color=\"light\" class=\"ion-margin-end text-16\">Wins</ion-text>\n    </div>\n  </ion-list-header>\n  <ion-item *ngFor=\"let p of players; let idx = index\" color=\"dark\" lines=\"none\">\n    <ion-text slot=\"start\" [color]=\"idx === 1 ? 'secondary' : 'medium'\" class=\"text-13-300\">{{idx}}</ion-text>\n    <ion-avatar slot=\"start\">\n      <img src=\"../../../../../assets/images/person.png\">\n    </ion-avatar>\n    <ion-label [color]=\"idx === 1 ? 'secondary' : 'tertiary'\" class=\"text-16\">Matt Jones</ion-label>\n    <ion-chip slot=\"end\" color=\"dark\"><ion-text [color]=\"idx === 1 ? 'secondary' : 'light'\" class=\"text-16\">23</ion-text></ion-chip>\n  </ion-item>\n</ion-list>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar color=\"dark\">\n    <ion-button\n            class=\"ion-margin-start ion-margin-end mb12 apply-btn\"\n            fill=\"solid\" color=\"success\" expand=\"block\"\n            (click)=\"playAgain()\"\n    >\n      Play again\n    </ion-button>\n  </ion-toolbar>\n</ion-footer>\n";
      /***/
    },

    /***/
    "yVue":
    /*!************************************************************************************!*\
      !*** ./src/app/pages/game/modals/modal-leaderboard/modal-leaderboard.component.ts ***!
      \************************************************************************************/

    /*! exports provided: ModalLeaderboardComponent */

    /***/
    function yVue(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ModalLeaderboardComponent", function () {
        return ModalLeaderboardComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_modal_leaderboard_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./modal-leaderboard.component.html */
      "pCjB");
      /* harmony import */


      var _modal_leaderboard_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./modal-leaderboard.component.scss */
      "Bt0R");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var ModalLeaderboardComponent = /*#__PURE__*/function () {
        function ModalLeaderboardComponent(_modalController) {
          _classCallCheck(this, ModalLeaderboardComponent);

          this._modalController = _modalController;
          this.players = [1, 2, 3,, 4, 5, 5, 6, 7, 8, 9, 7, 4, 4, 2, 3,, 4, 5, 5, 6, 7, 8, 9, 7, 4, 4];
        }

        _createClass(ModalLeaderboardComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "closeModal",
          value: function closeModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._modalController.dismiss();

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "playAgain",
          value: function playAgain() {
            this.closeModal().then();
          }
        }]);

        return ModalLeaderboardComponent;
      }();

      ModalLeaderboardComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }];
      };

      ModalLeaderboardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-leaderboard',
        template: _raw_loader_modal_leaderboard_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_leaderboard_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ModalLeaderboardComponent);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-game-game-module-es5.js.map