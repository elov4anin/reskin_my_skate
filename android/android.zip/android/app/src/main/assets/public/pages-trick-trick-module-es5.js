(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-trick-trick-module"], {
    /***/
    "+pLN":
    /*!**********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/pages/trick/trick.page.html ***!
      \**********************************************************************************************/

    /*! exports provided: default */

    /***/
    function pLN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content color=\"primary\">\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"stopGame()\">\n      <ion-icon name=\"power-outline\" color=\"danger\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <div class=\"d-flex flex-column ion-align-items-center ion-justify-content-start trick\">\n    <ion-text color=\"tertiary\" class=\"text-15\">Trick 2</ion-text>\n    <ion-text  color=\"light\" class=\"title-34\">Frontside Flip</ion-text>\n    <ion-button fill=\"clear\" class=\"mb16\" (click)=\"openModalPlayTrick()\">\n      <ion-icon color=\"secondary\" name=\"play-circle-outline\" slot=\"start\"></ion-icon>\n      <ion-text color=\"secondary\" class=\"text-16\">Play instructions</ion-text>\n    </ion-button>\n    <ion-avatar>\n      <img src=\"../../../../../assets/images/person.png\">\n    </ion-avatar>\n\n    <ion-text color=\"tertiary\" class=\"mt12 text-16\">Bobby Mount</ion-text>\n    <div class=\"d-flex ion-justify-content-between buttons\">\n\n      <ion-button class=\"game-btn\" color=\"success\" (click)=\"openNailed()\">\n        <div class=\"d-flex flex-column ion-justify-content-center\">\n          <ion-icon src=\"assets/images/svg-icons/nailed.svg\"></ion-icon>\n          <ion-text class=\"title-20 mt12\">Nailed it!</ion-text>\n          <ion-text class=\"text-12 mt4\">No letter</ion-text>\n        </div>\n      </ion-button>\n\n      <ion-button class=\"game-btn\" color=\"dark\" (click)=\"openFailed()\">\n        <div class=\"d-flex flex-column ion-justify-content-center\">\n          <ion-icon src=\"assets/images/svg-icons/failed.svg\"></ion-icon>\n          <ion-text class=\"title-20 mt12\">Failed it</ion-text>\n          <ion-text class=\"text-12 mt4\">You get a S</ion-text>\n        </div>\n      </ion-button>\n\n    </div>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "BGTw":
    /*!*********************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/game/pages/trick/modal-trick-howto/modal-trick-howto.component.html ***!
      \*********************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function BGTw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"dark\" class=\"ion-padding-top\">\n    <ion-text slot=\"start\" class=\"ion-margin-start title-20\">\n      Trick instructions\n    </ion-text>\n    <ion-text (click)=\"closeModal()\" slot=\"end\" color=\"secondary\" class=\"ion-margin-end text-16-500 text-hover\">\n      Close\n    </ion-text>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"dark\">\n  <div class=\"d-flex h100percent ion-align-items-center ion-justify-content-center\">\n    <iframe\n            width=\"375\"\n            height=\"211\"\n            src=\"https://www.youtube.com/embed/aHrn3-Cb3iM\"\n            frameborder=\"0\"\n            allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\"\n            allowfullscreen></iframe>\n  </div>\n\n</ion-content>\n";
      /***/
    },

    /***/
    "Y0br":
    /*!****************************************************************!*\
      !*** ./src/app/pages/game/pages/trick/trick-routing.module.ts ***!
      \****************************************************************/

    /*! exports provided: TrickPageRoutingModule */

    /***/
    function Y0br(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TrickPageRoutingModule", function () {
        return TrickPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _trick_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./trick.page */
      "c7xa");

      var routes = [{
        path: '',
        component: _trick_page__WEBPACK_IMPORTED_MODULE_3__["TrickPage"]
      }];

      var TrickPageRoutingModule = function TrickPageRoutingModule() {
        _classCallCheck(this, TrickPageRoutingModule);
      };

      TrickPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], TrickPageRoutingModule);
      /***/
    },

    /***/
    "c7xa":
    /*!******************************************************!*\
      !*** ./src/app/pages/game/pages/trick/trick.page.ts ***!
      \******************************************************/

    /*! exports provided: TrickPage */

    /***/
    function c7xa(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TrickPage", function () {
        return TrickPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_trick_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./trick.page.html */
      "+pLN");
      /* harmony import */


      var _trick_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./trick.page.scss */
      "vkpY");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _modal_trick_howto_modal_trick_howto_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./modal-trick-howto/modal-trick-howto.component */
      "kFW/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../tabs/tabs.enum */
      "162u");
      /* harmony import */


      var _game_routes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../game-routes */
      "2DP2");

      var TrickPage = /*#__PURE__*/function () {
        function TrickPage(_modalController, _router) {
          _classCallCheck(this, TrickPage);

          this._modalController = _modalController;
          this._router = _router;
        }

        _createClass(TrickPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "openModalPlayTrick",
          value: function openModalPlayTrick() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var modal;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this._modalController.create({
                        component: _modal_trick_howto_modal_trick_howto_component__WEBPACK_IMPORTED_MODULE_5__["ModalTrickHowtoComponent"],
                        cssClass: 'modal-add-players'
                      });

                    case 2:
                      modal = _context.sent;
                      _context.next = 5;
                      return modal.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "stopGame",
          value: function stopGame() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this._router.navigate(['/', _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_7__["TABS_MAIN_ROUTE"], _tabs_tabs_enum__WEBPACK_IMPORTED_MODULE_7__["tabsEnum2RouteMapping"].GAME]);

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "openNailed",
          value: function openNailed() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this._router.navigate(['/', _game_routes__WEBPACK_IMPORTED_MODULE_8__["GameRoutes"].ROOT, _game_routes__WEBPACK_IMPORTED_MODULE_8__["GameRoutes"].NAILED]);

                    case 2:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "openFailed",
          value: function openFailed() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this._router.navigate(['/', _game_routes__WEBPACK_IMPORTED_MODULE_8__["GameRoutes"].ROOT, _game_routes__WEBPACK_IMPORTED_MODULE_8__["GameRoutes"].FAILED]);

                    case 2:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }]);

        return TrickPage;
      }();

      TrickPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
        }];
      };

      TrickPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-trick',
        template: _raw_loader_trick_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_trick_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TrickPage);
      /***/
    },

    /***/
    "izUN":
    /*!*******************************************************************************************!*\
      !*** ./src/app/pages/game/pages/trick/modal-trick-howto/modal-trick-howto.component.scss ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function izUN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC10cmljay1ob3d0by5jb21wb25lbnQuc2NzcyJ9 */";
      /***/
    },

    /***/
    "kFW/":
    /*!*****************************************************************************************!*\
      !*** ./src/app/pages/game/pages/trick/modal-trick-howto/modal-trick-howto.component.ts ***!
      \*****************************************************************************************/

    /*! exports provided: ModalTrickHowtoComponent */

    /***/
    function kFW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ModalTrickHowtoComponent", function () {
        return ModalTrickHowtoComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_modal_trick_howto_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./modal-trick-howto.component.html */
      "BGTw");
      /* harmony import */


      var _modal_trick_howto_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./modal-trick-howto.component.scss */
      "izUN");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var ModalTrickHowtoComponent = /*#__PURE__*/function () {
        function ModalTrickHowtoComponent(platform, _modalController) {
          _classCallCheck(this, ModalTrickHowtoComponent);

          this.platform = platform;
          this._modalController = _modalController;
        }

        _createClass(ModalTrickHowtoComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "closeModal",
          value: function closeModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      _context5.next = 2;
                      return this._modalController.dismiss();

                    case 2:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }]);

        return ModalTrickHowtoComponent;
      }();

      ModalTrickHowtoComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }];
      };

      ModalTrickHowtoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-trick-howto',
        template: _raw_loader_modal_trick_howto_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_trick_howto_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ModalTrickHowtoComponent);
      /***/
    },

    /***/
    "vkpY":
    /*!********************************************************!*\
      !*** ./src/app/pages/game/pages/trick/trick.page.scss ***!
      \********************************************************/

    /*! exports provided: default */

    /***/
    function vkpY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-fab-button {\n  border: 1px solid var(--theme-divisor-color);\n  border-radius: 50%;\n}\n\n.trick {\n  height: 100%;\n  box-sizing: border-box;\n  padding-top: 140px;\n}\n\n.buttons {\n  margin-top: auto;\n  margin-bottom: 40px;\n}\n\nion-avatar {\n  width: 80px;\n  height: 80px;\n  margin-top: 40px;\n}\n\n.game-btn {\n  width: 140px;\n  height: 177px;\n  border-radius: var(--theme-base-border-radius);\n}\n\n.game-btn:first-of-type {\n  margin-right: 28px;\n}\n\n.game-btn ion-icon {\n  width: 94px;\n  height: 55px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHRyaWNrLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDRDQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDhDQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxrQkFBQTtBQUNKOztBQUVFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFBSiIsImZpbGUiOiJ0cmljay5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZmFiLWJ1dHRvbiB7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0tdGhlbWUtZGl2aXNvci1jb2xvcik7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG59XHJcblxyXG4udHJpY2sge1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gIHBhZGRpbmctdG9wOiAxNDBweDtcclxufVxyXG5cclxuLmJ1dHRvbnMge1xyXG4gIG1hcmdpbi10b3A6IGF1dG87XHJcbiAgbWFyZ2luLWJvdHRvbTogNDBweDtcclxufVxyXG5cclxuaW9uLWF2YXRhciB7XHJcbiAgd2lkdGg6IDgwcHg7XHJcbiAgaGVpZ2h0OiA4MHB4O1xyXG4gIG1hcmdpbi10b3A6IDQwcHg7XHJcbn1cclxuXHJcbi5nYW1lLWJ0biB7XHJcbiAgd2lkdGg6IDE0MHB4O1xyXG4gIGhlaWdodDogMTc3cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tdGhlbWUtYmFzZS1ib3JkZXItcmFkaXVzKTtcclxuXHJcbiAgJjpmaXJzdC1vZi10eXBlIHtcclxuICAgIG1hcmdpbi1yaWdodDogMjhweDtcclxuICB9XHJcblxyXG4gIGlvbi1pY29uIHtcclxuICAgIHdpZHRoOiA5NHB4O1xyXG4gICAgaGVpZ2h0OiA1NXB4O1xyXG4gIH1cclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "we8H":
    /*!********************************************************!*\
      !*** ./src/app/pages/game/pages/trick/trick.module.ts ***!
      \********************************************************/

    /*! exports provided: TrickPageModule */

    /***/
    function we8H(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TrickPageModule", function () {
        return TrickPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _trick_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./trick-routing.module */
      "Y0br");
      /* harmony import */


      var _trick_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./trick.page */
      "c7xa");
      /* harmony import */


      var _modal_trick_howto_modal_trick_howto_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./modal-trick-howto/modal-trick-howto.component */
      "kFW/");

      var TrickPageModule = function TrickPageModule() {
        _classCallCheck(this, TrickPageModule);
      };

      TrickPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _trick_routing_module__WEBPACK_IMPORTED_MODULE_5__["TrickPageRoutingModule"]],
        declarations: [_trick_page__WEBPACK_IMPORTED_MODULE_6__["TrickPage"], _modal_trick_howto_modal_trick_howto_component__WEBPACK_IMPORTED_MODULE_7__["ModalTrickHowtoComponent"]]
      })], TrickPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-trick-trick-module-es5.js.map